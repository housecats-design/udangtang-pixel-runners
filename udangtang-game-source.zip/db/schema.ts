import {integer, sqliteTable, text} from 'drizzle-orm/sqlite-core';
export const sportsRooms = sqliteTable('sports_rooms', {
  code:text('code').primaryKey(),
  state:text('state').notNull(),
  revision:integer('revision').notNull().default(0),
  expires:integer('expires').notNull(),
});
