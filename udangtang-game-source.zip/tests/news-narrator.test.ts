import test from 'node:test';
import assert from 'node:assert/strict';
import {NewsNarrator,spokenNews} from '../src/audio/news-narrator.ts';

function fakeNarrator(){
  const spoken:SpeechSynthesisUtterance[]=[];
  let cancelled=0,errors=0;
  const voices=[{lang:'en-US',localService:true},{lang:'ko-KR',localService:false},{lang:'ko-KR',localService:true}] as SpeechSynthesisVoice[];
  const synthesis={getVoices:()=>voices,speak:(item:SpeechSynthesisUtterance)=>spoken.push(item),cancel:()=>{cancelled++;}};
  const narrator=new NewsNarrator(synthesis as unknown as SpeechSynthesis,
    text=>({text}) as SpeechSynthesisUtterance,()=>{errors++;});
  const end=(item:SpeechSynthesisUtterance)=>item.onend?.call(item,{} as SpeechSynthesisEvent);
  return {narrator,spoken,voices,end,cancelled:()=>cancelled,errors:()=>errors};
}

test('news is spoken in Korean using a local Korean voice without reading decorations',()=>{
  const f=fakeNarrator();f.narrator.setEnabled(true);f.narrator.say('🍭 민수 · 머리 위에 UFO가 나타났어요!');
  const item=f.spoken[0];
  assert.equal(item.text,'민수 , 머리 위에 유에프오가 나타났어요!');
  assert.equal(item.lang,'ko-KR');assert.equal(item.voice,f.voices[2]);
  assert.equal(item.rate,2.5);
  assert.equal(spokenNews(' 🏆️  '),'');
});

test('busy narration finishes its sentence and retains only the latest waiting news',()=>{
  const f=fakeNarrator();f.narrator.setEnabled(true);
  f.narrator.say('첫 소식');f.narrator.say('오래된 대기 소식');f.narrator.say('최신 소식');
  assert.equal(f.spoken.length,1);
  f.end(f.spoken[0]);assert.deepEqual(f.spoken.map(item=>item.text),['첫 소식','최신 소식']);
  f.end(f.spoken[1]);assert.equal(f.spoken.length,2);
});

test('ticker resize and repeat updates do not read the same news again',()=>{
  const f=fakeNarrator();f.narrator.setEnabled(true);f.narrator.say('같은 소식');
  f.narrator.say('같은 소식');f.end(f.spoken[0]);f.narrator.say('같은 소식');
  assert.equal(f.spoken.length,1);
});

test('pause or mute cancels speech and drops pending news even after a late end event',()=>{
  const f=fakeNarrator();f.narrator.setEnabled(true);f.narrator.say('읽는 중');f.narrator.say('대기 중');
  f.narrator.setEnabled(false);f.narrator.setEnabled(false);f.end(f.spoken[0]);
  f.narrator.say('꺼져 있는 동안');assert.equal(f.spoken.length,1);assert.equal(f.cancelled(),1);
  f.narrator.setEnabled(true);f.narrator.say('재개 후 새 소식');assert.equal(f.spoken.length,2);
  f.narrator.reset();f.end(f.spoken[1]);assert.equal(f.cancelled(),2);assert.equal(f.spoken.length,2);
});

test('voices loaded after startup are selected on the next sentence',()=>{
  const f=fakeNarrator();const korean=f.voices.pop()!;f.voices.length=0;
  f.narrator.setEnabled(true);f.narrator.say('첫 소식');assert.equal(f.spoken[0].voice,undefined);
  f.end(f.spoken[0]);f.voices.push(korean);f.narrator.say('다음 소식');assert.equal(f.spoken[1].voice,korean);
});

test('unsupported and failing speech engines leave the game usable',()=>{
  const unsupported=new NewsNarrator(null,()=>{throw Error('must not create an utterance');});
  unsupported.setEnabled(true);unsupported.say('소식');unsupported.reset();assert.equal(unsupported.supported,false);
  const f=fakeNarrator();f.narrator.setEnabled(true);f.narrator.say('실패한 소식');f.narrator.say('대기 소식');
  const item=f.spoken[0];item.onerror?.call(item,{} as SpeechSynthesisErrorEvent);
  assert.equal(f.errors(),1);f.end(item);assert.equal(f.spoken.length,1);
  f.narrator.say('새 소식');assert.equal(f.spoken.length,2);
});
