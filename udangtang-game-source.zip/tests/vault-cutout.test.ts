import test from 'node:test';
import assert from 'node:assert/strict';
import {removeVaultStand} from '../src/sports/vault-cutout.ts';
test('the generated vault stand is removed without losing the warm hand or teal jersey at the grip',()=>{
 const d=new Uint8ClampedArray(96*96*4),set=(x:number,y:number,color:number[])=>d.set(color,(y*96+x)*4),alpha=(x:number,y:number)=>d[(y*96+x)*4+3];
 set(70,52,[114,125,126,255]);set(65,70,[45,61,65,255]);set(65,49,[226,172,116,255]);set(56,48,[46,133,132,255]);set(29,66,[34,49,76,255]);
 removeVaultStand(d,10);
 assert.equal(alpha(70,52),0);assert.equal(alpha(65,70),0);assert.equal(alpha(65,49),255);assert.equal(alpha(56,48),255);assert.equal(alpha(29,66),255);
});
test('unaffected takeoff frames and actor pixels to the left of the stand keep their alpha',()=>{
 const d=new Uint8ClampedArray(96*96*4).fill(123),before=d.slice();removeVaultStand(d,5);assert.deepEqual(d,before);
 removeVaultStand(d,6);assert.equal(d[(75*96+43)*4+3],123,'the trailing foot is outside the equipment mask');
});
