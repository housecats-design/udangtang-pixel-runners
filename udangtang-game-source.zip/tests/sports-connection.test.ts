import test from 'node:test';
import assert from 'node:assert/strict';
import {RoomConnection,type SyncReply} from '../src/sports/connection.ts';
import {applyControl,createMatch,startRound,stepMatch} from '../src/sports/engine.ts';
import {roomApi,type Database} from '../server/rooms.ts';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
const flush=()=>new Promise<void>(resolve=>setImmediate(resolve));
const player={id:'phone',name:'휴대폰',avatar:0,color:'#49c4b2',ready:true,connected:true,total:0};
function reply():SyncReply {const match=createMatch([player],['hurdles']);startRound(match);stepMatch(match,3.1);return {view:{code:'TEST23',athletes:[player],match,revision:1,hostSeen:Date.now(),expires:Date.now()+60000},ack:0};}
test('resuming a stopped connection ignores the old request and does not create duplicate polling loops',async()=>{
  const pending:Array<(reply:SyncReply)=>void>=[];let states=0;
  const c=new RoomConnection({code:'TEST23',token:'phone-token',role:'player',playerId:'phone'},()=>new Promise(resolve=>pending.push(resolve)));
  c.onState=()=>states++;
  try{
    c.start();c.start();assert.equal(pending.length,1);c.stop();c.start();assert.equal(pending.length,2);
    pending[0](reply());await flush();assert.equal(states,0);
    pending[1](reply());await flush();assert.equal(states,1);
  }finally{c.stop();}
});
test('a new touch sends immediately and an old round queue cannot block a rematch',async()=>{
  const bodies:Record<string,unknown>[]=[];let snapshot=reply();
  const c=new RoomConnection({code:'TEST23',token:'phone-token',role:'player',playerId:'phone'},async(_action,body)=>{bodies.push(body);return snapshot;});
  try{
    c.pending=Array.from({length:45},(_,i)=>({seq:i+1,button:'A',down:true,round:0}));c.start();await flush();assert.equal(c.pending.length,0);
    const count=bodies.length;c.input({button:'C',down:true,round:1,at:.125});await flush();assert.equal(bodies.length,count+1);
    const sent=bodies.at(-1)!.inputs as Array<{button:string}>;assert.equal(sent[0].button,'C');
    snapshot={...reply(),ack:c.seq};await c.sync();assert.equal(c.pending.length,0);
  }finally{c.stop();}
});
function database():Database {
  const db=new DatabaseSync(':memory:');for(const file of readdirSync('drizzle').filter(f=>f.endsWith('.sql')))db.exec(readFileSync('drizzle/'+file,'utf8'));
  return {prepare(sql){let values:unknown[]=[];const s={bind(...args:unknown[]){values=args;return s;},async first<T>(){return (db.prepare(sql).get(...values as any[])??null) as T|null;},async all<T>(){return {results:db.prepare(sql).all(...values as any[]) as T[]};},async run(){return db.prepare(sql).run(...values as any[]);}};return s;}};
}
test('phone A/C and B cross the room API, apply once on the PC, and return movement to the phone',async()=>{
  const db=database();
  async function request(action:string,body:Record<string,unknown>){const r=await roomApi(new Request('https://sports.test/sports-api/'+action,{method:'POST',body:JSON.stringify(body)}),db);assert.equal(r.status,200);return await r.json() as SyncReply&{code:string};}
  const hostToken='host-test-secret-token'.repeat(3),{code}=await request('create',{token:hostToken});
  const phone=await request('join',{code,token:'phone-token',name:'휴대폰',avatar:0});
  await request('join',{code,token:'other-token',name:'다른 선수',avatar:1});
  const match=createMatch((await request('host',{code,token:hostToken})).view.athletes,['hurdles']);startRound(match);stepMatch(match,3.1);
  const ack:Record<string,number>={};let frame=1;
  await request('host',{code,token:hostToken,match,frame});
  const c=new RoomConnection({code,token:'phone-token',role:'player',playerId:phone.playerId!},request);
  try{
    c.start();await flush();
    for(let i=0;i<12;i++){
      stepMatch(match,.125);const button=i%2?'C':'A';
      c.input({button,down:true,round:match.number,at:match.round!.time});c.input({button,down:false,round:match.number,at:match.round!.time});
      await flush();await c.sync();await flush();
      const state=await request('host',{code,token:hostToken,match,frame:++frame,ack});
      for(const input of state.inputs??[]){if(input.seq<=(ack[input.playerId]??0))continue;applyControl(match,input.playerId,input.button,input.down,input.heldMs);ack[input.playerId]=input.seq;}
      await request('host',{code,token:hostToken,match,frame:++frame,ack});
    }
    const p=match.round!.players.find(p=>p.id===phone.playerId)!;assert.ok(p.progress>5);assert.ok(p.speed>5);assert.equal(match.round!.players.find(p=>p.id!==phone.playerId)!.progress,0);
    c.input({button:'B',down:true,round:match.number,at:match.round!.time});await flush();await c.sync();await flush();
    const state=await request('host',{code,token:hostToken,match,frame:++frame,ack});
    for(const input of state.inputs??[]){if(input.seq<=(ack[input.playerId]??0))continue;applyControl(match,input.playerId,input.button,input.down,input.heldMs);ack[input.playerId]=input.seq;}
    stepMatch(match,.1);assert.equal(p.phase,'jump');assert.ok(p.height>0);
    await request('host',{code,token:hostToken,match,frame:++frame,ack});
    const received=await request('sync',{code,token:'phone-token'});assert.equal(received.view.match!.round!.players.find(p=>p.id===phone.playerId)!.phase,'jump');
  }finally{c.stop();}
});
