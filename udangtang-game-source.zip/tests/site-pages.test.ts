import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {metadataHTML,pages,renderSiteDocument,sitePage,siteSchema,SITE_URL} from '../src/site-pages.ts';
const template=readFileSync(new URL('../index.html',import.meta.url),'utf8');
test('game-room home exposes both games and preserves sports invitation routing',()=>{
  assert.equal(sitePage(''),'home');assert.equal(sitePage('?game=unknown'),'home');
  assert.equal(sitePage('?game=race'),'race');assert.equal(sitePage('?game=sports&room=ABC123&view=all'),'sports');
  assert.equal(sitePage('?game=olympics'),'sports');
  assert.match(template,/<h1>우당탕 게임룸<\/h1>/);
  assert.match(template,/href="\?game=race"/);assert.match(template,/href="\?game=sports"/);
});
test('server HTML gives crawlers the correct title, canonical, content and single metadata block',()=>{
  for(const page of ['home','race','sports'] as const){
    const html=renderSiteDocument(template,new URL(pages[page].url));
    assert.ok(html.includes(`<title>${pages[page].title}</title>`));
    assert.ok(html.includes(`rel="canonical" href="${pages[page].url}"`));
    assert.equal((html.match(/<title>/g)||[]).length,1);
    assert.equal((html.match(/name="description"/g)||[]).length,1);
    assert.match(html,/name="google-site-verification"/);
    assert.ok(!html.includes('housecats-design.github.io'));
    assert.match(html,page==='home'?/<h1>우당탕 게임룸/:page==='race'?/<h1>우당탕 달리기/:/<h1>우당탕 올림픽/);
  }
});
test('room invitations retain functionality but canonicalize to the public game page',()=>{
  const html=renderSiteDocument(template,new URL(SITE_URL+'?game=sports&room=ABC123&view=mine'));
  assert.match(html,/name="robots" content="noindex,follow"/);
  assert.ok(html.includes(`rel="canonical" href="${pages.sports.url}"`));
  assert.ok(!metadataHTML('sports').includes('ABC123'));
});
test('site name describes the game room and the sitemap includes both games',()=>{
  const schema=siteSchema('home');assert.equal(schema['@graph'][0].name,'우당탕 게임룸');
  const data=JSON.stringify(schema);assert.ok(data.includes('우당탕 달리기'));assert.ok(data.includes('우당탕 올림픽'));
  const sitemap=readFileSync(new URL('../public/sitemap.xml',import.meta.url),'utf8');
  for(const page of Object.values(pages))assert.ok(sitemap.includes(`<loc>${page.url}</loc>`));
  assert.ok(readFileSync(new URL('../public/robots.txt',import.meta.url),'utf8').includes(SITE_URL+'sitemap.xml'));
});
