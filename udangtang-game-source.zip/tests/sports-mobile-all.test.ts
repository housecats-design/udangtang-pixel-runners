import test from 'node:test';
import assert from 'node:assert/strict';
import {SPORTS} from '../src/sports/model.ts';
import {auditMobileSport} from './helpers/sports-mobile-harness.ts';
for(const sport of SPORTS)for(const latency of [0,.12,.25])test(`mobile ${sport.id} via PC room with ${latency*2000}ms RTT`,async()=>{
 const result=await auditMobileSport(sport.id,latency),p=result.player;
 assert.equal(p.finished,true,JSON.stringify(result));
 if(sport.id==='skeet')assert.ok(p.hits>=26,JSON.stringify(result));
 else if(sport.id==='hurdles')assert.ok(p.progress>=100,JSON.stringify(result));
 else if(sport.id==='swimming')assert.equal(p.progress,100,JSON.stringify(result));
 else assert.ok(p.score>0&&p.result!=='도약 실패'&&p.result!=='파울',JSON.stringify(result));
});

test('a phone can complete swimming in a full eight-player room with 240ms RTT',async()=>{
 const r=await auditMobileSport('swimming',.12,8);assert.equal(r.playerCount,8);assert.equal(r.player.progress,100);assert.ok(r.other.progress<10);
});
