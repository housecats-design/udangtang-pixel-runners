import test from 'node:test';
import assert from 'node:assert/strict';
import {createMatch,startRound,stepMatch} from '../src/sports/engine.ts';
import {RemoteTimeline,RemoteClock,projectRemoteMatch,type RemoteInput} from '../src/sports/remote-input.ts';
import type {SportId} from '../src/sports/model.ts';
function playing(sport:SportId){const people=['one','two'].map(id=>({id,name:id,avatar:0,color:'#49c4b2',ready:true,connected:true,total:0}));const m=createMatch(people,[sport]);startRound(m);stepMatch(m,3.1);return m;}
function command(seq:number,button:'A'|'B'|'C',at:number,down=true,heldMs?:number):RemoteInput{return {seq,button,at,down,heldMs,playerId:'one',round:1};}
test('replayed packets and acknowledgement retries never apply one tap twice',()=>{
 const m=playing('hurdles'),timeline=new RemoteTimeline(),ack={};for(let i=0;i<20;i++)timeline.step(m,1/60);
 const inputs=[command(1,'A',.05),command(2,'C',.18)];timeline.receive(m,inputs,ack);
 assert.ok(m.round!.players[0].speed>1.3);assert.equal(m.round!.players[1].speed,0);
 const saved=structuredClone(m);timeline.receive(m,inputs,ack);assert.deepEqual(m,saved);assert.deepEqual(ack,{one:2});
});
test('late takeoff rescues a false vault foul using its original position and held angle',()=>{
 const m=playing('vault'),p=m.round!.players[0];p.phase='run';p.progress=82.5;p.speed=10;
 const timeline=new RemoteTimeline();for(let i=0;i<32;i++)timeline.step(m,1/60);assert.equal(m.round!.players[0].finished,true);
 timeline.receive(m,[command(1,'B',0),command(2,'B',.35556,false,355.56)],{});
 const corrected=m.round!.players[0];assert.equal(corrected.finished,false);assert.ok(['takeoff','horse'].includes(corrected.phase));assert.ok(Math.abs(corrected.angle-52)<.01);
 assert.equal(m.athletes[0].total,0);assert.equal(m.round!.players[1].progress,0);
});
test('history is bounded and old packets are acknowledged without changing the race',()=>{
 const m=playing('hurdles'),timeline=new RemoteTimeline(),ack={};for(let i=0;i<150;i++)timeline.step(m,1/60);
 const saved=structuredClone(m);timeline.receive(m,[command(1,'A',0)],ack);assert.deepEqual(m,saved);assert.deepEqual(ack,{one:1});
});
test('unconfirmed older rotation presses retain their spacing and do not mutate authoritative state',()=>{
 const m=playing('vault'),p=m.round!.players[0];m.round!.time=5;p.phase='air';p.phaseAt=4.5;p.progress=95;p.height=40;
 p.vault={runSpeed:9,launchAngle:52,peak:60,duration:2.6,targetRotation:0};
 const saved=structuredClone(m),view=projectRemoteMatch(m,[command(1,'A',4.8),command(2,'A',4.93),command(3,'A',5.8)],5.2);
 assert.equal(view.round!.players[0].attempts,2);assert.deepEqual(m,saved);
});
test('phone clock never goes backwards between server snapshots and resets for a rematch',()=>{
 const clock=new RemoteClock();assert.equal(clock.read(5,1000,1300),5.3);assert.equal(clock.read(5.1,1400,1400),5.3);
 clock.reset();assert.equal(clock.read(0,2000,2000),0);
});
test('each athlete keeps their own wind after another participant selects a different direction',()=>{
 const m=playing('archery'),timeline=new RemoteTimeline();for(let i=0;i<90;i++)timeline.step(m,1/60);
 timeline.receive(m,[command(1,'A',.2),{...command(1,'A',1.0),playerId:'two'}],{});
 assert.notEqual(m.round!.players[0].quality,m.round!.players[1].quality);
});
