import test from 'node:test';
import assert from 'node:assert/strict';
import {newParticipant} from '../src/data/avatars.ts';
import {load,save,parseSave,defaultSettings,STORAGE_KEY} from '../src/storage/store.ts';
const roster=()=>Array.from({length:35},(_,i)=>newParticipant(i));
test('v2 round trip preserves IDs, duplicates, avatars, distance, rule and sound',()=>{
  const participants=roster();participants[0].name=participants[1].name='같은 이름';let raw='';
  for(const [i,id] of ['rabbit','fox','duck'].entries())participants[i].avatarId=id;
  const settings={...defaultSettings,distanceMeters:1000 as const,winnerRule:'last' as const,soundEnabled:false};
  assert.ok(save({setItem:(key,v)=>{assert.equal(key,STORAGE_KEY);raw=v;}},participants,settings));
  assert.deepEqual(parseSave(raw),{schemaVersion:2,participants,settings});
});
test('v1 time settings migrate to 300m while all names, IDs, avatars and preferences survive',()=>{
  const participants=roster();const old={schemaVersion:1,participants,settings:{durationSeconds:300,winnerRule:'last',soundEnabled:false}};
  const migrated=parseSave(JSON.stringify(old))!;assert.equal(migrated.schemaVersion,2);assert.deepEqual(migrated.participants,participants);
  assert.deepEqual(migrated.settings,{distanceMeters:300,winnerRule:'last',soundEnabled:false});
});
test('only 300m, 500m and 1km are accepted as saved distance choices',()=>{
  for(const distance of [300,500,1000])assert.ok(parseSave(JSON.stringify({schemaVersion:2,participants:roster(),settings:{...defaultSettings,distanceMeters:distance}})));
  for(const distance of [0,301,1500,NaN,'300',null])assert.equal(parseSave(JSON.stringify({schemaVersion:2,participants:roster(),settings:{...defaultSettings,distanceMeters:distance}})),null);
});
test('corrupt/incompatible saves and duplicate IDs are rejected',()=>{
  for(const raw of ['{','null','{}',JSON.stringify({schemaVersion:3})])assert.equal(parseSave(raw),null);
  const p=roster();p[1].id=p[0].id;assert.equal(parseSave(JSON.stringify({schemaVersion:2,participants:p,settings:defaultSettings})),null);
});
test('blocked storage and quota errors do not crash the current session',()=>{
  assert.deepEqual(load({getItem:()=>{throw Error('blocked');}}),{data:null,error:true});
  assert.equal(save({setItem:()=>{throw Error('quota');}},roster(),defaultSettings),false);
});
