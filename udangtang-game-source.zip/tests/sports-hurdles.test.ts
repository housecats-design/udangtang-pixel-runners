import test from 'node:test';
import assert from 'node:assert/strict';
import {createMatch,startRound,stepMatch,applyControl} from '../src/sports/engine.ts';
import {HURDLES,HURDLE_CLEARANCE,hurdleHeight,hurdleJumpCue} from '../src/sports/hurdles.ts';

function playing(){const match=createMatch([{id:'one',name:'one',avatar:0,color:'#49c4b2',ready:true,connected:true,total:0}],['hurdles']);startRound(match);stepMatch(match,3.1);return match;}
test('alternating A and C accelerates hurdles more strongly than repeating one button',()=>{
  const a=playing(),b=playing();
  for(let i=0;i<6;i++){
    applyControl(a,'one',i%2?'A':'C',true);applyControl(b,'one','A',true);
    stepMatch(a,.1);stepMatch(b,.1);
  }
  assert.ok(a.round!.players[0].speed>b.round!.players[0].speed*1.5);
  assert.ok(a.round!.players[0].progress>b.round!.players[0].progress);
});
test('ten well-timed hurdle jumps complete the 100m race without collisions',()=>{
  const match=playing(),p=match.round!.players[0];let taps=0;
  for(let frame=0;frame<3600&&!p.finished;frame++){
    if(frame%6===0)applyControl(match,'one',taps++%2?'A':'C',true);
    const next=HURDLES[p.stage];
    if(p.phase==='run'&&next!==undefined&&next-p.progress<=2.6)applyControl(match,'one','B',true);
    stepMatch(match,1/60);
  }
  assert.equal(p.progress,100);assert.equal(p.hits,10);assert.equal(p.attempts,0);assert.ok(p.score>0);
  assert.equal(match.phase,'results');assert.ok(p.finished);
});
test('a late jump knocks down the hurdle once, reduces speed and then recovers',()=>{
  const match=playing(),p=match.round!.players[0];p.progress=12.95;p.speed=10;p.phase='run';
  applyControl(match,'one','B',true);stepMatch(match,.1);
  assert.equal(p.phase,'fall');assert.equal(p.stage,1);assert.deepEqual(p.shots,[0]);assert.ok(p.speed<4);
  const started=match.round!.time;
  for(let i=0;i<70;i++)stepMatch(match,1/60);
  assert.equal(p.phase,'run');assert.deepEqual(p.shots,[0]);assert.ok(match.round!.time-started>=1);
});
test('jump cannot be extended by repeated B presses while airborne',()=>{
  const match=playing(),p=match.round!.players[0];applyControl(match,'one','B',true);
  const takeoff=p.phaseAt;
  for(let frame=0;frame<40;frame++){stepMatch(match,1/60);applyControl(match,'one','B',true);}
  assert.equal(p.phaseAt,takeoff);assert.ok(hurdleHeight(.36)>HURDLE_CLEARANCE);
  for(let frame=0;frame<6;frame++)stepMatch(match,1/60);
  assert.equal(p.phase,'run');assert.equal(p.height,0);
});
test('jump cues adapt to low and high running speeds instead of prompting too early',()=>{
  for(const speed of [2,4,8,10]){
    const match=playing(),p=match.round!.players[0],distance=speed*.3;
    p.progress=13-distance;p.speed=speed;p.phase='run';
    assert.ok(hurdleJumpCue(distance,speed));applyControl(match,'one','B',true);
    for(let i=0;i<45;i++)stepMatch(match,1/60);
    assert.equal(p.hits,1);assert.equal(p.attempts,0);
  }
  assert.equal(hurdleJumpCue(4,2),false);
});
