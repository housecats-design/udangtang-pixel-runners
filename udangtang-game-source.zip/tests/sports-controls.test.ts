import test from 'node:test';
import assert from 'node:assert/strict';
import {bindSportButton} from '../src/sports/controls.ts';
import {createMatch,startRound,stepMatch,applyControl} from '../src/sports/engine.ts';
import type {Control} from '../src/sports/model.ts';
class Button extends EventTarget {captures=0;setPointerCapture(){this.captures++;throw new Error('NotFoundError');}}
function fire(target:EventTarget,type:string,fields:object={}){const e=new Event(type,{cancelable:true});Object.assign(e,fields);target.dispatchEvent(e);return e;}
function touch(target:EventTarget,type:string,id:number){return fire(target,type,{changedTouches:[{identifier:id}]});}
function rig(){const button=new Button(),end=new EventTarget(),events:Array<[Control,boolean]>=[];const dispose=bindSportButton(button as unknown as HTMLButtonElement,'A',(c,d)=>events.push([c,d]),end);return {button,end,events,dispose};}
test('a failed pointer capture cannot swallow the press or release',()=>{
  const {button,end,events,dispose}=rig();fire(button,'pointerdown',{pointerId:1,pointerType:'mouse'});fire(end,'pointerup',{pointerId:1,pointerType:'mouse'});
  assert.deepEqual(events,[['A',true],['A',false]]);dispose();
});
test('Safari touch input works without pointer capture and compatibility events do not duplicate strokes',()=>{
  const {button,events,dispose}=rig();
  fire(button,'pointerdown',{pointerId:1,pointerType:'touch'});touch(button,'touchstart',1);touch(button,'touchend',1);
  fire(button,'pointerup',{pointerId:1,pointerType:'touch'});fire(button,'click',{detail:1});
  assert.equal(button.captures,0);assert.deepEqual(events,[['A',true],['A',false]]);dispose();
});
test('touch pointer events alone support holding B when Touch Events are not provided',()=>{
  const {button,end,events,dispose}=rig();fire(button,'pointerdown',{pointerId:7,pointerType:'touch'});
  assert.deepEqual(events,[['A',true]]);assert.equal(button.captures,0);
  fire(end,'pointerup',{pointerId:7,pointerType:'touch'});fire(button,'click',{detail:1});
  assert.deepEqual(events,[['A',true],['A',false]]);dispose();
});
test('click-only mobile and assistive activation supports repeated A/C presses',()=>{
  const {button,events,dispose}=rig();fire(button,'click',{detail:1});fire(button,'click',{detail:1});fire(button,'click',{detail:0});
  assert.equal(events.filter(([,down])=>down).length,3);assert.equal(events.filter(([,down])=>!down).length,3);dispose();
});
test('multi-touch keeps a button held until its last finger ends, cancellation and blur release it',()=>{
  const {button,end,events,dispose}=rig();touch(button,'touchstart',1);touch(button,'touchstart',2);touch(button,'touchend',1);
  assert.deepEqual(events,[['A',true]]);touch(button,'touchcancel',2);touch(button,'touchstart',3);fire(end,'blur');
  assert.deepEqual(events,[['A',true],['A',false],['A',true],['A',false]]);dispose();
});
test('leaving and restoring the phone page clears held touches so the next tap still fires',()=>{
  const {button,end,events,dispose}=rig();touch(button,'touchstart',1);fire(end,'pagehide');
  touch(button,'touchstart',1);touch(button,'touchend',1);
  assert.deepEqual(events,[['A',true],['A',false],['A',true],['A',false]]);dispose();
});
test('alternating touch events accelerate hurdles and B jumps without affecting another athlete',()=>{
  const people=['phone','other'].map(id=>({id,name:id,avatar:0,color:'#49c4b2',ready:true,connected:true,total:0}));
  const m=createMatch(people,['hurdles']);startRound(m);stepMatch(m,3.1);const end=new EventTarget();
  const buttons=['A','B','C'].map(c=>{const b=new Button();bindSportButton(b as unknown as HTMLButtonElement,c as Control,(control,down)=>applyControl(m,'phone',control,down),end);return b;});
  for(let i=0;i<12;i++){const b=buttons[i%2?2:0];touch(b,'touchstart',i);touch(b,'touchend',i);stepMatch(m,.125);}
  const p=m.round!.players[0];assert.ok(p.speed>5);assert.ok(p.progress>5);assert.equal(m.round!.players[1].progress,0);
  p.phase='run';touch(buttons[1],'touchstart',99);touch(buttons[1],'touchend',99);stepMatch(m,.1);assert.equal(p.phase,'jump');assert.ok(p.height>0);
});
