import test from 'node:test';
import assert from 'node:assert/strict';
import {LANE_COUNT,Race,STEP,inObstacleBand} from '../src/simulation/engine.ts';
import {animals,newParticipant} from '../src/data/avatars.ts';
import {PASS_SECONDS,RIDE_SECONDS,STAMINA_SECONDS,pickLollipopReward,vehicles,type LollipopReward} from '../src/simulation/lollipop.ts';

function quietRace(seed=19,rule:'first'|'last'='first',size=2,distance=300){
  const race=new Race(Array.from({length:size},(_,i)=>newParticipant(i)),distance,seed,rule);
  race.obstacles=[];race.nextBeam=race.nextUfo=race.nextContact=Infinity;
  for(const runner of race.runners){runner.nextSpeed=runner.nextBreak=runner.nextLane=Infinity;runner.speed=runner.target=100;}
  return race;
}

test('catch-up help starts at 50 meters and moves only the last active runner toward the next runner',()=>{
  const race=quietRace(19,'last',3);
  race.nextBeam=1000;
  const [leader,ahead,last]=race.runners;
  leader.x=1600;ahead.x=1000;last.x=501;
  for(const runner of race.runners)runner.speed=runner.target=0;
  race.step();const initialBeam=race.beam;assert.equal(initialBeam,null);
  last.x=500;race.step();
  assert.equal(race.beam?.index,last.index);assert.ok(race.beam?.catchUp);
  race.ufo={index:last.index,warn:1,fire:race.worldTime+STEP,end:race.worldTime+2};
  for(let i=0;i<130;i++)race.step();
  assert.equal(last.status,'running');assert.equal(last.x,930);
  assert.equal(ahead.x,1000);assert.equal(leader.x,1600);
});

test('a catch-up warning is cancelled if the last runner closes the gap before it fires',()=>{
  const race=quietRace();race.nextBeam=1000;
  const [ahead,last]=race.runners;
  ahead.x=1000;last.x=460;
  for(const runner of race.runners)runner.speed=runner.target=0;
  race.step();assert.ok(race.beam?.catchUp);
  last.x=550;
  for(let i=0;i<45;i++)race.step();
  assert.equal(last.transport,null);assert.equal(last.x,550);
});

test('only an actual rank change between the last two unfinished runners signals slow motion',()=>{
  const race=quietRace(19,'last',3);
  const [first,a,b]=race.runners;
  for(const runner of race.runners)runner.speed=runner.target=0;
  first.x=1500;a.x=500;b.x=490;race.step();
  b.x=510;race.step();assert.equal(race.duelOvertake,null);
  first.x=race.finishX;race.step();assert.equal(race.completedCount,1);assert.equal(race.duelOvertake,null);
  a.x=b.x;race.step();assert.equal(race.duelOvertake,null);
  a.x=520;race.step();
  const overtake=race.duelOvertake;
  assert.deepEqual(overtake,{leader:a.index,trailer:b.index});
  race.step();assert.equal(race.duelOvertake,overtake);
  b.x=525;race.step();assert.deepEqual(race.duelOvertake,{leader:b.index,trailer:a.index});
});

test('the speed lollipop gives its exhausted winner 4× base speed for exactly four seconds',()=>{
  const race=quietRace();
  race.worldTime=race.elapsed=3;
  for(const runner of race.runners){runner.x=2100;runner.speed=runner.target=50;}
  race.step();
  const draw=race.lollipop!;
  assert.ok(draw&&!draw.resolved);
  draw.reward='boost';
  assert.ok(race.runners.every(runner=>runner.candyBoostUntil===0));
  const winner=race.runners[draw.winner];
  winner.stamina=0;winner.status='sleeping';winner.until=race.worldTime+2;
  const awardedAt=race.worldTime;
  race.resolveLollipop();race.resolveLollipop();
  assert.equal(winner.candyBoostUntil,awardedAt+4);
  const before=race.runners.map(runner=>runner.x);
  race.step();
  assert.deepEqual(race.runners.map((runner,i)=>Math.round((runner.x-before[i])/STEP)),[0,1].map(i=>i===draw.winner?200:50));
  for(let frame=1;frame<240;frame++)race.step();
  assert.ok(Math.abs(winner.x-before[winner.index]-800)<1e-7);
  assert.equal(winner.stamina,0);
  const stoppedAt=winner.x;race.step();
  assert.equal(winner.status,'sleeping');assert.equal(winner.x,stoppedAt);
  assert.equal(race.events.filter(event=>event.kind==='lollipop-win').length,1);
  assert.equal(race.lollipop,draw);
});

test('a giant footfall pauses other racers, including the remaining time of their reactions',()=>{
  const race=quietRace(66);
  race.lollipop={round:1,winner:0,reward:'blank',variant:0,at:0,resolved:true};race.worldTime=race.elapsed=4;
  for(const runner of race.runners)runner.x=1010;
  race.step();
  const giant=race.giant!;
  assert.ok(giant);
  const big=race.runners[giant.runner],other=race.runners[1-giant.runner];
  for(let i=0;i<60&&!race.isStompFrozen(other.index);i++)race.step();
  assert.ok(race.isStompFrozen(other.index));
  const x=other.x,bigX=big.x,gait=other.gait;
  other.status='frozen';other.statusStarted=race.worldTime;other.until=race.worldTime+1;
  for(let i=0;i<12;i++)race.step();
  assert.equal(other.x,x);assert.equal(other.gait,gait);assert.ok(big.x>bigX);
  assert.ok(Math.abs(other.until-race.worldTime-1)<1e-8);
  for(let i=0;i<500&&race.giant;i++)race.step();
  assert.equal(race.giant,null);assert.ok(other.x>x);
});

for(const rule of ['first','last'] as const)test(`rainbow respects the ${rule} rule even when another runner reaches the line first`,()=>{
  const race=quietRace(43,rule);
  race.lollipop={round:1,winner:0,reward:'blank',variant:0,at:0,resolved:true};race.worldTime=race.elapsed=4;
  for(const runner of race.runners)runner.x=1700;
  race.step();
  const rainbow=race.runners[race.rainbowIndex!],other=race.runners[1-rainbow.index];
  assert.ok(rainbow.rainbow);
  rainbow.x=race.finishX-12;other.x=race.finishX-.1;
  race.step();assert.equal(other.finishTime,null);assert.ok(other.finishHeld);
  for(let i=0;i<60&&!race.finished;i++)race.step();
  assert.ok(race.finished);assert.equal(race.result?.[0],rainbow);
  if(rule==='last')assert.equal(race.lastPlaceIndex,other.index);
});

test('obstacles only hit within their own lane band, reduce stamina once, and fatigue reduces pace',()=>{
  const race=quietRace();const [hit,clear]=race.runners;
  const peel={id:900,x:320,width:26,type:'banana' as const,phase:0,band:{center:.4,span:.11}};
  race.obstacles=[peel];
  for(const runner of [hit,clear]){runner.x=319;runner.attempted.add(peel.id);}
  hit.lane=hit.laneTarget=.4;clear.lane=clear.laneTarget=.7;
  assert.equal(inObstacleBand(peel,clear.lane),false);
  race.step();
  assert.equal(hit.status,'banana-cry');assert.equal(clear.status,'running');
  assert.ok(hit.damageAmount>=10&&hit.damageAmount<=50);assert.equal(clear.damageAmount,0);
  const stamina=hit.stamina;
  for(let i=0;i<20;i++)race.step();
  assert.equal(hit.stamina,stamina);
  const before=clear.x;clear.stamina=.5;race.step();
  assert.ok(clear.x-before<100*STEP*.88);
});

test('the wall catches runners and airborne arrivals in its lanes while the adjacent lanes stay open',()=>{
  const race=new Race(Array.from({length:3},(_,i)=>newParticipant(i)),300,19);
  const wall=race.obstacles.find(obstacle=>obstacle.type==='wall')!;
  race.obstacles=[wall];race.nextBeam=race.nextUfo=race.nextContact=Infinity;
  const [launched,climber,bypass]=race.runners;
  for(const runner of race.runners){
    runner.x=wall.x-8;
    runner.lane=runner.laneTarget=wall.band!.center;
    runner.nextLane=Infinity;
  }
  bypass.lane=bypass.laneTarget=wall.band!.center<.5?.94:.06;
  launched.transport={kind:'beam-forward',from:launched.x,to:wall.x+200,started:-.1,duration:1,height:115,startZ:0};
  launched.status='abducted';
  race.step();
  assert.ok([launched,climber].every(runner=>runner.status==='climbing'&&runner.transport===null));
  assert.equal(bypass.status,'running');
  assert.ok(bypass.x>wall.x-7);
  for(let i=0;i<65;i++)race.step();assert.ok([launched,climber].every(runner=>runner.z>60));
  for(let i=0;i<100;i++)race.step();
  assert.ok(race.runners.every(runner=>runner.status==='running'&&runner.x>wall.x+wall.width));
});

test('each full course includes repeated machinery while leaving open lanes beside every machine and wall',()=>{
  const participants=[newParticipant(0),newParticipant(1)];
  for(const distance of [300,500,1000]){
    for(const seed of [0,1,19,5231,20261110]){
      const race=new Race(participants,distance,seed);
      race.runners[0].x=race.finishX-1600;
      race.step();
      const machines=['spinner','platform','hammer'];
      for(const type of machines)assert.ok(race.obstacles.filter(o=>o.type===type).length>=2,`${distance}m ${seed} ${type}`);
      for(const obstacle of race.obstacles.filter(o=>o.type==='wall'||machines.includes(o.type))){
        const occupied=Array.from({length:LANE_COUNT},(_,lane)=>(lane+.5)/LANE_COUNT)
          .filter(lane=>inObstacleBand(obstacle,lane));
        assert.ok(occupied.length>=1&&occupied.length<=3,`${distance}m ${seed} ${obstacle.type}`);
        assert.ok(obstacle.band!.center-obstacle.band!.span/2>=-1e-9);
        assert.ok(obstacle.band!.center+obstacle.band!.span/2<=1+1e-9);
      }
    }
  }
});

function award(race:Race,reward:LollipopReward,winner=0,variant=0){
  race.lollipop={round:1,winner,reward,variant,at:race.worldTime,resolved:false};
  race.resolveLollipop();
}

test('restart is one of nine lollipop rewards and has a 2% weight',()=>{
  const rewards=Array.from({length:100},(_,i)=>pickLollipopReward((i+.5)/100));
  assert.equal(rewards.filter(reward=>reward==='restart').length,2);
  assert.equal(new Set(rewards).size,9);
});

for(const [distance,total] of [[300,1],[500,2],[1000,2]])test(`${distance}m lollipop starts at 70%, with a second throw at 85% only on longer courses`,()=>{
  const race=quietRace(19,'first',2,distance);race.worldTime=race.elapsed=4;
  for(const runner of race.runners)runner.speed=runner.target=0;
  const leader=race.runners[1];
  assert.equal(race.lollipopRounds,total);
  const firstMark=race.finishX*.70,secondMark=race.finishX*.85;
  leader.x=firstMark-1;race.step();assert.equal(race.lollipop?.round,undefined);
  leader.x=firstMark;race.step();assert.equal(race.lollipop?.round,1);
  race.lollipop!.reward='restart';race.resolveLollipop();
  leader.x=secondMark-1;race.step();assert.equal(race.lollipop?.round,1);
  leader.x=secondMark;race.step();assert.equal(race.lollipop?.round,total);
  race.lollipop!.reward='restart';race.resolveLollipop();
  leader.x=race.finishX-1;race.step();assert.equal(race.lollipop?.round,total);
  assert.equal(race.events.filter(event=>event.kind==='lollipop').length,total);
});

test('restart returns each runner to their shuffled start and clears course attempts and airborne motion',()=>{
  const race=quietRace(19,'last',3);race.worldTime=race.elapsed=6;
  const [a,b,c]=race.runners;
  for(const [i,r] of race.runners.entries()){
    r.x=r.previousX=900-i*150;r.lane=r.laneTarget=.5;r.z=22;
    r.status='climbing';r.handled.add(-1);r.attempted.add(3);r.jumpAt.set(3,200);r.obstacleRetries.set(3,'pending');
  }
  race.beam={index:b.index,mode:'forward',phase:'moving',fire:0,end:8};
  c.status='abducted';c.transport={kind:'beam-back',from:600,to:200,started:5,duration:2,height:115,startZ:0};
  award(race,'restart');
  assert.deepEqual(race.runners.map(r=>[r.x,r.previousX,r.lane,r.status,r.z,r.transport]),race.runners.map(r=>[0,0,r.startLane,'running',0,null]));
  assert.ok(race.runners.every(r=>!r.handled.size&&!r.attempted.size&&!r.jumpAt.size&&!r.obstacleRetries.size));
  assert.equal(a.finishTime,null);assert.equal(race.beam,null);assert.equal(race.elapsed,6);
  assert.equal(race.impacts.filter(i=>i.kind==='roulette').length,3);
});

test('position swap exchanges first and last including lanes while the middle runner stays put',()=>{
  const race=quietRace(19,'last',3);race.worldTime=race.elapsed=6;
  const [middle,last,first]=race.runners;
  middle.x=900;last.x=460;first.x=1300;last.lane=.7;first.lane=.25;
  first.handled.add(44);race.obstacles=[{id:44,x:700,width:50,type:'spring',phase:0}];
  award(race,'swap');
  assert.deepEqual(race.rank().map(r=>[r.index,r.x]),[[last.index,1300],[middle.index,900],[first.index,460]]);
  assert.deepEqual([last.lane,first.lane],[.25,.7]);
  assert.equal(first.obstacleRetries.get(44),'pending');assert.equal(race.duelOvertake,null);
});

test('free pass crosses the wall and ground hazards while infinite stamina protects a separate runner',()=>{
  const race=quietRace(19,'first',3);const [pass,stamina,ordinary]=race.runners;
  const wallRace=new Race(race.runners.map(r=>r.participant),300,19);
  const wall=wallRace.obstacles.find(o=>o.type==='wall')!;
  const [protectedRunner,climber]=wallRace.runners;
  wallRace.obstacles=[wall];wallRace.nextBeam=wallRace.nextContact=wallRace.nextUfo=Infinity;
  for(const r of [protectedRunner,climber]){
    r.x=wall.x-8;
    r.lane=r.laneTarget=wall.band!.center;
  }
  award(wallRace,'pass');wallRace.step();
  assert.equal(protectedRunner.status,'running');assert.ok(protectedRunner.handled.has(wall.id));
  assert.equal(climber.status,'climbing');assert.equal(protectedRunner.obstaclePassUntil,PASS_SECONDS);
  const peel={id:990,x:320,width:26,type:'banana' as const,phase:0};
  race.obstacles=[peel];
  for(const r of race.runners){r.x=319;r.attempted.add(peel.id);r.stamina=.4;}
  award(race,'pass');award(race,'stamina',stamina.index);race.step();
  assert.equal(pass.status,'running');assert.equal(pass.damageAmount,0);
  assert.equal(stamina.status,'banana-cry');assert.equal(stamina.stamina,1);assert.equal(stamina.damageAmount,0);
  assert.equal(stamina.infiniteStaminaUntil,STAMINA_SECONDS);assert.ok(ordinary.stamina<.4);
  race.worldTime=STAMINA_SECONDS;stamina.status='running';race.step();assert.ok(stamina.stamina<1);
});

test('ride and giant prizes use the selected participant and expire on race time',()=>{
  const race=quietRace();const [winner,other]=race.runners;
  award(race,'ride',winner.index,2);race.step();
  assert.equal(winner.ride?.kind,vehicles[2]);assert.equal(winner.ride?.until,RIDE_SECONDS);
  assert.ok(winner.x>other.x*1.4);
  race.worldTime=RIDE_SECONDS;const [before,otherBefore]=[winner.x,other.x];race.step();
  assert.ok(Math.abs((winner.x-before)-(other.x-otherBefore))<1e-8);
  award(race,'giant',winner.index);assert.equal(race.giant?.runner,winner.index);
  race.step(.5);assert.ok(race.isStompFrozen(other.index));
  race.step(6.2);assert.equal(race.giant,null);
});

test('roulette animal form lasts through a later ride, the finish, and the result',()=>{
  const race=quietRace();const [runner,other]=race.runners;
  const selected=runner.participant.avatarId;
  award(race,'animal',runner.index,1);
  assert.equal(other.animal,null);
  assert.match(race.events[0].text,/여우.*경기 끝까지/);
  race.step(10);
  assert.equal(runner.animal,animals[1]);
  award(race,'ride',runner.index,2);
  assert.equal(runner.animal,animals[1]);
  assert.equal(runner.ride?.kind,vehicles[2]);
  race.step(RIDE_SECONDS+1);
  assert.equal(runner.animal,animals[1]);
  runner.x=other.x=race.finishX-1;
  race.step();
  assert.ok(race.finished);
  assert.equal(race.result?.find(r=>r.index===runner.index)?.animal,animals[1]);
  assert.equal(runner.participant.avatarId,selected);
  const nextRace=new Race(race.runners.map(r=>r.participant),300,19);
  assert.equal(nextRace.runners[runner.index].animal,null);
});

test('selected animals start the race in animal form and keep it through a roulette restart',()=>{
  const rabbit={...newParticipant(0),avatarId:'rabbit'};
  const race=new Race([rabbit,newParticipant(1)],300,19);
  assert.equal(race.runners[0].animal,animals[0]);
  race.runners[0].x=800;
  award(race,'restart');
  assert.equal(race.runners[0].x,0);
  assert.equal(race.runners[0].animal,animals[0]);
});
