import test from 'node:test';
import assert from 'node:assert/strict';
import {Race,STEP,inObstacleBand} from '../src/simulation/engine.ts';
import {newParticipant} from '../src/data/avatars.ts';

function quietRace(seed=19,rule:'first'|'last'='first',size=2){
  const race=new Race(Array.from({length:size},(_,i)=>newParticipant(i)),300,seed,rule);
  race.obstacles=[];race.nextBeam=race.nextUfo=race.nextContact=Infinity;
  for(const runner of race.runners){runner.nextSpeed=runner.nextBreak=runner.nextLane=Infinity;runner.speed=runner.target=100;}
  return race;
}

test('catch-up help starts at 50 meters and moves only the last active runner toward the next runner',()=>{
  const race=quietRace(19,'last',3);
  race.nextBeam=1000;
  const [leader,ahead,last]=race.runners;
  leader.x=1600;ahead.x=1000;last.x=501;
  for(const runner of race.runners)runner.speed=runner.target=0;
  race.step();const initialBeam=race.beam;assert.equal(initialBeam,null);
  last.x=500;race.step();
  assert.equal(race.beam?.index,last.index);assert.ok(race.beam?.catchUp);
  race.ufo={index:last.index,warn:1,fire:race.worldTime+STEP,end:race.worldTime+2};
  for(let i=0;i<130;i++)race.step();
  assert.equal(last.status,'running');assert.equal(last.x,930);
  assert.equal(ahead.x,1000);assert.equal(leader.x,1600);
});

test('a catch-up warning is cancelled if the last runner closes the gap before it fires',()=>{
  const race=quietRace();race.nextBeam=1000;
  const [ahead,last]=race.runners;
  ahead.x=1000;last.x=460;
  for(const runner of race.runners)runner.speed=runner.target=0;
  race.step();assert.ok(race.beam?.catchUp);
  last.x=550;
  for(let i=0;i<45;i++)race.step();
  assert.equal(last.transport,null);assert.equal(last.x,550);
});

test('only an actual rank change between the last two unfinished runners signals slow motion',()=>{
  const race=quietRace(19,'last',3);
  const [first,a,b]=race.runners;
  for(const runner of race.runners)runner.speed=runner.target=0;
  first.x=1500;a.x=500;b.x=490;race.step();
  b.x=510;race.step();assert.equal(race.duelOvertake,null);
  first.x=race.finishX;race.step();assert.equal(race.completedCount,1);assert.equal(race.duelOvertake,null);
  a.x=b.x;race.step();assert.equal(race.duelOvertake,null);
  a.x=520;race.step();
  const overtake=race.duelOvertake;
  assert.deepEqual(overtake,{leader:a.index,trailer:b.index});
  race.step();assert.equal(race.duelOvertake,overtake);
  b.x=525;race.step();assert.deepEqual(race.duelOvertake,{leader:b.index,trailer:a.index});
});

test('one lollipop award gives its exhausted winner 4× base speed for exactly four seconds',()=>{
  const race=quietRace();
  race.worldTime=race.elapsed=3;
  for(const runner of race.runners)runner.x=630;
  race.step();
  const draw=race.lollipop!;
  assert.ok(draw&&!draw.resolved);
  assert.ok(race.runners.every(runner=>runner.candyBoostUntil===0));
  const winner=race.runners[draw.winner];
  winner.stamina=0;winner.status='sleeping';winner.until=race.worldTime+2;
  const awardedAt=race.worldTime;
  race.resolveLollipop();race.resolveLollipop();
  assert.equal(winner.candyBoostUntil,awardedAt+4);
  const before=race.runners.map(runner=>runner.x);
  race.step();
  assert.deepEqual(race.runners.map((runner,i)=>Math.round((runner.x-before[i])/STEP)),[0,1].map(i=>i===draw.winner?400:100));
  for(let frame=1;frame<240;frame++)race.step();
  assert.ok(Math.abs(winner.x-before[winner.index]-1600)<1e-7);
  assert.equal(winner.stamina,0);
  const stoppedAt=winner.x;race.step();
  assert.equal(winner.status,'sleeping');assert.equal(winner.x,stoppedAt);
  assert.equal(race.events.filter(event=>event.kind==='lollipop-win').length,1);
  assert.equal(race.lollipop,draw);
});

test('a giant footfall pauses other racers, including the remaining time of their reactions',()=>{
  const race=quietRace(66);
  race.lollipop={winner:0,resolved:true};race.worldTime=race.elapsed=4;
  for(const runner of race.runners)runner.x=1010;
  race.step();
  const giant=race.giant!;
  assert.ok(giant);
  const big=race.runners[giant.runner],other=race.runners[1-giant.runner];
  for(let i=0;i<60&&!race.isStompFrozen(other.index);i++)race.step();
  assert.ok(race.isStompFrozen(other.index));
  const x=other.x,bigX=big.x,gait=other.gait;
  other.status='frozen';other.statusStarted=race.worldTime;other.until=race.worldTime+1;
  for(let i=0;i<12;i++)race.step();
  assert.equal(other.x,x);assert.equal(other.gait,gait);assert.ok(big.x>bigX);
  assert.ok(Math.abs(other.until-race.worldTime-1)<1e-8);
  for(let i=0;i<500&&race.giant;i++)race.step();
  assert.equal(race.giant,null);assert.ok(other.x>x);
});

for(const rule of ['first','last'] as const)test(`rainbow respects the ${rule} rule even when another runner reaches the line first`,()=>{
  const race=quietRace(43,rule);
  race.lollipop={winner:0,resolved:true};race.worldTime=race.elapsed=4;
  for(const runner of race.runners)runner.x=1700;
  race.step();
  const rainbow=race.runners[race.rainbowIndex!],other=race.runners[1-rainbow.index];
  assert.ok(rainbow.rainbow);
  rainbow.x=race.finishX-12;other.x=race.finishX-.1;
  race.step();assert.equal(other.finishTime,null);assert.ok(other.finishHeld);
  for(let i=0;i<60&&!race.finished;i++)race.step();
  assert.ok(race.finished);assert.equal(race.result?.[0],rainbow);
  if(rule==='last')assert.equal(race.lastPlaceIndex,other.index);
});

test('obstacles only hit within their own lane band, reduce stamina once, and fatigue reduces pace',()=>{
  const race=quietRace();const [hit,clear]=race.runners;
  const peel={id:900,x:320,width:26,type:'banana' as const,phase:0,band:{center:.4,span:.11}};
  race.obstacles=[peel];
  for(const runner of [hit,clear]){runner.x=319;runner.attempted.add(peel.id);}
  hit.lane=hit.laneTarget=.4;clear.lane=clear.laneTarget=.7;
  assert.equal(inObstacleBand(peel,clear.lane),false);
  race.step();
  assert.equal(hit.status,'banana-cry');assert.equal(clear.status,'running');
  assert.ok(hit.damageAmount>=10&&hit.damageAmount<=50);assert.equal(clear.damageAmount,0);
  const stamina=hit.stamina;
  for(let i=0;i<20;i++)race.step();
  assert.equal(hit.stamina,stamina);
  const before=clear.x;clear.stamina=.5;race.step();
  assert.ok(clear.x-before<100*STEP*.88);
});

test('the wall makes every lane climb and also catches a racer launched forward',()=>{
  const race=new Race(Array.from({length:3},(_,i)=>newParticipant(i)),300,19);
  const wall=race.obstacles.find(obstacle=>obstacle.type==='wall')!;
  race.obstacles=[wall];race.nextBeam=race.nextUfo=race.nextContact=Infinity;
  for(const runner of race.runners)runner.x=wall.x-8;
  const launched=race.runners[0];
  launched.transport={kind:'beam-forward',from:launched.x,to:wall.x+200,started:-.1,duration:1,height:115,startZ:0};
  launched.status='abducted';
  race.step();
  assert.ok(race.runners.every(runner=>runner.status==='climbing'&&runner.transport===null));
  for(let i=0;i<65;i++)race.step();assert.ok(race.runners.every(runner=>runner.z>60));
  for(let i=0;i<100;i++)race.step();
  assert.ok(race.runners.every(runner=>runner.status==='running'&&runner.x>wall.x+wall.width));
});
