import test from 'node:test';
import assert from 'node:assert/strict';
import {createMatch,startRound,stepMatch,applyControl,nextRound} from '../src/sports/engine.ts';
import {SPORTS,PLAYER_COLORS,type Athlete,type SportId} from '../src/sports/model.ts';
import {roomApi,type Database} from '../server/rooms.ts';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
function athlete(id='one'):Athlete {return {id,name:id,avatar:0,color:PLAYER_COLORS[0],ready:true,connected:true,total:0};}
function playing(sport:SportId) {const match=createMatch([athlete()], [sport]);startRound(match);stepMatch(match,3.1);return match;}
for(const sport of SPORTS)test(`${sport.id} finishes without input and records total points once`,()=>{
  const match=playing(sport.id);
  for(let i=0;i<4000&&match.phase==='playing';i++)stepMatch(match,1/60);
  assert.equal(match.phase,'results');assert.ok(match.round!.players[0].finished);
  const total=match.athletes[0].total;
  stepMatch(match,30);assert.equal(match.athletes[0].total,total);
  nextRound(match);assert.equal(match.phase,'finished');
});
test('swimming responds to alternating strokes and B restores breath only at the cue',()=>{
  const match=playing('swimming'),player=match.round!.players[0];
  for(let i=0;i<50;i++) {stepMatch(match,.1);if(player.oxygen<=.32)applyControl(match,'one','B',true);applyControl(match,'one',i%2?'A':'C',true);}
  assert.ok(player.speed>5&&player.progress>20);
  player.oxygen=.1;applyControl(match,'one','B',true);assert.equal(player.oxygen,1);
});
test('skeet allows one shot per target and hits only inside the time window',()=>{
  const match=playing('skeet'),player=match.round!.players[0];
  for(const [i,target] of match.round!.skeetTargets!.slice(0,2).entries()){
    match.round!.time=target.hitAt;const button=target.side===0?'A':'C';
    applyControl(match,'one',button,true);applyControl(match,'one',button,true);assert.equal(player.hits,i+1);
  }
});
test('hold and release angle is preserved when both network messages arrive together',()=>{
  const match=playing('archery'),player=match.round!.players[0];
  applyControl(match,'one','A',true);applyControl(match,'one','B',true);applyControl(match,'one','B',false,1812.5);
  assert.equal(player.angle,5.25);assert.equal(player.attempts,1);assert.ok(player.score>=900);
});
test('only the identified athlete reacts and countdown cannot accept controls',()=>{
  const match=createMatch([athlete('one'),athlete('two')],['swimming']);startRound(match);
  applyControl(match,'one','A',true);assert.equal(match.round!.players[0].speed,0);
  stepMatch(match,3.1);applyControl(match,'two','A',true);
  assert.equal(match.round!.players[0].speed,0);assert.ok(match.round!.players[1].speed>0);
});
function database():Database {
  const sqlite=new DatabaseSync(':memory:');
  for(const file of readdirSync('drizzle').filter(file=>file.endsWith('.sql')))sqlite.exec(readFileSync('drizzle/'+file,'utf8'));
  return {prepare(sql:string) {
    let values:unknown[]=[];
    const statement={bind(...args:unknown[]){values=args;return statement;},async first<T>() {return (sqlite.prepare(sql).get(...values as any[])??null) as T|null;},
      async all<T>() {return {results:sqlite.prepare(sql).all(...values as any[]) as T[]};},async run(){return sqlite.prepare(sql).run(...values as any[]);}};
    return statement;
  }};
}
test('online rooms enforce eight slots, host authorization, concurrent joins, and exactly-once input delivery',async()=>{
  const db=database();
  async function request(action:string,body:object) {
    const response=await roomApi(new Request('https://sports.test/sports-api/'+action,{method:'POST',body:JSON.stringify(body)}),db);
    return {status:response.status,data:await response.json() as any};
  }
  const hostToken='host-secret-token'.repeat(3);
  const {data:{code}}=await request('create',{token:hostToken});
  const joins=await Promise.all(Array.from({length:8},(_,i)=>request('join',{code,token:'player-token-'+i,name:'친구 '+i,avatar:i%8})));
  assert.ok(joins.every(join=>join.status===200));
  assert.equal((await request('join',{code,token:'extra',name:'초과'})).status,409);
  assert.equal((await request('host',{code,token:'wrong'})).status,403);
  const host=await request('host',{code,token:hostToken});
  assert.equal(host.data.view.athletes.length,8);
  assert.equal(JSON.stringify(host.data).includes('tokenHash'),false);
  const match=createMatch(host.data.view.athletes,['swimming']);startRound(match);stepMatch(match,3.1);
  const multiple=createMatch(host.data.view.athletes,['swimming','archery']);startRound(multiple);
  assert.equal((await request('host',{code,token:hostToken,match:multiple,frame:1})).status,400);
  assert.equal((await request('host',{code,token:hostToken,match,frame:1})).status,200);
  const input={seq:1,button:'A',down:true,round:match.number};
  await request('sync',{code,token:'player-token-0',inputs:[input,input]});
  const queued=await request('host',{code,token:hostToken});
  assert.equal(queued.data.inputs.length,1);
  const playerId=joins[0].data.playerId;
  const acked=await request('host',{code,token:hostToken,ack:{[playerId]:1}});
  assert.equal(acked.data.inputs.length,0);
  await request('sync',{code,token:'player-token-0',inputs:[input]});
  assert.equal((await request('host',{code,token:hostToken})).data.inputs.length,0);
  const watch=await request('watch',{code});assert.equal(watch.status,200);
  const skeet=createMatch(host.data.view.athletes,['skeet']);startRound(skeet);stepMatch(skeet,3.1);
  assert.equal((await request('host',{code,token:hostToken,match:skeet,frame:2})).status,200);
  const spectator=await request('watch',{code});
  const participant=await request('sync',{code,token:'player-token-0'});
  assert.deepEqual(spectator.data.view.match.round.skeetTargets,skeet.round!.skeetTargets);
  assert.deepEqual(participant.data.view.match.round.skeetTargets,skeet.round!.skeetTargets);
});
test('vault, triple jump, weightlifting and pole vault all have reachable successful results',()=>{
  for(const sport of ['vault','triple','weightlifting','pole'] as const) {
    const match=playing(sport),player=match.round!.players[0];
    let pulses=0;
    for(let frame=0;frame<3000&&!player.finished;frame++) {
      const t=match.round!.time;
      const phaseAge=t-player.phaseAt;
      const tap=()=>applyControl(match,'one',pulses++%2?'A':'C',true);
      if(sport==='vault') {
        if(player.phase==='ready'||player.phase==='run'){
          if(frame%5===0)tap();
          if(player.progress>=76)applyControl(match,'one','B',true);
        }else if(player.phase==='angle'&&phaseAge>=.3556)applyControl(match,'one','B',false,355.56);
        else if(player.phase==='air'&&frame%6===0&&player.attempts<8)applyControl(match,'one','A',true);
      } else if(sport==='triple') {
        if(player.phase==='ready'||player.phase==='run') {
          if(frame%5===0)tap();
          if(player.progress>=76)applyControl(match,'one','B',true);
        } else if(player.phase==='step')applyControl(match,'one','B',true);
        else if(player.phase==='angle')applyControl(match,'one','B',false,[35,41,45][player.stage]/45*1000);
      } else if(sport==='weightlifting') {
        if(player.phase==='ready')applyControl(match,'one','B',true);
        else {if(frame%5===0)tap();if(player.phase==='lift'&&player.power>=.8)applyControl(match,'one','B',true);}
      } else {
        if(player.phase==='ready'||player.phase==='run') {
          if(frame%5===0)tap();
          if(player.progress>=79)applyControl(match,'one','B',true);
        } else if(player.phase==='bend'&&phaseAge>=1.15)applyControl(match,'one','B',false,1150);
      }
      stepMatch(match,1/60);
    }
    assert.ok(player.finished,sport+' must finish');
    assert.ok(player.score>0,sport+' must be winnable');
  }
});
