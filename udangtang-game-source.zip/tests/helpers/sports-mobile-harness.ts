import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {bindSportButton} from '../../src/sports/controls.ts';
import {RoomConnection,type SyncReply} from '../../src/sports/connection.ts';
import {applyRemoteInputs,RemoteTimeline,projectRemoteMatch,RemoteClock} from '../../src/sports/remote-input.ts';
import {createMatch,startRound,stepMatch} from '../../src/sports/engine.ts';
import {roomApi,type Database} from '../../server/rooms.ts';
import type {Control,Match,SportId} from '../../src/sports/model.ts';
import {createSkeetCourse} from '../../src/sports/skeet.ts';
import {HURDLES,hurdleJumpCue} from '../../src/sports/hurdles.ts';
const flush=()=>new Promise<void>(resolve=>setImmediate(resolve));
class Button extends EventTarget{setPointerCapture(){throw new Error('Safari capture not available');}}
function fire(target:EventTarget,type:string,id:number){const e=new Event(type,{cancelable:true});Object.assign(e,{changedTouches:[{identifier:id}]});target.dispatchEvent(e);}
export async function auditMobileSport(sport:SportId,latency:number,participants=2){
 const sqlite=new DatabaseSync(':memory:');for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')))sqlite.exec(readFileSync('drizzle/'+f,'utf8'));
 const db:Database={prepare(sql){let values:unknown[]=[];const s={bind(...args:unknown[]){values=args;return s;},async first<T>(){return (sqlite.prepare(sql).get(...values as any[])??null) as T|null;},async all<T>(){return {results:sqlite.prepare(sql).all(...values as any[]) as T[]};},async run(){return sqlite.prepare(sql).run(...values as any[]);}};return s;}};
 async function request(action:string,body:Record<string,unknown>){const r=await roomApi(new Request('https://sports.test/sports-api/'+action,{method:'POST',body:JSON.stringify(body)}),db);assert.equal(r.status,200,await r.clone().text());return await r.json() as SyncReply&{code:string};}
 const token='mobile-audit-host-token'.repeat(3),{code}=await request('create',{token});
 const joined=await request('join',{code,token:'phone-token',name:'휴대폰',avatar:0});
 for(let i=1;i<participants;i++)await request('join',{code,token:'other-token-'+i,name:'입력 없는 선수 '+i,avatar:i%8});
 const match=createMatch((await request('host',{code,token})).view.athletes,[sport]);startRound(match);if(sport==='skeet')match.round!.skeetTargets=createSkeetCourse(73019);stepMatch(match,3.1);
 let frame=1,clock=0,lastReply=0,view:Match|null=null,lastPoll=-1,lastHost=-1;
 const timeline=new RemoteTimeline(),clientClock=new RemoteClock();
 const ack:Record<string,number>={},down=new Map<Control,number>(),releaseAt=new Map<Control,number>(),sent=new Set<number>();
 const network:Array<{at:number;run:()=>Promise<void>|void}>=[];
 await request('host',{code,token,match,frame});
 const connection=new RoomConnection({code,token:'phone-token',role:'player',playerId:joined.playerId!},(action,body)=>new Promise((resolve,reject)=>{
  const serialized=structuredClone(body);
  network.push({at:clock+latency,run:async()=>{try{const reply=await request(action,serialized);network.push({at:clock+latency,run:()=>resolve(reply)});}catch(e){reject(e);}}});
 }));
 connection.onState=reply=>{view=structuredClone(reply.view.match);lastReply=clock*1000;};
 let transportError='';connection.onError=message=>{transportError=message;};
 const windowTarget=new EventTarget(),buttons=new Map<Control,Button>(),disposers:Array<()=>void>=[];
 for(const control of ['A','B','C'] as Control[]){const button=new Button();buttons.set(control,button);disposers.push(bindSportButton(button as unknown as HTMLButtonElement,control,(button,pressed)=>{
  if(!view||view.phase!=='playing')return;
  const heldMs=pressed?undefined:(clock-(down.get(button)??clock))*1000;
  if(pressed)down.set(button,clock);else down.delete(button);
  connection.input({button,down:pressed,heldMs,round:view.number,at:clientClock.read(view.round!.time,lastReply,clock*1000)});
 },windowTarget));}
 const touch=(button:Control,held=.04)=>{if(down.has(button))return;fire(buttons.get(button)!,'touchstart',(['A','B','C'].indexOf(button)+1));releaseAt.set(button,clock+held);};
 let pulses=0,nextPulse=0,windChosen=false,archeryShots=0,phaseLog=new Set<string>();
 try{
  connection.start();
  for(let tick=0;tick<3800;tick++){
   clock=tick/60;timeline.step(match,1/60);
   for(let i=0;i<network.length;){if(network[i].at>clock+1e-8){i++;continue;}const task=network.splice(i,1)[0];await task.run();}
   await flush();
   if(clock-lastPoll>=.1-1e-8){lastPoll=clock;void connection.sync();}
   if(clock-lastHost>=.1-1e-8){lastHost=clock;const reply=await request('host',{code,token,match,frame:++frame,ack});applyRemoteInputs(match,reply.inputs??[],ack,timeline);}
   for(const [button,at] of releaseAt)if(clock>=at-1e-8){fire(buttons.get(button)!,'touchend',(['A','B','C'].indexOf(button)+1));releaseAt.delete(button);}
   const rawView=view as Match|null;
   const displayed=rawView?projectRemoteMatch(rawView,connection.unconfirmed,clientClock.read(rawView.round!.time,lastReply,clock*1000)):null,p=displayed?.round?.players.find(p=>p.id===joined.playerId);
   const authoritative=match.round!.players.find(p=>p.id===joined.playerId)!;if(authoritative.finished&&clock-(authoritative.finishAt??clock)>1.6)break;
   if(!p||displayed?.phase!=='playing')continue;
   phaseLog.add(p.phase);
   const alternate=()=>{if(clock>=nextPulse){touch(pulses++%2?'C':'A');nextPulse=clock+.125;}};
   if(sport==='swimming'){
    if(p.oxygen<=.32||p.phase==='gasping')touch('B');alternate();
   }else if(sport==='skeet'){
    const t=displayed.round!.time;
    for(const target of displayed.round!.skeetTargets!)if(t>=target.hitAt&&!sent.has(target.id)){sent.add(target.id);touch(target.side===0?'A':'C');}
   }else if(sport==='vault'){
    if(p.phase==='ready'||p.phase==='run'){alternate();if(p.progress>=76)touch('B',(52-20)/90);}
    if(p.phase==='air'&&p.attempts<8&&clock>=nextPulse){touch('A');nextPulse=clock+.125;}
   }else if(sport==='archery'){
    if(!windChosen&&p.phase==='ready'){touch('A');windChosen=true;}
    else if(p.phase==='aim'&&p.aimAt===null&&p.attempts>=archeryShots&&(!p.arrow||displayed.round!.time-p.arrow.at>=1.1)&&!down.has('B')){touch('B',.5+5.25/4);archeryShots=p.attempts+1;}
   }else if(sport==='triple'){
    if(p.phase==='ready'||p.phase==='run'){alternate();if(p.progress>=76)touch('B',35/45);}
    else if(p.phase==='step')touch('B',[35,41,45][p.stage]/45);
   }else if(sport==='weightlifting'){
    if(p.phase==='ready')touch('B');else{alternate();if(p.phase==='lift'&&p.power>=.8)touch('B');}
   }else if(sport==='pole'){
    if(p.phase==='ready'||p.phase==='run'){alternate();if(p.progress>=79)touch('B',1.15);}
   }else{
    alternate();if(hurdleJumpCue((HURDLES[p.stage]??Infinity)-p.progress,p.speed)&&p.phase==='run')touch('B');
   }
  }
  assert.equal(transportError,'');
  await request('host',{code,token,match,frame:++frame,ack});
  const final=await request('sync',{code,token:'phone-token'}),spectator=await request('watch',{code});
  const p=match.round!.players.find(p=>p.id===joined.playerId)!;
  assert.deepEqual(final.view.match!.round!.players.find(p=>p.id===joined.playerId),p);
  assert.deepEqual(spectator.view.match!.round!.players.find(p=>p.id===joined.playerId),p);
  return {player:structuredClone(p),other:structuredClone(match.round!.players.find(p=>p.id!==joined.playerId)!),phases:[...phaseLog],latency,sport,playerCount:match.athletes.length};
 }finally{connection.stop();for(const dispose of disposers)dispose();sqlite.close();}
}
