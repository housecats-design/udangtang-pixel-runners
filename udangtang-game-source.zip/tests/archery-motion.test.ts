import test from 'node:test';
import assert from 'node:assert/strict';
import {archeryPose,archeryDemo,ARCHERY_LOAD_SECONDS,ARCHERY_SHOT_COOLDOWN} from '../src/sports/archery.ts';
import {applyControl,createMatch,startRound,stepMatch} from '../src/sports/engine.ts';

test('archer nocks before holding the drawn bow, even through a long or serialized B hold',()=>{
  const p={aimAt:1};
  const frames=[0,.1,.2,.3,.4].map(age=>archeryPose(p,1+age));
  assert.ok(frames.every(p=>p.clip==='loading'));
  assert.ok(frames[0].frame<frames.at(-1)!.frame);
  for(const t of [1.5,2.8,5.4,100]){
    const pose=archeryPose(JSON.parse(JSON.stringify(p)),t);
    assert.equal(pose.clip,'aiming');assert.ok(pose.frame>=8&&pose.frame<=12,'held B cannot enter release frames');
  }
});
function playing(){
  const people=['one','two'].map((id,i)=>({id,name:id,avatar:i,color:'#49c4b2',ready:true,connected:true,total:0}));
  const m=createMatch(people,['archery']);startRound(m);stepMatch(m,3.1);return m;
}
test('early B release cancels the nocking motion without playing a shot',()=>{
  const m=playing(),p=m.round!.players[0];applyControl(m,p.id,'A',true);applyControl(m,p.id,'B',true);
  stepMatch(m,ARCHERY_LOAD_SECONDS-.1);assert.equal(p.angle,0);
  applyControl(m,p.id,'B',false,400);
  assert.equal(p.attempts,0);assert.equal(p.arrow,undefined);
  assert.equal(archeryPose(p,m.round!.time).clip,'ready');
});
test('B release starts the generated release exactly at the real shot and preserves score and cooldown',()=>{
  const m=playing(),r=m.round!,p=r.players[0];applyControl(m,p.id,'A',true);p.quality=0;
  applyControl(m,p.id,'B',true);stepMatch(m,1.8125);applyControl(m,p.id,'B',false,1812.5);
  assert.equal(p.arrow!.angle,5.25);assert.equal(p.arrow!.points,10);assert.equal(p.score,1000);
  const shotAt=p.arrow!.at;
  assert.equal(archeryPose(p,shotAt).clip,'release');assert.equal(archeryPose(p,shotAt).frame,13);
  assert.equal(archeryPose(p,shotAt+.3).clip,'recover');assert.equal(archeryPose(p,shotAt+.5).clip,'ready');
  assert.equal(archeryPose(r.players[1],shotAt).clip,'ready');
  stepMatch(m,.6);applyControl(m,p.id,'B',true);assert.equal(p.aimAt,null);
  stepMatch(m,ARCHERY_SHOT_COOLDOWN);applyControl(m,p.id,'B',true);assert.notEqual(p.aimAt,null);
  assert.equal(archeryPose(p,r.time).clip,'loading');assert.equal(p.attempts,1);
});
test('landing page preview uses the same load, aim and actual release segments',()=>{
  const clips=new Set<string>();
  for(let t=0;t<9;t+=.025){const pose=archeryPose(archeryDemo(t),t);clips.add(pose.clip);assert.ok(Number.isInteger(pose.frame)&&pose.frame>=0&&pose.frame<=16);}
  assert.deepEqual([...clips].sort(),['aiming','loading','ready','recover','release']);
});
