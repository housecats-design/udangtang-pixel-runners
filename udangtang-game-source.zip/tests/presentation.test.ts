import test from 'node:test';
import assert from 'node:assert/strict';
import {groundPosition,reactionLimbs,tumblePose} from '../src/rendering/motion.ts';
import {Race} from '../src/simulation/engine.ts';
import {newParticipant} from '../src/data/avatars.ts';
const roster=()=>Array.from({length:35},(_,i)=>newParticipant(i));
test('knocked-down pose tips, holds, then rises in time to run again',()=>{
  const start=tumblePose('fallen',0,1.4);
  const down=tumblePose('fallen',.4,1.4);
  const rise=tumblePose('fallen',1.15,1.4);
  const upright=tumblePose('fallen',1.4,1.4);
  assert.ok(down.angle>1.5&&down.centerY>start.centerY);
  assert.ok(rise.angle>0&&rise.angle<down.angle&&rise.centerY<down.centerY);
  assert.ok(Math.abs(upright.angle-start.angle)<1e-9);
  assert.equal(upright.centerY,start.centerY);
  const pit=tumblePose('falling',1.2,1.25);
  assert.ok(pit.centerY>0&&pit.opacity<.1&&pit.scale<.5);
  const landing=tumblePose('respawn',0,.42),recovered=tumblePose('respawn',.42,.42);
  assert.ok(landing.angle>0&&landing.centerY>recovered.centerY);
  assert.equal(recovered.angle,0);
});
test('limbs flail independently and the flying kick extends and retracts a leg',()=>{
  const flight=reactionLimbs('flight',0,1),nextFlight=reactionLimbs('flight',.1,1);
  assert.notEqual(flight[0][3],nextFlight[0][3]);assert.notEqual(flight[2][3],nextFlight[2][3]);
  assert.notEqual(reactionLimbs('fall',.15,1.4)[1][3],reactionLimbs('fall',.28,1.4)[1][3]);
  const takeoff=reactionLimbs('kick',0,.83),strike=reactionLimbs('kick',.37,.83),land=reactionLimbs('kick',.83,.83);
  assert.ok(strike[3][2]-takeoff[3][2]>15);assert.deepEqual(takeoff,land);
});
test('runners now travel over 100 pixels per second while race time stays real time',()=>{
  const race=new Race(roster(),300,73);for(let i=0;i<60;i++)race.step();
  assert.ok(Math.abs(race.elapsed-1)<1e-9);assert.ok(race.runners.every(r=>r.x>100));
});
test('vertical weaving stays in bounds, varies by character and freezes at a stopped distance',()=>{
  for(const count of [2,8,35])for(let i=0;i<count;i++){
    const samples=Array.from({length:100},(_,j)=>groundPosition(i,count,j*15,257,386,42));
    assert.ok(samples.every(y=>y>=257&&y<=386));assert.ok(Math.max(...samples)-Math.min(...samples)>8);
  }
  assert.equal(groundPosition(5,35,250,257,386,42),groundPosition(5,35,250,257,386,42));
  assert.notEqual(groundPosition(5,35,250,257,386,42),groundPosition(15,35,250,257,386,42));
});
test('display motion does not change RNG, physical heights, progress or ranking',()=>{
  const race=new Race(roster(),300,642);for(let i=0;i<1000;i++)race.step();
  const before=race.runners.map(r=>[r.x,r.z,r.rng]);const rank=race.rank().map(r=>r.index);
  for(let frame=0;frame<60;frame++)for(const r of race.runners)groundPosition(r.index,35,r.x,257,386,race.seed);
  assert.deepEqual(race.runners.map(r=>[r.x,r.z,r.rng]),before);assert.deepEqual(race.rank().map(r=>r.index),rank);
});
