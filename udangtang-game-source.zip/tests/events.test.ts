import test from 'node:test';
import assert from 'node:assert/strict';
import {BOOST_SECONDS,Race,STEP,type Runner} from '../src/simulation/engine.ts';
import {newParticipant} from '../src/data/avatars.ts';
const roster=(n=2)=>Array.from({length:n},(_,i)=>newParticipant(i));
function quietRace(n=2,rule:'first'|'last'='first',seed=29){
  const race=new Race(roster(n),300,seed,rule);race.obstacles=[];race.nextUfo=race.nextBeam=Infinity;
  for(const r of race.runners){r.nextBreak=r.nextSpeed=Infinity;r.speed=r.target=0;}
  return race;
}
function untilReleased(race:Race,r:Runner){for(let i=0;i<600&&r.status!=='running';i++)race.step();assert.equal(r.status,'running');}
for(const [retrySeed,relaunch] of [[0,true],[1,false]] as const)test(`a reverse spring ${relaunch?'launches again':'lets the runner pass'} after one return roll`,()=>{
  const race=quietRace();const r=race.runners[0];r.x=500;r.speed=r.target=125;r.rng=1;r.retryRng=retrySeed;
  race.runners[1].x=350;race.obstacles=[{id:900,x:500,width:54,type:'spring',phase:0}];
  assert.equal(race.rank()[0].index,0);race.step();assert.equal(r.status,'launched');assert.ok(r.handled.has(900));
  for(let i=0;i<35;i++)race.step();assert.ok(r.z>50);assert.ok(r.x<500);
  untilReleased(race,r);assert.ok(r.x>=0&&r.x<350);assert.equal(race.rank()[0].index,1);
  assert.equal(r.retryRng,retrySeed);
  r.x=499;race.step();assert.equal(r.status,relaunch?'launched':'running');
  const consumed=r.retryRng;assert.notEqual(consumed,retrySeed);
  for(let i=0;i<12;i++)race.step();assert.equal(r.retryRng,consumed);
});
test('a checkpoint return can trigger the same platform again during recovery protection',()=>{
  const race=quietRace();const runner=race.runners[0];
  race.obstacles=[{id:900,x:100,width:92,type:'platform',phase:0}];
  runner.x=100;runner.speed=runner.target=155;runner.attempted.add(900);runner.retryRng=0;
  race.step();assert.equal(runner.status,'falling');
  untilReleased(race,runner);assert.ok(runner.x<10);
  for(let i=0;i<60&&race.runners[0].status==='running';i++)race.step();
  assert.equal(runner.status,'falling');assert.notEqual(runner.retryRng,0);
});
test('a backward beam restores a previously passed hazard’s chance to trigger',()=>{
  const race=quietRace();const runner=race.runners[0];
  race.obstacles=[{id:900,x:500,width:26,type:'banana',phase:0}];
  runner.x=600;runner.handled.add(900);runner.retryRng=0;
  race.beam={index:0,mode:'back',phase:'warning',fire:.01,end:4};
  race.step();assert.equal(runner.status,'abducted');
  untilReleased(race,runner);assert.ok(runner.x<500);
  runner.speed=runner.target=125;
  for(let i=0;i<300&&race.runners[0].status==='running';i++)race.step();
  assert.equal(runner.status,'banana-cry');
});
for(const mode of ['back','forward'] as const)test(`tractor beam ${mode} changes actual rank and clears after landing`,()=>{
  const race=quietRace();const r=race.runners[0];r.x=600;race.runners[1].x=mode==='forward'?700:500;
  race.beam={index:0,mode,phase:'warning',fire:.01,end:4};race.step();
  assert.equal(r.status,'abducted');assert.equal(race.beam?.phase,'moving');
  for(let i=0;i<55;i++)race.step();assert.ok(r.z>50);
  untilReleased(race,r);assert.ok(mode==='forward'?r.x>=840:r.x<=360);
  assert.equal(race.rank()[0].index,mode==='forward'?0:1);assert.equal(r.transport,null);
});
test('busy/protected runners resist another beam without overlapping effects',()=>{
  const race=quietRace();const r=race.runners[0];r.x=100;r.status='eating';r.until=8;
  race.beam={index:0,mode:'back',phase:'warning',fire:.01,end:4};race.step();
  assert.equal(r.status,'eating');assert.equal(r.x,100);assert.equal(r.transport,null);assert.equal(race.beam?.phase,'blocked');
});
for(const [action,rng] of [['eating',7],['drinking',1]] as const)test(`${action} eases to a stop and resumes`,()=>{
  const race=quietRace();const r=race.runners[0];r.speed=r.target=125;r.nextBreak=0;r.breakRng=rng;
  r.stamina=.35;
  race.step();assert.equal(r.status,action);const start=r.x;
  for(let i=0;i<24;i++)race.step();
  const settled=r.x;assert.ok(settled>start);
  for(let i=0;i<12;i++)race.step();assert.equal(r.x,settled);
  untilReleased(race,r);assert.ok(r.x>settled);assert.ok(r.protectUntil>race.worldTime);
  assert.equal(r.stamina,1);assert.ok(r.speedBoost>=.1&&r.speedBoost<=.2);
  assert.equal(r.boostUntil,race.worldTime+BOOST_SECONDS);
  const boostedX=r.x;race.step();assert.ok(Math.abs(r.x-boostedX-125*(1+r.speedBoost)*STEP)<1e-9);
  while(race.worldTime+STEP<r.boostUntil)race.step();
  const normalX=r.x;race.step();assert.ok(Math.abs(r.x-normalX-125*STEP)<1e-9);assert.ok(r.stamina<1);
});
test('a phone call gradually slows the runner and stays in motion',()=>{
  const race=quietRace();const r=race.runners[0];
  r.speed=r.target=120;r.nextBreak=0;r.breakRng=4;
  race.step();assert.equal(r.status,'phoning');assert.equal(race.events[0].kind,'phone');
  for(let i=0;i<30;i++)race.step();
  const x=r.x;for(let i=0;i<30;i++)race.step();
  assert.ok(Math.abs(r.x-x-21)<1e-8);assert.equal(r.status,'phoning');
  untilReleased(race,r);assert.ok(r.protectUntil>race.worldTime);
});
for(const [kind,seed] of [['grab',4],['kick',0]] as const)test(`${kind} winds up between nearby runners before affecting the target`,()=>{
  const race=quietRace(2,'first',seed);const [actor,target]=race.runners;
  actor.x=200;target.x=224;actor.speed=actor.target=target.speed=target.target=120;race.nextContact=0;
  actor.lane=actor.laneTarget=.42;target.lane=target.laneTarget=.52;
  race.step();
  assert.equal(race.contact?.actor,0);assert.equal(race.contact?.kind,kind);assert.equal(target.status,'running');
  for(let i=0;i<24;i++)race.step();
  assert.equal(race.events[0].kind,kind);assert.equal(race.contact?.hit,true);
  if(kind==='grab'){
    assert.equal(target.status,'grabbed');
    for(let i=0;i<22;i++)race.step();
    const x=target.x;race.step();assert.ok(target.x-x<1);
  }else{
    assert.equal(target.transport?.kind,'kick-bump');
    assert.ok(actor.z>25);
    for(let i=0;i<26;i++)race.step();
    assert.equal(target.status,'fallen');assert.ok(target.x>280);
    assert.equal(actor.z,0);
  }
  untilReleased(race,target);
});
test('passing a runner and nearing the finish keep the simulation at full speed',()=>{
  const race=quietRace(5,'last');const [first,second,third,fourth,fifth]=race.runners;
  first.x=race.finishX-20;second.x=800;third.x=700;fourth.x=600;fifth.x=599;fifth.speed=fifth.target=120;
  race.step();assert.deepEqual(race.rank().slice(-2).map(r=>r.index),[4,3]);
  for(let i=0;i<59;i++)race.step();
  assert.ok(Math.abs(race.worldTime-1)<1e-9);
  assert.equal(race.worldTime,race.elapsed);
  assert.ok(Math.abs(fifth.x-719)<1e-8);
});
test('a banana peel causes one skid and crying pause before the runner continues',()=>{
  const race=quietRace(),r=race.runners[0];
  r.x=319;r.speed=r.target=120;r.attempted.add(900);
  race.obstacles=[{id:900,x:320,width:32,type:'banana',phase:0}];
  race.step();assert.equal(r.status,'banana-cry');assert.equal(race.events[0].kind,'banana');
  const hit=r.x;
  for(let i=0;i<30;i++)race.step();
  assert.equal(r.x,hit+24);
  for(let i=0;i<15;i++)race.step();
  assert.equal(r.x,hit+24);assert.equal(r.status,'banana-cry');
  untilReleased(race,r);assert.ok(r.x>hit+24);assert.ok(r.handled.has(900));
});
test('a runner drops into a hole and crosses to its far rim without a checkpoint reset',()=>{
  const race=quietRace(),r=race.runners[0];
  r.x=319;r.speed=r.target=120;r.attempted.add(900);
  race.obstacles=[{id:900,x:320,width:72,type:'hole',phase:0}];
  race.step();assert.equal(r.status,'pit-fall');
  const entry=r.x;
  for(let i=0;i<15;i++)race.step();assert.equal(r.x,entry);
  for(let i=0;i<25;i++)race.step();assert.ok(r.x>entry&&r.x<399);
  untilReleased(race,r);assert.ok(r.x>=399);assert.equal(r.respawnAt,-Infinity);
});
test('running out of stamina stops the runner for a nap and restores stamina without a boost',()=>{
  const race=quietRace(),r=race.runners[0];r.speed=r.target=120;r.stamina=.0001;
  race.step();assert.equal(r.stamina,0);
  race.step();assert.equal(r.status,'sleeping');assert.equal(race.events[0].kind,'sleep');
  const x=r.x;for(let i=0;i<65;i++)race.step();
  assert.equal(r.x,x);assert.ok(r.stamina>0&&r.stamina<1);
  untilReleased(race,r);assert.equal(race.events[0].kind,'wake');
  assert.ok(r.stamina>.99&&r.x>x);assert.equal(r.boostUntil,0);
});
test('35-person 1km race exercises all new events with finite deterministic states',()=>{
  const race=new Race(roster(35),1000,3);const seen=new Set<string>();
  for(let step=0;step<60000&&!race.finished;step++){race.step();for(const r of race.runners){seen.add(r.status);if(r.transport)seen.add(r.transport.kind);assert.ok(Number.isFinite(r.x)&&r.x>=0&&Number.isFinite(r.z));}}
  for(const kind of ['eating','drinking','phoning','spring','beam-forward','beam-back','grabbing','grabbed','kicking','kick-bump','banana-cry','pit-fall','sleeping','climbing'])assert.ok(seen.has(kind),kind);
  assert.ok(race.finished);assert.equal(race.completedCount,35);assert.ok(race.worldTime<=race.elapsed);assert.ok(race.runners.every(r=>r.x===10000));
});
