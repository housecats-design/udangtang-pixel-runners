import test from 'node:test';
import assert from 'node:assert/strict';
import {Race,type Runner} from '../src/simulation/engine.ts';
import {newParticipant} from '../src/data/avatars.ts';
import {shuffleLineup} from '../src/ui/lineup.ts';
import {headLabelBox} from '../src/rendering/labels.ts';
function quiet(n=2,rule:'first'|'last'='last'){
  const r=new Race(Array.from({length:n},(_,i)=>newParticipant(i)),300,19,rule);r.obstacles=[];r.nextUfo=r.nextBeam=Infinity;
  for(const p of r.runners){p.nextBreak=p.nextSpeed=Infinity;p.speed=p.target=100;}return r;
}
test('last mode stops the remaining runner in place without crossing the finish',()=>{
  const r=quiet(3);r.runners[0].x=r.finishX-.1;r.runners[1].x=r.finishX-.3;r.runners[2].x=1530;
  r.step();assert.ok(r.finished);assert.equal(r.completedCount,2);assert.equal(r.lastPlaceIndex,2);
  assert.equal(r.runners[2].status,'crying');assert.equal(r.runners[2].finishTime,null);assert.ok(r.runners[2].x<1540);
  assert.equal(r.result!.at(-1)!.index,2);assert.equal(r.runners[2].transport,null);assert.equal(r.runners[2].z,0);
  const x=r.runners[2].x;for(let i=0;i<600;i++)r.step();assert.equal(r.runners[2].x,x);
});
test('last-mode crossing ties still select a seeded last runner before the line',()=>{
  const r=quiet(8);for(const p of r.runners)p.x=r.finishX-.1;r.step();assert.ok(r.finished);
  assert.equal(r.completedCount,7);const last=r.result!.at(-1)!;assert.equal(last.status,'crying');assert.equal(last.finishTime,null);assert.ok(last.x<r.finishX);
  assert.equal(last.tie,Math.max(...r.runners.map(p=>p.tie)));
  const pair=quiet(2);for(const p of pair.runners)p.x=pair.finishX-.1;pair.step();assert.ok(pair.tieOccurred,'two-way tie is disclosed even when last is stopped before the line');
});
test('last-mode cutoff cancels a midair beam while keeping the actual stop location',()=>{
  const r=quiet();r.runners[0].x=r.finishX-.1;const p=r.runners[1];p.x=900;p.status='abducted';p.z=80;p.transport={kind:'beam-back',from:1000,to:700,started:-.5,duration:2,height:115,startZ:0};
  r.step();assert.equal(p.status,'crying');assert.equal(p.transport,null);assert.ok(p.x>=700&&p.x<=1000);assert.equal(p.z,0);
});
test('first mode still waits for all arrivals and has no crying state',()=>{
  const r=quiet(2,'first');r.runners[0].x=r.finishX-.1;r.runners[1].x=r.finishX-20;r.step();assert.equal(r.finished,false);
  for(let i=0;i<300&&!r.finished;i++)r.step();assert.ok(r.finished);assert.equal(r.completedCount,2);assert.equal(r.lastPlaceIndex,null);assert.ok(r.runners.every(p=>p.status==='finished'));
});
test('first and last modes share identical simulation until last place is determined',()=>{
  const p=Array.from({length:35},(_,i)=>newParticipant(i));const first=new Race(p,300,123,'first'),last=new Race(p,300,123,'last');
  for(let step=0;step<30000&&!last.finished;step++){
    first.step();last.step();if(!last.finished)assert.deepEqual(first.runners.map(p=>[p.x,p.z,p.rng]),last.runners.map(p=>[p.x,p.z,p.rng]));
  }
  assert.ok(last.finished);assert.deepEqual(first.rank().slice(0,34).map(p=>p.index),last.result!.slice(0,34).map(p=>p.index));
});
test('platform emits separate fall and respawn effects at the actual locations',()=>{
  const r=quiet(2,'first');const p=r.runners[0];p.x=1800;p.attempted.add(900);r.obstacles=[{id:900,x:1800,width:90,type:'platform',phase:0}];
  r.step();assert.equal(p.status,'falling');const fall=r.impacts.find(i=>i.kind==='fall')!;assert.equal(fall.runner,0);assert.ok(fall.x>=1800);
  for(let i=0;i<100;i++)r.step();const respawn=r.impacts.find(i=>i.kind==='respawn')!;assert.ok(respawn);assert.equal(respawn.runner,0);assert.equal(respawn.x,900);assert.ok(respawn.at>fall.at);assert.ok(p.respawnAt>0);
  for(let i=0;i<100;i++)r.step();assert.equal(r.impacts.length,0);
});
test('display shuffle returns a permutation without altering participant identity or course position',()=>{
  const r=quiet(35,'first');const ids=r.runners.map(p=>p.participant.id);const copy=[...ids];const shuffled=shuffleLineup(ids,()=>.1);
  assert.deepEqual(ids,copy);assert.deepEqual([...shuffled].sort(),[...ids].sort());assert.notDeepEqual(shuffled,ids);assert.ok(r.runners.every(p=>p.x===0));
  assert.deepEqual(r.runners.map(p=>p.participant.id),ids);
});
test('name and rank labels stay directly above the head, even when runners overlap',()=>{
  const first=headLabelBox(130,180,68);
  const overlapping=headLabelBox(130,180,52);
  const jumping=headLabelBox(130,145,68);
  assert.equal(first.left+first.width/2,130);
  assert.equal(overlapping.left+overlapping.width/2,130);
  assert.equal(overlapping.top,first.top);
  assert.equal(first.top+27,176);
  assert.equal(jumping.top,first.top-35);
});
