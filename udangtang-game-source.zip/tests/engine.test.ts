import test from 'node:test';
import assert from 'node:assert/strict';
import {Race,STEP,seededRandom,type Obstacle} from '../src/simulation/engine.ts';
import {newParticipant} from '../src/data/avatars.ts';
const roster=(n=8)=>Array.from({length:n},(_,i)=>newParticipant(i));
function finish(race:Race){for(let i=0;i<60000&&!race.finished;i++)race.step();assert.ok(race.finished,'race must complete');return race;}
function quiet(n=2,distance=300){const r=new Race(roster(n),distance,19);r.obstacles=[];r.nextUfo=r.nextBeam=Infinity;for(const p of r.runners){p.nextSpeed=p.nextBreak=Infinity;p.speed=p.target=100;}return r;}
test('seeded random is repeatable and changes between seeds',()=>{assert.deepEqual(seededRandom(42),seededRandom(42));assert.notDeepEqual(seededRandom(42),seededRandom(43));});
test('2 and 35 runners complete all three distances from the same x',()=>{
  for(const n of [2,35])for(const distance of [300,500,1000]){
    const r=new Race(roster(n),distance,127);assert.ok(r.runners.every(p=>p.x===0));finish(r);
    assert.equal(r.finishX,distance*10);assert.equal(r.result!.length,n);
    assert.ok(r.runners.every(p=>p.x===r.finishX&&p.finishTime!==null&&p.status==='finished'));
    assert.ok(r.result!.every((p,i,a)=>i===0||p.finishTime!>=a[i-1].finishTime!));
  }
  assert.throws(()=>new Race(roster(36),300,1));assert.throws(()=>new Race(roster(1),300,1));assert.throws(()=>new Race(roster(),0,1));
});
test('same seed results are independent of names, IDs, appearance and rank reads',()=>{
  const p=roster(35);const a=finish(new Race(p,500,5231));
  const b=new Race(p.map((v,i)=>({...v,id:'changed'+i,name:'동명이인',avatarId:'human-08',paletteId:'#ee8190'})),500,5231);
  while(!b.finished){for(let i=0;i<4;i++)b.step();b.rank().at(-1);}
  assert.deepEqual(a.runners.map(r=>r.finishTime),b.runners.map(r=>r.finishTime));assert.deepEqual(a.result!.map(r=>r.index),b.result!.map(r=>r.index));
});
test('crossing order uses fractional arrival times, not array update order or final x',()=>{
  const r=quiet();r.runners[0].x=r.finishX-.5;r.runners[1].x=r.finishX-.1;
  r.step();assert.equal(r.completedCount,2);assert.ok(r.finished);assert.equal(r.result![0].index,1);
  assert.ok(r.runners.every(p=>p.x===r.finishX));assert.ok(r.runners[1].finishTime!<r.runners[0].finishTime!);
});
for(const rule of ['first','last'] as const)test(`the selected participant is the ${rule} result even if another runner would take that place`,()=>{
  const participants=roster(3);
  participants[0].name=participants[1].name='같은 이름';
  const race=new Race(participants,300,19,rule,[],participants[1].id);
  race.obstacles=[];race.nextUfo=race.nextBeam=race.nextContact=Infinity;
  const [first,selected,third]=race.runners;
  for(const runner of race.runners){
    runner.nextSpeed=runner.nextBreak=Infinity;
    runner.speed=runner.target=100;
  }
  first.x=race.finishX-(rule==='first'?.1:12);
  selected.x=race.finishX-(rule==='first'?12:.1);
  third.x=race.finishX-8;
  race.step();
  assert.equal((rule==='first'?first:selected).finishHeld,true);
  finish(race);
  assert.equal(rule==='first'?race.result![0]:race.result!.at(-1),selected);
  if(rule==='last'){
    assert.equal(selected.status,'crying');
    assert.equal(selected.finishTime,null);
    assert.ok(selected.x<race.finishX);
  }
});
test('race continues after first arrival and result finalizes exactly once after everyone arrives',()=>{
  const r=quiet();r.runners[0].x=r.finishX-.1;r.runners[1].x=r.finishX-10;r.step();
  assert.equal(r.completedCount,1);assert.equal(r.finished,false);const firstTime=r.runners[0].finishTime;
  finish(r);assert.equal(r.runners[0].finishTime,firstTime);const result=r.result;const elapsed=r.elapsed;
  for(let i=0;i<100;i++)r.step();assert.equal(r.result,result);assert.equal(r.elapsed,elapsed);
  assert.equal(r.result![0].index,0);assert.equal(r.result!.at(-1)!.index,1);
});
test('finished runners cannot be frozen, moved back or take another break',()=>{
  const r=quiet();const p=r.runners[0];p.x=r.finishX-.1;r.step();const arrival=p.finishTime;
  r.beam={index:0,mode:'back',phase:'warning',fire:r.worldTime,end:r.worldTime+4};
  r.ufo={index:0,warn:1,fire:r.worldTime,end:r.worldTime+4};p.nextBreak=0;
  for(let i=0;i<60;i++)r.step();assert.equal(p.x,r.finishX);assert.equal(p.finishTime,arrival);assert.equal(p.status,'finished');
});
test('exact arrival ties use seeded tie values, not roster order',()=>{
  const r=quiet(8);for(const p of r.runners)p.x=r.finishX-.1;r.step();
  assert.ok(r.finished&&r.tieOccurred);assert.ok(r.runners.every(p=>p.finishTime===r.runners[0].finishTime));
  assert.deepEqual(r.result!.map(p=>p.tie),r.runners.map(p=>p.tie).sort((a,b)=>a-b));
});
test('forward beam crossing finish records the continuous trajectory and clamps at the line',()=>{
  const r=quiet();const p=r.runners[0];p.x=r.finishX-80;
  p.transport={kind:'beam-forward',from:p.x,to:r.finishX+120,started:0,duration:2,height:115,startZ:0};p.status='abducted';p.until=2;
  for(let i=0;i<600&&p.finishTime===null;i++)r.step();assert.notEqual(p.finishTime,null);
  assert.equal(p.x,r.finishX);assert.equal(p.transport,null);assert.equal(p.status,'finished');assert.ok(p.finishTime!>0);
});
function atObstacle(type:Obstacle['type']){const r=quiet();r.obstacles=[{id:900,x:100,width:type==='mud'?145:90,type,phase:0}];const p=r.runners[0];p.x=100;p.attempted.add(900);p.speed=p.target=85;return {r,p};}
test('puddle stops, recovers and cannot repeatedly hit',()=>{const {r,p}=atObstacle('puddle');r.step();assert.equal(p.status,'splash');for(let i=0;i<250;i++)r.step();assert.equal(p.status,'running');assert.ok(p.handled.has(900)&&p.x>100);});
test('mud halves actual motion inside its range',()=>{const {r,p}=atObstacle('mud');r.step();assert.ok(Math.abs(p.x-100-85*STEP*.5)<1e-9);});
test('rotating bar and hammer use the same phase as rendered art',()=>{for(const type of ['spinner','hammer'] as const){const {r,p}=atObstacle(type);r.elapsed=r.worldTime=.3;r.step();assert.equal(p.status,'fallen');if(type==='hammer')assert.ok(p.x<100);}});
test('platform fall restores checkpoint and current-position rank',()=>{const {r,p}=atObstacle('platform');r.step();assert.equal(p.status,'falling');for(let i=0;i<80;i++)r.step();assert.equal(p.status,'running');assert.ok(p.x<30);assert.ok(r.rank().indexOf(p)>0);});
test('UFO warns, freezes its target, then releases it',()=>{const r=quiet();r.nextUfo=.01;r.step();const target=r.ufo!.index;for(let i=0;i<79;i++)r.step();assert.equal(r.runners[target].status,'frozen');const x=r.runners[target].x;for(let i=0;i<30;i++)r.step();assert.equal(r.runners[target].x,x);for(let i=0;i<240;i++)r.step();assert.equal(r.runners[target].status,'running');});
test('course leaves a clear finish area and never creates hazards after the line',()=>{const r=finish(new Race(roster(35),1000,20261110));assert.ok(r.obstacles.every(o=>o.x+o.width<=r.finishX-160));});
