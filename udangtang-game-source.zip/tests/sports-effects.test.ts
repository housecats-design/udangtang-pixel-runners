import test from 'node:test';
import assert from 'node:assert/strict';
import {createMatch,startRound,stepMatch,applyControl} from '../src/sports/engine.ts';
import {SKEET_DURATION,SKEET_TARGET_COUNT,SKEET_GATES,createSkeetCourse,skeetBonusAt,skeetTarget,skeetHit,skeetMotionIndex} from '../src/sports/skeet.ts';

test('generated shooting starts at the actual shot and cannot replay on a new opposite aim',()=>{
  const shot={id:0,side:0 as const,at:.83,hit:true};
  assert.equal(skeetMotionIndex(.82,0,shot),0);
  assert.equal(skeetMotionIndex(.83,0,shot),4);
  assert.ok(skeetMotionIndex(1.12,0,shot)>4);
  assert.equal(skeetMotionIndex(1.12,1,shot),0);
  assert.equal(skeetMotionIndex(1.44,0,shot),0);
  assert.equal(skeetMotionIndex(2.7,0,shot),0);
  assert.equal(skeetMotionIndex(1,1,undefined),0);
});

test('every seeded target crosses the visible aiming box inside its own scoring window',()=>{
  for(const seed of [1,19,701,20261125])for(const disc of createSkeetCourse(seed)){
    const gate=SKEET_GATES[disc.side],window=24/disc.speed;
    assert.ok(window<.14,'narrower timing than the previous .24 second window');
    for(const offset of [-window*.99,0,window*.99]){
      const time=disc.hitAt+offset,point=skeetTarget(time,disc);
      assert.equal(skeetHit(time,disc.side,[disc]),true);
      assert.ok(Math.abs(point.x-gate.x)<=24);assert.ok(Math.abs(point.y-gate.y)<=22);
    }
    assert.equal(skeetHit(disc.hitAt+window+.001,disc.side,[disc]),false);
    assert.deepEqual(skeetTarget(disc.hitAt,disc),gate);
  }
});
test('course mixes order, same-side runs, staggered and fast gaps and survives network serialization',()=>{
  for(let seed=1;seed<=80;seed++){
    const course=createSkeetCourse(seed);
    assert.equal(course.length,SKEET_TARGET_COUNT);
    assert.equal(new Set(course.map(d=>d.id)).size,SKEET_TARGET_COUNT);
    assert.deepEqual(course,createSkeetCourse(seed));
    assert.deepEqual(course,JSON.parse(JSON.stringify(course)));
    assert.ok(skeetBonusAt(course)<SKEET_DURATION-2);
    assert.ok(course.every(d=>d.launchAt>=0&&d.launchAt<d.hitAt&&d.hitAt<d.exitAt));
    const gaps=course.slice(1).map((d,i)=>d.hitAt-course[i].hitAt);
    assert.ok(gaps.some(g=>g<.23));assert.ok(gaps.some(g=>g>.58&&g<.8));
    assert.ok(course.some((d,i)=>i>0&&d.side===course[i-1].side));
    assert.ok(course.some((d,i)=>i>0&&course[i-1].side===0&&d.side===1));
    assert.ok(course.some((d,i)=>i>0&&course[i-1].side===1&&d.side===0));
  }
  assert.notDeepEqual(createSkeetCourse(1),createSkeetCourse(2));
});
function shooting(){const match=createMatch([{id:'one',name:'one',avatar:0,color:'#49c4b2',ready:true,connected:true,total:0}],['skeet']);startRound(match);stepMatch(match,3.1);match.round!.skeetTargets=createSkeetCourse(701);return match;}
test('same-side rapid targets score independently without duplicate or early-hit farming',()=>{
  const match=shooting(),round=match.round!,player=round.players[0],course=round.skeetTargets!;
  const secondIndex=course.findIndex((d,i)=>i>0&&d.side===course[i-1].side&&d.hitAt-course[i-1].hitAt<.35);
  assert.ok(secondIndex>0);
  for(const disc of course.slice(secondIndex-1,secondIndex+1)){
    round.time=disc.hitAt;
    const button=disc.side===0?'A':'C';applyControl(match,'one',button,true);applyControl(match,'one',button,true);
  }
  assert.equal(player.hits,2);assert.equal(player.shots.length,2);assert.equal(player.attempts,2);
  assert.equal(player.shotEffects!.length,2);
  const first=course[0];const miss=shooting();miss.round!.time=first.launchAt+.01;
  applyControl(miss,'one',first.side===0?'A':'C',true);
  assert.equal(miss.round!.players[0].hits,0);
  miss.round!.time=first.hitAt;applyControl(miss,'one',first.side===0?'A':'C',true);
  assert.equal(miss.round!.players[0].hits,0,'one attempt per launched target');
});
test('all 32 targets remain hittable and perfect bonus opens only after the course ends',()=>{
  const match=shooting(),round=match.round!,player=round.players[0],course=round.skeetTargets!;
  for(const disc of course){round.time=disc.hitAt;applyControl(match,'one',disc.side===0?'A':'C',true);}
  assert.equal(player.hits,SKEET_TARGET_COUNT);assert.equal(player.bonus,0);
  round.time=skeetBonusAt(course)+.01;applyControl(match,'one','A',true);assert.equal(player.bonus,1000);
  assert.equal(player.shotEffects!.at(-1)!.bonus,true);
  round.time=SKEET_DURATION;stepMatch(match,1/60);assert.equal(player.result,'32/32 명중');
});
