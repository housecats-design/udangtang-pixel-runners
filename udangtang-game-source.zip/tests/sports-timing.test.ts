import test from 'node:test';
import assert from 'node:assert/strict';
import {applyControl,createMatch,startRound,stepMatch} from '../src/sports/engine.ts';
import {PLAYER_COLORS,type SportId} from '../src/sports/model.ts';
function playing(sport:SportId){const people=['one','two'].map((id,i)=>({id,name:id,avatar:i,color:PLAYER_COLORS[i],ready:true,connected:true,total:0}));const m=createMatch(people,[sport]);startRound(m);stepMatch(m,3.1);return m;}
test('missed swimming cue stops that swimmer; strokes cannot move them until B',()=>{
  const m=playing('swimming'),p=m.round!.players[0],other=m.round!.players[1];
  p.speed=9;p.oxygen=.31;other.speed=9;
  stepMatch(m,.01);assert.equal(p.phase,'breath');
  stepMatch(m,.71);assert.equal(p.phase,'gasping');assert.equal(p.speed,0);
  const stopped=p.progress,forward=other.progress;
  for(let i=0;i<10;i++){applyControl(m,'one',i%2?'A':'C',true);stepMatch(m,.1);}
  assert.equal(p.progress,stopped);assert.equal(p.speed,0);assert.ok(other.progress>forward);
  applyControl(m,'one','B',true);assert.equal(p.oxygen,1);assert.equal(p.phase,'swim');
  applyControl(m,'one','A',true);stepMatch(m,.1);assert.ok(p.progress>stopped);
});
test('B is accepted during the cue and early breathing does not refill oxygen',()=>{
  const m=playing('swimming'),p=m.round!.players[0];p.oxygen=.8;
  applyControl(m,'one','B',true);assert.equal(p.oxygen,.8);
  p.oxygen=.3;stepMatch(m,.05);stepMatch(m,.5);applyControl(m,'one','B',true);stepMatch(m,.3);
  assert.notEqual(p.phase,'gasping');assert.ok(p.oxygen>.9);
});
test('normal alternating swim cadence still reaches the breath cue around two seconds',()=>{
  const m=playing('swimming'),p=m.round!.players[0];
  while(p.phase!=='breath'&&m.round!.time<3){stepMatch(m,.125);applyControl(m,'one',Math.round(m.round!.time*8)%2?'A':'C',true);}
  assert.ok(m.round!.time>=1.8&&m.round!.time<=2.2);
});
function launchVault(speed=9,angle=52){
  const m=playing('vault'),p=m.round!.players[0];p.phase='run';p.progress=76;p.speed=speed;
  applyControl(m,'one','B',true);applyControl(m,'one','B',false,(angle-20)/90*1000);
  for(let i=0;i<48;i++)stepMatch(m,1/60);
  assert.equal(p.phase,'air');return m;
}
test('vault speed and held angle change trajectory; C accelerates but cannot turn in flight',()=>{
  const fast=launchVault(9,52),slow=launchVault(4,30),p=fast.round!.players[0],q=slow.round!.players[0];
  assert.ok(p.vault!.peak>q.vault!.peak);assert.ok(p.vault!.duration>q.vault!.duration);
  assert.equal(p.angle,52);applyControl(fast,'one','C',true);assert.equal(p.attempts,0);
});
test('vault requires enough A presses and an upright landing, then shows success or fall and crying',()=>{
  for(const taps of [0,4,8]){
    const m=launchVault(),p=m.round!.players[0];
    for(let i=0;i<400&&!p.finished;i++){
      if(p.phase==='air'&&p.attempts<taps&&i%6===0)applyControl(m,'one','A',true);
      stepMatch(m,1/60);
    }
    assert.equal(p.finished,true);assert.equal(p.vault!.success,taps===8);
    assert.equal(p.phase,taps===8?'salute':'cry');assert.equal(p.score>0,taps===8);
  }
});
test('archery must nock an arrow first and holds the chosen angle in the shot record',()=>{
  const m=playing('archery'),p=m.round!.players[0];applyControl(m,'one','A',true);p.quality=0;
  applyControl(m,'one','B',true);stepMatch(m,.3);assert.equal(p.angle,0);
  applyControl(m,'one','B',false,300);assert.equal(p.attempts,0);
  applyControl(m,'one','B',true);applyControl(m,'one','B',false,1812.5);
  assert.equal(p.arrow!.angle,5.25);assert.equal(p.arrow!.points,10);
  const attempts=p.attempts;applyControl(m,'one','B',true);applyControl(m,'one','B',false,1812.5);assert.equal(p.attempts,attempts);
});
test('triple final jump transitions through a distinct sand landing before scoring once',()=>{
  const m=playing('triple'),p=m.round!.players[0];p.phase='flight';p.stage=2;p.phaseAt=0;p.quality=1;p.power=19;
  stepMatch(m,1.11);assert.equal(p.phase,'landing');assert.equal(p.height,0);assert.equal(p.finished,false);
  stepMatch(m,1.21);assert.equal(p.finished,true);assert.ok(p.score>0);
  const score=p.score;stepMatch(m,2);assert.equal(p.score,score);
});
