import test from 'node:test';
import assert from 'node:assert/strict';
import {RaceMusic} from '../src/audio/race-music.ts';

function fakeAudio(){
  const parameter=()=>({
    value:0,setValueAtTime(){},linearRampToValueAtTime(){},
    exponentialRampToValueAtTime(){},cancelScheduledValues(){},setTargetAtTime(){},
  });
  const oscillators:{started:number;stops:number[];onended:(()=>void)|null;disconnected:boolean}[]=[];
  const gains:{disconnected:boolean}[]=[];
  const context={
    currentTime:0,state:'running',destination:{},
    createOscillator(){
      const node={
        started:-1,stops:[] as number[],onended:null as (()=>void)|null,
        disconnected:false,type:'sine',frequency:parameter(),connect(){},
        disconnect(){this.disconnected=true;},
        start(at:number){this.started=at;},stop(at:number){this.stops.push(at);},
      };
      oscillators.push(node);return node;
    },
    createGain(){
      const node={gain:parameter(),disconnected:false,connect(){},disconnect(){this.disconnected=true;}};
      gains.push(node);return node;
    },
  };
  return {context,oscillators,gains,music:new RaceMusic(context as unknown as AudioContext)};
}

test('music waits for a running audio context and repeated play calls do not layer loops',t=>{
  t.mock.timers.enable({apis:['setInterval']});
  const {context,music,oscillators}=fakeAudio();
  context.state='suspended';music.setPlaying(true);
  assert.equal(oscillators.length,0);
  context.state='running';music.setPlaying(true);
  assert.ok(oscillators.length>0);
  const initial=oscillators.length;
  for(let i=0;i<60;i++)music.setPlaying(true);
  assert.equal(oscillators.length,initial);
  context.currentTime=.2;t.mock.timers.tick(25);
  assert.ok(oscillators.length>initial);
  music.stop();
});

test('mute cancels sounding and queued notes, and repeated stops do not extend the fade',t=>{
  t.mock.timers.enable({apis:['setInterval']});
  const {context,music,oscillators,gains}=fakeAudio();
  music.setPlaying(true);context.currentTime=.05;music.setPlaying(false);
  assert.ok(oscillators.every(node=>node.stops.at(-1)===.07));
  const count=oscillators.length;
  context.currentTime=2;music.setPlaying(false);t.mock.timers.tick(500);
  assert.equal(oscillators.length,count);
  assert.ok(oscillators.every(node=>node.stops.length===2));
  for(const node of oscillators)node.onended?.();
  assert.ok(oscillators.every(node=>node.disconnected));
  assert.ok(gains.every(node=>node.disconnected));
});

test('resume preserves the tune position while rematch resets to its opening',t=>{
  t.mock.timers.enable({apis:['setInterval']});
  const {context,music,oscillators}=fakeAudio();
  music.setPlaying(true);context.currentTime=.05;music.stop();
  const count=oscillators.length;
  context.currentTime=1;music.setPlaying(true);
  // Step 1 is a rest; step 2 contains the next melody, chord and percussion.
  assert.equal(oscillators.length-count,5);
  music.stop(true);
  const resumed=oscillators.length;
  context.currentTime=2;music.setPlaying(true);
  assert.equal(oscillators.length-resumed,3);
  music.stop();
});

test('long races keep looping without scheduling a burst after an audio-clock jump',t=>{
  t.mock.timers.enable({apis:['setInterval']});
  const {context,music,oscillators}=fakeAudio();
  music.setPlaying(true);
  for(let i=1;i<=2400;i++){
    context.currentTime=i*.025;t.mock.timers.tick(25);
    for(const node of oscillators)if(!node.disconnected&&node.stops.at(-1)!<=context.currentTime)node.onended?.();
  }
  assert.ok(oscillators.some(node=>node.started>59),'music continues beyond two full loops');
  const count=oscillators.length;
  context.currentTime=100;t.mock.timers.tick(25);
  assert.ok(oscillators.length-count<=10,'only schedules the short lookahead window');
  assert.ok(oscillators.slice(count).every(node=>node.started>=100));
  music.stop();
});
