import test from 'node:test';
import assert from 'node:assert/strict';
import {ARENA_WIDTH,ARENA_HEIGHT,arenaLanes,arenaStations} from '../src/sports/arena-layout.ts';
import {createMatch,startRound,stepMatch,applyControl} from '../src/sports/engine.ts';

test('all eight athletes fit the shared pool, track and field without overlapping starting positions',()=>{
  const lanes=arenaLanes(8),stations=arenaStations(8);
  assert.equal(lanes.length,8);assert.equal(stations.length,8);
  assert.equal(new Set(lanes.map(lane=>lane.y)).size,8);
  assert.equal(new Set(stations.map(spot=>`${spot.x}:${spot.y}`)).size,8);
  for(const lane of lanes){assert.ok(lane.top>=220);assert.ok(lane.top+lane.height<=ARENA_HEIGHT);assert.ok(lane.height>=54);}
  for(const spot of stations){assert.ok(spot.x-120>0&&spot.x+120<ARENA_WIDTH);assert.ok(spot.y-150>220&&spot.y+60<ARENA_HEIGHT);}
});
test('swimming asks for breath every two seconds at eight alternating presses per second',()=>{
  const match=createMatch([{id:'one',name:'one',avatar:0,color:'#49c4b2',ready:true,connected:true,total:0}],['swimming']);
  startRound(match);stepMatch(match,3.1);
  const player=match.round!.players[0];let taps=0;
  for(let cycle=0;cycle<2;cycle++){
    const start=match.round!.time;
    for(let frame=1;frame<=250;frame++){
      stepMatch(match,1/120);
      if(frame%15===0)applyControl(match,'one',taps++%2?'A':'C',true);
      if(player.oxygen<=.32)break;
    }
    assert.ok(Math.abs(match.round!.time-start-2)<.03);
    applyControl(match,'one','B',true);assert.equal(player.oxygen,1);
  }
});
