# PixelLab 02 · 둥근 SD형 클레이 사격

사용자가 5개 실제 PixelLab 동작 시안 중 선택한 02번입니다. `provenance.json`에 모델·작업 ID·시드·프롬프트·반환 프레임 수를 보관합니다. 추가 생성 없이 선택한 결과를 사용했습니다.

- `turn/00.png`–`16.png`: 오른쪽 조준 → 정면 회전 → 왼쪽 조준 (17프레임, 시작 참조 프레임 포함)
- `shot/00.png`–`08.png`: 오른쪽 발사·반동·복귀 (9프레임, 시작 참조 프레임 포함)
- 오른쪽으로 복귀: turn 역재생. 왼쪽 발사: shot 좌우 반전.
- 8명 모두 같은 SD 체형·모션을 공유하며 저장된 머리·피부·상의·하의 색상을 적용합니다.

`swift scripts/pack-skeet-sd.swift`로 `public/assets/characters/pixellab-skeet-sd.png`를 만듭니다. 64×64, 6열 5행, turn 0–16 뒤 shot 17–25 순서이며 프레임별 원점·크기는 유지합니다. macOS 샌드박스에서는 `swift -module-cache-path /private/tmp/udangtang-swift-cache scripts/pack-skeet-sd.swift`를 사용할 수 있습니다.

게임 전환은 0.16초, 발사·반동·복귀는 0.3초입니다. 전환 도중 누른 사격의 시각 동작만 전환 종료 후 재생하고 명중·점수·서버 입력 시각은 변경하지 않습니다. 개인 화면과 공동 경기장은 동일한 사격 렌더러를 사용합니다.
