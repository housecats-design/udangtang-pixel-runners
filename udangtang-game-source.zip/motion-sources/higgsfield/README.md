# 우당탕 달리기 · 힉스필드 모션 원본

민트 러너를 기준으로 만든 힉스필드 원본입니다. PNG 시트는 각 행에 한 동작, 왼쪽부터 오른쪽까지 6프레임입니다. 점프는 12프레임 GIF입니다.

| 원본 | 행 순서 (위 → 아래) |
| --- | --- |
| [01-core.png](01-core.png) | 대기, 달리기, 공중에서 허우적거리기, 환호, 울기, 넘어지기 |
| [02-events.png](02-events.png) | 일어나기, 벽 타기, 물에 발이 빠졌을 때 반응, 잠들기, 밥 먹기, 음료 마시기 |
| [03-reactions.png](03-reactions.png) | 전화 받기, 얼어붙기, 앞 참가자 잡기, 잡혔을 때 휘청이기, 발차기, 지친 달리기 |
| [04-forms.png](04-forms.png) | 킥보드, 자전거, 자동차, 토끼, 여우, 오리 |
| [jump.gif](jump.gif) | 점프 준비, 도약, 공중, 착지 |
| [기존 바나나 미끄러짐](../../public/assets/characters/banana-slip-higgsfield.png) | 기존 힉스필드 영상에서 가져온 동작 |

게임에서는 가볍게 패킹한 [모션 아틀라스](../../public/assets/characters/higgsfield-motion-atlas.png)를 재생합니다.
구멍, 이동 발판, 광선은 공중 동작과 일어나기를 재사용하고 기존 게임 효과와 함께 재생합니다. 거대화와 무지개에는 같은 달리기 동작에 크기 및 색 효과를 적용합니다. 기존 바나나 모션은 참가자별로 준비된 [프레임](../../public/assets/characters/banana-slip-cast.png)을 사용합니다.

아틀라스를 다시 만들려면 게임 폴더에서 `swift scripts/pack-higgsfield-motions.swift`를 실행하세요.
