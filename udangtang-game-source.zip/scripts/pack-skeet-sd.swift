import Foundation
import CoreGraphics
import ImageIO
import UniformTypeIdentifiers

// Run from the game root: swift scripts/pack-skeet-sd.swift
// Keep the generated 64px frame coordinates intact (no per-frame recentering).
let tile = 64, columns = 6, rows = 5
let width = tile * columns, height = tile * rows
let space = CGColorSpace(name: CGColorSpace.sRGB)!
let bitmap = CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue
var pixels = [UInt8](repeating: 0, count: width * height * 4)
var frame = 0
for (clip, count) in [("turn", 17), ("shot", 9)] {
    for i in 0..<count {
        let name = String(format: "%02d.png", i)
        let url = URL(fileURLWithPath: "motion-sources/pixellab/skeet-sd/\(clip)/\(name)")
        let source = CGImageSourceCreateWithURL(url as CFURL, nil)!
        let image = CGImageSourceCreateImageAtIndex(source, 0, nil)!
        precondition(image.width == tile && image.height == tile)
        let context = CGContext(data: nil, width: tile, height: tile, bitsPerComponent: 8,
                                bytesPerRow: tile * 4, space: space, bitmapInfo: bitmap)!
        context.draw(image, in: CGRect(x: 0, y: 0, width: tile, height: tile))
        let input = context.data!.assumingMemoryBound(to: UInt8.self)
        for y in 0..<tile {
            let start = ((frame / columns * tile + y) * width + frame % columns * tile) * 4
            for x in 0..<(tile * 4) { pixels[start + x] = input[y * tile * 4 + x] }
        }
        frame += 1
    }
}
let provider = CGDataProvider(data: Data(pixels) as CFData)!
let result = CGImage(width: width, height: height, bitsPerComponent: 8, bitsPerPixel: 32,
                     bytesPerRow: width * 4, space: space, bitmapInfo: CGBitmapInfo(rawValue: bitmap),
                     provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent)!
let url = URL(fileURLWithPath: "public/assets/characters/pixellab-skeet-sd.png")
let dest = CGImageDestinationCreateWithURL(url as CFURL, UTType.png.identifier as CFString, 1, nil)!
CGImageDestinationAddImage(dest, result, nil)
precondition(CGImageDestinationFinalize(dest))
print("Packed \(frame) PixelLab SD frames into \(width)×\(height)")
