import CoreGraphics
import Foundation
import ImageIO
import UniformTypeIdentifiers

// Run from the game root: swift scripts/pack-higgsfield-motions.swift
let dir = "motion-sources/higgsfield"
let space = CGColorSpace(name: CGColorSpace.sRGB)!
let bitmap = CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue
let size = 64, columns = 12, rows = 25
let width = size * columns, height = size * rows
var output = [UInt8](repeating: 0, count: width * height * 4)
struct Pixels {
    let width: Int, height: Int, data: [UInt8]
    init(_ image: CGImage) {
        width = image.width; height = image.height
        let ctx = CGContext(data: nil, width: width, height: height, bitsPerComponent: 8,
                            bytesPerRow: width * 4, space: space, bitmapInfo: bitmap)!
        ctx.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
        data = Array(UnsafeBufferPointer(start: ctx.data!.assumingMemoryBound(to: UInt8.self),
                                         count: width * height * 4))
    }
    func alpha(_ x: Int, _ y: Int) -> Int { Int(data[(y * width + x) * 4 + 3]) }
}
struct Bounds { let x: Int, y: Int, w: Int, h: Int }
func source(_ name: String) -> CGImageSource {
    CGImageSourceCreateWithURL(URL(fileURLWithPath: "\(dir)/\(name)") as CFURL, nil)!
}
func bounds(_ p: Pixels, _ rect: Bounds) -> Bounds {
    var left = rect.x + rect.w, right = rect.x - 1
    var top = rect.y + rect.h, bottom = rect.y - 1, opaque = 0
    for y in rect.y..<(rect.y + rect.h) {
        for x in rect.x..<(rect.x + rect.w) where p.alpha(x, y) >= 190 {
            left = min(left, x); right = max(right, x)
            top = min(top, y); bottom = max(bottom, y); opaque += 1
        }
    }
    precondition(opaque > 200, "Missing frame in \(rect)")
    return Bounds(x: left, y: top, w: right - left + 1, h: bottom - top + 1)
}
func pack(_ p: Pixels, _ b: Bounds, _ scale: Double, _ row: Int, _ col: Int, _ foot: Int) {
    let w = max(1, Int((Double(b.w) * scale).rounded()))
    let h = max(1, Int((Double(b.h) * scale).rounded()))
    let ox = col * size + (size - w) / 2, oy = row * size + foot - h
    precondition(w <= size && foot >= h && foot <= size)
    for y in 0..<h {
        for x in 0..<w {
            let sx = b.x + min(b.w - 1, Int((Double(x) + 0.5) * Double(b.w) / Double(w)))
            let sy = b.y + min(b.h - 1, Int((Double(y) + 0.5) * Double(b.h) / Double(h)))
            let i = (sy * p.width + sx) * 4, alpha = Int(p.data[i + 3])
            if alpha < 190 { continue }
            let o = ((oy + y) * width + ox + x) * 4
            for c in 0..<3 { output[o + c] = UInt8(min(255, Int(p.data[i + c]) * 255 / alpha)) }
            output[o + 3] = 255
        }
    }
}

let names = ["01-core.png", "02-events.png", "03-reactions.png", "04-forms.png"]
for (sheet, name) in names.enumerated() {
    let p = Pixels(CGImageSourceCreateImageAtIndex(source(name), 0, nil)!)
    for row in 0..<6 {
        var frames: [Bounds] = []
        for col in 0..<6 {
            let x = col * p.width / 6, y = row * p.height / 6
            let w = (col + 1) * p.width / 6 - x, h = (row + 1) * p.height / 6 - y
            frames.append(bounds(p, Bounds(x: x + 8, y: y + 8, w: w - 16, h: h - 16)))
        }
        let maxW = frames.map(\.w).max()!, maxH = frames.map(\.h).max()!
        let targetHeight = sheet == 3 && row >= 3 ? 34.0 : 49.0
        let scale = min(targetHeight / Double(maxH), 60 / Double(maxW))
        for (col, frame) in frames.enumerated() {
            let commonBottom = frames.map { $0.y + $0.h }.max()!
            let bounce = [1, 2, 3, 19, 20, 21, 22, 23].contains(sheet * 6 + row)
                ? min(6, Int((Double(commonBottom - frame.y - frame.h) * scale).rounded())) : 0
            pack(p, frame, scale, sheet * 6 + row, col, 56 - bounce)
        }
        print(name, row + 1, frames.map { "\($0.w)x\($0.h)" }.joined(separator: " "))
    }
}

let jump = source("jump.gif")
let frameCount = CGImageSourceGetCount(jump)
precondition(frameCount == 12)
var jumpFrames: [(Pixels, Bounds)] = []
for i in 0..<frameCount {
    let p = Pixels(CGImageSourceCreateImageAtIndex(jump, i, nil)!)
    jumpFrames.append((p, bounds(p, Bounds(x: 0, y: 0, w: p.width, h: p.height))))
}
let jumpScale = min(49.0 / Double(jumpFrames.map { $0.1.h }.max()!),
                    60.0 / Double(jumpFrames.map { $0.1.w }.max()!))
for (i, f) in jumpFrames.enumerated() { pack(f.0, f.1, jumpScale, 24, i, 56) }

let provider = CGDataProvider(data: Data(output) as CFData)!
let result = CGImage(width: width, height: height, bitsPerComponent: 8, bitsPerPixel: 32,
                     bytesPerRow: width * 4, space: space, bitmapInfo: CGBitmapInfo(rawValue: bitmap),
                     provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent)!
let url = URL(fileURLWithPath: "public/assets/characters/higgsfield-motion-atlas.png")
let dest = CGImageDestinationCreateWithURL(url as CFURL, UTType.png.identifier as CFString, 1, nil)!
CGImageDestinationAddImage(dest, result, nil)
precondition(CGImageDestinationFinalize(dest))
