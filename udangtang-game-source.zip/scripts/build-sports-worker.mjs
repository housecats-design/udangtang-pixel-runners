import {readFile,writeFile,mkdir,readdir,rm} from 'node:fs/promises';
import {join,extname} from 'node:path';
import {build} from 'esbuild';
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.json':'application/json','.svg':'image/svg+xml','.ico':'image/x-icon','.wav':'audio/wav','.txt':'text/plain; charset=utf-8','.xml':'application/xml; charset=utf-8'};
const assets={};
async function collect(dir,prefix='') {
  for(const entry of await readdir(dir,{withFileTypes:true})) {
    const path=join(dir,entry.name),key=prefix+'/'+entry.name;
    if(entry.name==='server'||entry.name==='.openai')continue;
    if(entry.isDirectory())await collect(path,key);
    else if(types[extname(entry.name)])assets[key]={type:types[extname(entry.name)],body:(await readFile(path)).toString('base64')};
  }
}
await collect('dist');
await writeFile('server/static-assets.generated.json',JSON.stringify(assets));
try {
  await mkdir('dist/server',{recursive:true});
  await build({entryPoints:['server/worker.ts'],outfile:'dist/server/index.js',bundle:true,format:'esm',platform:'browser',target:'es2022',minify:true});
} finally {await rm('server/static-assets.generated.json',{force:true});}
console.log('Built online room Worker and embedded '+Object.keys(assets).length+' static assets.');
