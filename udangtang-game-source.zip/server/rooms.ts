import {SPORTS, PLAYER_COLORS, type Athlete, type ButtonInput, type Match, type RoomView} from '../src/sports/model.ts';

type Row = {code:string; state:string; revision:number; expires:number};
type Statement = {bind(...values:unknown[]):Statement; first<T=Row>():Promise<T|null>; all<T=Row>():Promise<{results:T[]}>; run():Promise<unknown>};
export type Database = {prepare(sql:string):Statement};
type Member = {id:string; name:string; avatar:number; color:string; ready:boolean; tokenHash:string; seen:number; seq:number; inputs:ButtonInput[]};
type Room = {hostHash:string; hostSeen:number; members:Member[]; match:Match|null; hostFrame:number; epoch:number; appliedAck?:Record<string,number>};
class RoomError extends Error {
  status:number;
  constructor(message:string,status=400) {super(message);this.status=status;}
}
const TTL=2*60*60*1000;
const ALPHABET='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const VALID_SPORTS=new Set(SPORTS.map(sport=>sport.id));
const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'};
function randomCode() {
  return Array.from(crypto.getRandomValues(new Uint8Array(6)),value=>ALPHABET[value%ALPHABET.length]).join('');
}
async function digest(token:string) {
  const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token));
  return Array.from(new Uint8Array(bytes),byte=>byte.toString(16).padStart(2,'0')).join('');
}
function roster(room:Room):Athlete[] {
  return room.members.map(member=>({id:member.id,name:member.name,avatar:member.avatar,color:member.color,
    ready:member.ready,connected:Date.now()-member.seen<6000,
    total:room.match?.athletes.find(athlete=>athlete.id===member.id)?.total??0}));
}
function view(row:Row,room:Room):RoomView {
  return {code:row.code,athletes:roster(room),match:room.match,revision:row.revision,hostSeen:room.hostSeen,expires:row.expires,appliedAck:room.appliedAck??{}};
}
function validateMatch(value:unknown,room:Room): asserts value is Match {
  const match=value as Match;
  if(!match||!['lobby','countdown','playing','results','finished'].includes(match.phase)||
    !Array.isArray(match.events)||!match.events.length||match.events.length!==1||
    match.events.some(sport=>!VALID_SPORTS.has(sport))||
    !Array.isArray(match.athletes)||match.athletes.length!==room.members.length||match.athletes.length>8||
    match.athletes.some(athlete=>!room.members.some(member=>member.id===athlete.id))) {
    throw new RoomError('경기 정보를 다시 확인해 주세요.');
  }
}
export async function roomApi(request:Request,db:Database):Promise<Response> {
  try {
    const url=new URL(request.url);
    const action=url.pathname.split('/').filter(Boolean).at(-1);
    if(action==='health')return Response.json({ok:true,version:'1.1.14'}, {headers});
    if(request.method!=='POST')throw new RoomError('POST 요청이 필요합니다.',405);
    if(Number(request.headers.get('content-length')??0)>90000)throw new RoomError('요청이 너무 큽니다.',413);
    const raw=await request.text();
    if(raw.length>90000)throw new RoomError('요청이 너무 큽니다.',413);
    const body=JSON.parse(raw);
    if(action==='create') {
      if(typeof body.token!=='string'||body.token.length<24||body.token.length>160)throw new RoomError('방장 인증 정보를 확인해 주세요.');
      const hostHash=await digest(body.token);
      const state:Room={hostHash,hostSeen:Date.now(),members:[],match:null,hostFrame:0,epoch:0};
      await db.prepare('DELETE FROM sports_rooms WHERE expires < ?').bind(Date.now()).run();
      for(let attempt=0;attempt<5;attempt++) {
        const code=randomCode();
        const inserted=await db.prepare('INSERT OR IGNORE INTO sports_rooms (code,state,revision,expires) VALUES (?,?,0,?) RETURNING code')
          .bind(code,JSON.stringify(state),Date.now()+TTL).first<{code:string}>();
        if(inserted)return Response.json({code}, {headers});
      }
      throw new RoomError('방 생성이 지연되고 있어요. 다시 시도해 주세요.',503);
    }
    const code=String(body.code??'').trim().toUpperCase();
    if(!/^[A-Z2-9]{6}$/.test(code))throw new RoomError('6자리 방 코드를 입력해 주세요.');
    const tokenHash=typeof body.token==='string'?await digest(body.token):'';
    for(let retry=0;retry<12;retry++) {
      const row=await db.prepare('SELECT * FROM sports_rooms WHERE code = ? AND expires > ?').bind(code,Date.now()).first<Row>();
      if(!row)throw new RoomError('방이 없거나 종료되었어요. 방 코드를 확인해 주세요.',404);
      const room=JSON.parse(row.state) as Room;
      if(action==='watch')return Response.json({view:view(row,room)}, {headers});
      if(action==='join') {
        const existing=room.members.find(member=>member.tokenHash===tokenHash);
        if(existing)return Response.json({playerId:existing.id,view:view(row,room)}, {headers});
        if(room.match&&room.match.phase!=='lobby')throw new RoomError('이미 경기가 시작되었어요. 다음 경기까지 기다려 주세요.',409);
        if(room.members.length>=8)throw new RoomError('참가 인원 8명이 모두 찼어요.',409);
        const name=String(body.name??'').trim().slice(0,12);
        if(!name||!tokenHash)throw new RoomError('이름을 입력해 주세요.');
        const avatar=Number(body.avatar);
        const member:Member={id:crypto.randomUUID(),name,avatar:Number.isInteger(avatar)?Math.max(0,Math.min(7,avatar)):0,
          color:PLAYER_COLORS[room.members.length],ready:false,tokenHash,seen:Date.now(),seq:0,inputs:[]};
        room.members.push(member);
      } else if(action==='sync') {
        const member=room.members.find(candidate=>candidate.tokenHash===tokenHash);
        if(!member)throw new RoomError('참가 정보를 찾을 수 없어요. 다시 입장해 주세요.',403);
        member.seen=Date.now();
        if(typeof body.ready==='boolean'&&(!room.match||room.match.phase==='lobby'))member.ready=body.ready;
        if(Array.isArray(body.inputs)&&(room.match?.phase==='playing'||room.match?.phase==='results')) {
          for(const input of body.inputs.slice(0,40)) {
            if(!Number.isSafeInteger(input.seq)||input.seq<=member.seq||input.round!==room.match.number||
              !['A','B','C'].includes(input.button)||typeof input.down!=='boolean')continue;
            member.seq=input.seq;
            if(member.inputs.length<500)member.inputs.push({seq:input.seq,button:input.button,down:input.down,round:input.round,
              ...(Number.isFinite(input.heldMs)?{heldMs:Math.max(0,Math.min(4000,input.heldMs))}:{}),
              ...(Number.isFinite(input.at)?{at:Math.max(0,Math.min(120,input.at))}:{})});
          }
        }
      } else if(action==='host') {
        if(tokenHash!==room.hostHash)throw new RoomError('방장만 경기를 진행할 수 있어요.',403);
        room.hostSeen=Date.now();
        if(body.remove&&(!room.match||room.match.phase==='lobby'))room.members=room.members.filter(member=>member.id!==body.remove);
        if(body.reset) {room.epoch=(room.epoch??0)+1;room.match=null;room.hostFrame=0;room.appliedAck={};for(const member of room.members){member.inputs=[];member.ready=false;}}
        if(body.match&&Number(body.epoch??0)===(room.epoch??0)&&Number(body.frame)>room.hostFrame) {
          validateMatch(body.match,room);
          room.match=body.match;room.hostFrame=Number(body.frame);
        }
        for(const member of room.members) {
          const ack=Number(body.ack?.[member.id]??0);
          (room.appliedAck??={})[member.id]=Math.max(room.appliedAck?.[member.id]??0,ack);
          member.inputs=member.inputs.filter(input=>input.seq>ack);
        }
      } else if(action==='close') {
        if(tokenHash!==room.hostHash)throw new RoomError('방장만 방을 종료할 수 있어요.',403);
        await db.prepare('DELETE FROM sports_rooms WHERE code = ?').bind(code).run();
        return Response.json({closed:true}, {headers});
      } else throw new RoomError('요청 경로를 확인해 주세요.',404);
      const next=await db.prepare('UPDATE sports_rooms SET state = ?, revision = revision + 1, expires = ? WHERE code = ? AND revision = ? RETURNING revision')
        .bind(JSON.stringify(room),Date.now()+TTL,code,row.revision).first<{revision:number}>();
      if(!next)continue;
      row.revision=next.revision;row.expires=Date.now()+TTL;
      const member=room.members.find(candidate=>candidate.tokenHash===tokenHash);
      return Response.json({view:view(row,room),playerId:member?.id,ack:member?.seq??0,
        ...(action==='host'?{frame:room.hostFrame,epoch:room.epoch??0,inputs:room.members.flatMap(candidate=>candidate.inputs.map(input=>({...input,playerId:candidate.id})))}:{})}, {headers});
    }
    throw new RoomError('연결을 동기화하고 있어요. 잠시 후 다시 시도해 주세요.',503);
  } catch(error) {
    const status=error instanceof RoomError?error.status:error instanceof SyntaxError?400:500;
    if(status===500)console.error('Sports room request failed',error);
    return Response.json({error:status===500?'방 서버에 연결하지 못했어요. 잠시 후 다시 시도해 주세요.':(error as Error).message},{status,headers});
  }
}
