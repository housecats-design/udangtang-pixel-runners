import {roomApi, type Database} from './rooms.ts';
import {renderSiteDocument} from '../src/site-pages.ts';
// Populated from the verified Vite output by scripts/build-sports-worker.mjs.
import assets from './static-assets.generated.json';
const assetMap=assets as Record<string,{body:string;type:string}>;
const origins=new Set(['https://housecats-design.github.io','https://udangtang-pixel-runners.housecats850262.chatgpt.site']);
export default {
  async fetch(request:Request,env:{DB:Database}):Promise<Response> {
    const url=new URL(request.url);
    if(url.pathname.startsWith('/sports-api/')) {
      const origin=request.headers.get('origin');
      const allowed=!origin||origin===url.origin||origins.has(origin);
      if(!allowed)return new Response('Origin not allowed',{status:403});
      const response=request.method==='OPTIONS'?new Response(null,{status:204}):await roomApi(request,env.DB);
      const headers=new Headers(response.headers);
      if(origin)headers.set('Access-Control-Allow-Origin',origin);
      headers.set('Access-Control-Allow-Methods','POST, GET, OPTIONS');
      headers.set('Access-Control-Allow-Headers','Content-Type');
      headers.set('Vary','Origin');
      return new Response(response.body,{status:response.status,headers});
    }
    let path=url.pathname;
    if(path==='/')path='/index.html';
    const asset=assetMap[path];
    if(!asset)return new Response('Not found',{status:404});
    const binary=Uint8Array.from(atob(asset.body),character=>character.charCodeAt(0));
    if(path==='/index.html')return new Response(renderSiteDocument(new TextDecoder().decode(binary),url),{headers:{'Content-Type':asset.type,'Cache-Control':'no-cache'}});
    return new Response(binary,{headers:{'Content-Type':asset.type,'Cache-Control':path==='/index.html'?'no-cache':'public, max-age=86400'}});
  },
};
