import {createServer} from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync, readdirSync, mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {roomApi, type Database} from './rooms.ts';

mkdirSync('.openai/local-sports',{recursive:true});
const sqlite=new DatabaseSync('.openai/local-sports/rooms.sqlite');
for(const migration of readdirSync('drizzle').filter(name=>name.endsWith('.sql')).sort()) {
  // Local development uses the same schema, applied only when the database is empty.
  if(!sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='sports_rooms'").get())sqlite.exec(readFileSync(resolve('drizzle',migration),'utf8'));
}
const db:Database={prepare(sql) {
  let values:unknown[]=[];
  const statement={
    bind(...args:unknown[]) {values=args;return statement;},
    async first<T>() {return (sqlite.prepare(sql).get(...values as any[])??null) as T|null;},
    async all<T>() {return {results:sqlite.prepare(sql).all(...values as any[]) as T[]};},
    async run() {return sqlite.prepare(sql).run(...values as any[]);},
  };
  return statement;
}};
createServer(async (incoming,outgoing)=>{
  const chunks:Buffer[]=[];
  let bytes=0;
  for await(const chunk of incoming) {
    bytes+=chunk.length;
    if(bytes>90000) {outgoing.writeHead(413).end();return;}
    chunks.push(chunk);
  }
  const response=await roomApi(new Request(`http://localhost${incoming.url}`,{
    method:incoming.method,headers:{'content-type':'application/json'},
    ...(incoming.method==='POST'?{body:Buffer.concat(chunks).toString()}:{}),
  }),db);
  outgoing.writeHead(response.status,Object.fromEntries(response.headers));
  outgoing.end(await response.text());
}).listen(8787,'127.0.0.1',()=>console.log('Sports room API http://127.0.0.1:8787'));
