export function spokenNews(text:string){
  return text.replace(/[\p{Extended_Pictographic}\uFE0F\u200D]/gu,'')
    .replace(/·/g,', ').replace(/UFO/g,'유에프오').replace(/\s+/g,' ').trim();
}

export class NewsNarrator{
  readonly supported:boolean;
  private synthesis:SpeechSynthesis|null;
  private makeUtterance:(text:string)=>SpeechSynthesisUtterance;
  private onError:()=>void;
  private enabled=false;
  private current:SpeechSynthesisUtterance|null=null;
  private pending='';
  private lastText='';

  constructor(synthesis:SpeechSynthesis|null,
    makeUtterance=(text:string)=>new SpeechSynthesisUtterance(text),onError=()=>{}){
    this.synthesis=synthesis;this.supported=!!synthesis;
    this.makeUtterance=makeUtterance;this.onError=onError;
  }

  setEnabled(enabled:boolean){
    const next=enabled&&this.supported;
    if(next===this.enabled)return;
    this.enabled=next;
    if(!next)this.reset();
  }

  reset(){
    const speaking=!!this.current;
    this.current=null;this.pending='';this.lastText='';
    // Clear our state first: browsers may fire cancellation callbacks immediately.
    if(speaking)try{this.synthesis?.cancel();}catch{}
  }

  say(message:string){
    const text=spokenNews(message);
    if(!this.enabled||!text||text===this.lastText)return;
    this.lastText=text;
    // Finish the current sentence, retaining only the newest waiting news item.
    if(this.current){this.pending=text;return;}
    this.speak(text);
  }

  private speak(text:string){
    if(!this.enabled||!this.synthesis)return;
    try{
      const utterance=this.makeUtterance(text);
      utterance.lang='ko-KR';utterance.rate=2.5;utterance.pitch=1;utterance.volume=.9;
      const korean=this.synthesis.getVoices().filter(voice=>/^ko(?:[-_]|$)/i.test(voice.lang));
      // Look up voices on every sentence; the device may load them asynchronously.
      const voice=korean.find(voice=>voice.localService)??korean[0];
      if(voice)utterance.voice=voice;
      this.current=utterance;
      utterance.onend=()=>{
        if(this.current!==utterance)return;
        this.current=null;
        const next=this.pending;this.pending='';
        if(next)this.speak(next);
      };
      utterance.onerror=()=>{
        if(this.current!==utterance)return;
        this.current=null;this.pending='';this.lastText='';this.onError();
      };
      this.synthesis.speak(utterance);
    }catch{this.current=null;this.pending='';this.lastText='';this.onError();}
  }
}
