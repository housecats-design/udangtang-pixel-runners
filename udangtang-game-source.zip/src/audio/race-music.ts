// Original 8-bar chiptune: melody, offbeat chords, bass and a soft drum pulse.
// Audio-clock scheduling keeps the rhythm independent of rendering and race RNG.
const STEP_SECONDS=60/132/4;
const BARS=[
  [76,0,79,0,81,79,76,0,74,0,76,79,0,76,74,0],
  [72,0,76,0,79,76,72,0,74,0,76,0,74,72,0,0],
  [77,0,81,0,84,81,79,0,77,0,76,0,74,76,77,0],
  [79,0,83,0,86,83,81,0,79,0,77,0,76,74,0,0],
  [76,79,0,81,0,84,83,81,79,0,76,0,79,76,74,0],
  [72,76,0,79,0,81,79,76,74,0,72,0,76,74,72,0],
  [77,81,0,84,0,81,79,77,76,0,77,0,79,81,83,0],
  [79,0,77,76,74,0,71,0,72,0,76,0,79,0,0,0],
];
const CHORDS=[[48,52,55],[45,48,52],[53,57,60],[55,59,62],
  [48,52,55],[45,48,52],[53,57,60],[55,59,62]];
const LOOP_STEPS=BARS.length*16;
type Voice={oscillator:OscillatorNode;gain:GainNode};

export class RaceMusic{
  private timer:ReturnType<typeof setInterval>|null=null;
  private voices=new Set<Voice>();
  private queued:{step:number;time:number}[]=[];
  private step=0;
  private nextTime=0;
  private context:AudioContext;

  constructor(context:AudioContext){this.context=context;}

  setPlaying(playing:boolean){
    if(!playing){this.stop();return;}
    if(this.timer!==null||this.context.state!=='running')return;
    this.nextTime=this.context.currentTime+.035;
    this.schedule();
    this.timer=setInterval(()=>this.schedule(),25);
  }

  stop(reset=false){
    if(this.timer===null){if(reset)this.step=0;return;}
    clearInterval(this.timer);
    this.timer=null;
    const now=this.context.currentTime;
    // Rewind any notes queued ahead of the audible playhead before resuming.
    const pending=this.queued.find(note=>note.time>now);
    if(pending)this.step=pending.step;
    this.queued=[];
    for(const {oscillator,gain} of this.voices){
      gain.gain.cancelScheduledValues(now);
      gain.gain.setTargetAtTime(0,now,.004);
      oscillator.stop(now+.02);
    }
    if(reset)this.step=0;
  }

  private schedule(){
    const now=this.context.currentTime;
    this.queued=this.queued.filter(note=>note.time>now);
    // A stalled tab must not queue a burst of overdue notes.
    if(this.nextTime<now)this.nextTime=now+.035;
    while(this.nextTime<now+.16){
      this.queued.push({step:this.step,time:this.nextTime});
      this.playStep(this.step,this.nextTime);
      this.step=(this.step+1)%LOOP_STEPS;
      this.nextTime+=STEP_SECONDS;
    }
  }

  private note(midi:number,time:number,duration:number,volume:number,type:OscillatorType){
    const oscillator=this.context.createOscillator();
    const gain=this.context.createGain();
    const voice={oscillator,gain};
    // Keep not-yet-started voices silent even if mute cancels their envelope.
    gain.gain.value=0;
    oscillator.type=type;
    oscillator.frequency.setValueAtTime(440*2**((midi-69)/12),time);
    gain.gain.setValueAtTime(0,time);
    gain.gain.linearRampToValueAtTime(volume,time+.008);
    gain.gain.exponentialRampToValueAtTime(.0001,time+duration);
    oscillator.connect(gain);
    gain.connect(this.context.destination);
    this.voices.add(voice);
    oscillator.onended=()=>{
      oscillator.disconnect();gain.disconnect();this.voices.delete(voice);
    };
    oscillator.start(time);
    oscillator.stop(time+duration+.01);
    return oscillator;
  }

  private playStep(step:number,time:number){
    const bar=Math.floor(step/16),beat=step%16;
    const melody=BARS[bar][beat],chord=CHORDS[bar];
    if(melody)this.note(melody,time,STEP_SECONDS*1.65,.013,'square');
    if(beat%4===0)this.note(chord[0]+(beat===8?7:0)-12,time,STEP_SECONDS*3.2,.038,'triangle');
    if(beat%4===2)for(const pitch of chord)this.note(pitch+12,time,STEP_SECONDS*1.4,.009,'triangle');
    if(beat%4===0){
      const kick=this.note(38,time,.12,.035,'sine');
      kick.frequency.exponentialRampToValueAtTime(35,time+.1);
    }
    if(beat%4===2)this.note(beat%8===6?94:90,time,.035,.003,'square');
  }
}
