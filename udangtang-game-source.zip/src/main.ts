import './style.css';
import {avatars,palettes,newParticipant,type Participant,type Settings} from './data/avatars.ts';
import {load,save,defaultSettings,STORAGE_KEY} from './storage/store.ts';
import {Race,STEP,PIXELS_PER_METER} from './simulation/engine.ts';
import {Renderer,avatarURL,sprite,loadRunnerAtlas,hasActionAtlas} from './rendering/renderer.ts';
import {shuffleLineup} from './ui/lineup.ts';
import {LOLLIPOP_ROUNDS} from './simulation/lollipop.ts';
import {LollipopWheel} from './ui/lollipop.ts';
const $=<T extends HTMLElement=HTMLElement>(selector:string)=>document.querySelector<T>(selector)!;
const app=$('#app');
const boot=(()=>{try{return load(localStorage);}catch{return {data:null,error:true};}})();
let participants:Participant[]=boot.data?.participants??Array.from({length:8},(_,i)=>newParticipant(i));
let displayOrder=participants.map(p=>p.id);
let settings:Settings=boot.data?.settings??{...defaultSettings};
let state:'setup'|'countdown'|'racing'|'paused'|'results'='setup';
let race:Race|null=null;let accumulator=0;let lastFrame=0;let countdownLeft=3;let resumeState:'countdown'|'racing'='racing';let hudTick=0;let saveTimer:ReturnType<typeof setTimeout>;let countdownTone=4;let toastTimer:ReturnType<typeof setTimeout>;
const escape=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const clock=(s:number)=>{const t=Math.ceil(Math.max(0,s));return `${Math.floor(t/60).toString().padStart(2,'0')}:${(t%60).toString().padStart(2,'0')}`;};
const distanceLabel=(m:number)=>m===1000?'1km':`${m}m`;
const arrivalLabel=(time:number|null)=>time===null?'달리는 중':`${Math.floor(time/60).toString().padStart(2,'0')}:${(time%60).toFixed(2).padStart(5,'0')}`;
app.innerHTML=`
<header><div class="brand"><div class="logo" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><path d="M15 3h8v7h-8zM10 12h10v6H10zM6 12h5v5H6zM19 15h7v4h-7zM11 18h7v6h-7zM5 23h10v5H5zM18 21h5v7h-5z" fill="#fff8dc"/><path d="M23 4h3v5h-3z" fill="#466348"/></svg></div><div><div class="brand-title">우당탕 달리기</div><div class="brand-sub">LITTLE RUNNERS, BIG LUCK</div></div></div><div class="header-right"><span class="pill"><i class="dot"></i> 오늘도 신나는 한 판</span><button class="help" id="help"><span>?</span> 이용 가이드</button></div></header>
<main><div class="intro"><div><div class="eyebrow">READY, SET, A LITTLE BIT OF LUCK!</div><h1>열심히 달리고, <em>행운을 만나고.</em></h1><p>누가 뽑힐지는 아무도 몰라요. 오늘의 주인공을 만나볼까요?</p></div><div class="weather"><i class="sun"></i><div>달리기 딱 좋은 날씨<br><span style="color:#a1ac91;font-size:9px">숲속 운동장에서 만나요</span></div></div></div>
<div class="layout">
<aside class="panel setup-card" id="setup-menu" aria-label="레이스 준비">
  <div class="setup-tabs" id="setup-tabs" role="tablist" aria-label="레이스 준비">
    <button type="button" id="settings-tab" role="tab" aria-selected="true" aria-controls="settings-panel">레이스 세팅</button>
    <button type="button" id="roster-tab" role="tab" aria-selected="false" aria-controls="roster-panel" tabindex="-1">함께 달릴 친구들 <span class="count-badge" id="participant-count" aria-hidden="true">8 / 35</span></button>
  </div>
  <div id="settings-panel" role="tabpanel" aria-labelledby="settings-tab">
    <div class="settings-grid"><div><div class="field-label">얼마나 달릴까요? <small>코스 길이 선택</small></div><div class="duration-options">${[300,500,1000].map(m=>`<button class="duration-option" data-distance="${m}">${distanceLabel(m)}</button>`).join('')}</div><p class="distance-hint">결승선까지 달리는 거리 레이스</p></div><div><div class="field-label">누가 행운의 주인공? <small>당첨 기준 선택</small></div><div class="rule-options"><button class="rule-option" data-rule="first"><span class="rule-emoji">🏆</span><span><strong>1등이 당첨!</strong><small>가장 먼저 도착한 친구</small></span></button><button class="rule-option" data-rule="last"><span class="rule-emoji">🍀</span><span><strong>꼴찌가 당첨!</strong><small>마지막에 남은 친구</small></span></button></div></div></div>
  </div>
  <div id="roster-panel" role="tabpanel" aria-labelledby="roster-tab" hidden>
    <h2 class="race-roster-heading" id="race-roster-heading" hidden>함께 달릴 친구들</h2>
    <div class="roster-tools">
      <div class="count-control"><label for="count">인원</label><input id="count" type="number" min="2" max="35" value="8" aria-label="참가 인원"/><span>명</span><button id="apply-count" title="인원 적용" aria-label="인원 적용">✓</button></div>
      <button id="bulk">☷ 이름 한 번에 넣기</button>
    </div>
    <div class="roster-actions">
      <button class="lineup-shuffle" id="shuffle-start">↕ 출발 위치 섞기</button>
      <button class="icon-btn" id="reset" title="명단과 설정 초기화" aria-label="명단과 설정 초기화">↺</button>
    </div>
    <ol class="participant-list" id="participant-list"></ol>
    <button class="add-participant" id="add">＋ 친구 추가하기</button>
  </div>
  <div class="setup-footer" id="setup-footer">
    <div class="start-row"><div class="summary" id="summary"></div><button class="primary-btn" id="start">다 같이 달리기 <span>→</span></button></div>
    <div class="save-status" id="save-status">✓ 이 브라우저에 자동 저장돼요</div>
  </div>
</aside>
<div class="main-column"><section class="stage" aria-label="레이스 경기장"><div class="stage-top"><div class="stage-label"><span class="live-tag" id="stage-tag">PREVIEW</span><span id="stage-title">숲속 우당탕 운동장</span></div><div class="stage-actions"><span class="stage-meta">무조작 · 랜덤 장애물 레이스</span><button class="round-btn" id="sound" aria-label="소리 끄기" title="소리 끄기">♫</button><button class="round-btn hidden" id="race-details" aria-label="실시간 순위" title="실시간 순위" aria-expanded="false">☷</button><button class="round-btn hidden" id="stage-stop" aria-label="경기 중단" title="경기 중단">■</button><button class="round-btn hidden" id="fullscreen" aria-label="전체화면 나가기" title="전체화면 나가기">⛶</button><button class="round-btn hidden" id="pause" aria-label="일시정지" title="일시정지">Ⅱ</button></div></div>
<div class="canvas-wrap"><canvas class="game-canvas" id="game" aria-label="픽셀 캐릭터들이 왼쪽에서 오른쪽으로 자동으로 달리는 경기장"></canvas><span class="preview-tag" id="preview-tag">출발 전, 몸 푸는 중</span><div class="hud hidden" id="hud"><div class="timer-card"><div class="timer-label" id="race-progress-label">결승선까지</div><div class="timer" id="timer">300m</div></div><div id="race-news" class="race-news" role="marquee" aria-label="운동장 소식"><span id="race-news-text"></span></div><div class="follow-card"><span id="follow-rule">1등을 따라가는 중</span><strong id="follow-name"></strong></div></div><div id="last-place-banner" class="last-place-banner hidden" role="status">꼴찌 확정!<small>그 자리에서 눈물이 뚝뚝…</small></div><div class="course-badge">WOODLAND PLAYGROUND · 01</div><div class="lollipop-overlay" id="lollipop-overlay" hidden>
  <div class="lollipop-card">
    <p class="lollipop-round"></p>
    <h2>갑자기 누군가 막대사탕을 던졌다!</h2>
    <div class="lollipop-wheel"><i aria-hidden="true"></i><canvas width="420" height="420" role="img" aria-label="룰렛 참가자"></canvas></div>
    <p class="lollipop-caption" role="status" aria-live="polite"></p>
  </div>
</div><div class="overlay hidden" id="overlay"></div></div>
<div class="position-panel"><div class="position-header"><strong>↔ 모두의 위치</strong><span id="position-description">같은 출발선에서 함께 시작해요</span></div><div class="position-track" id="position-track"></div><div class="position-ticks"><span id="min-distance">출발선 0 m</span><span id="mid-distance">모든 친구가 준비 중이에요</span><span id="max-distance">LET’S RUN →</span></div></div></section>
<section class="hidden" id="race-panel"><div class="race-info"><div class="race-card"><h3 id="ranking-title">지금 선두는?</h3><ol class="ranking-list" id="live-ranking"></ol></div></div><div class="race-controls"><button class="secondary-btn" id="stop">경기 중단</button><button class="primary-btn" id="bottom-pause">잠깐 쉬어가기 Ⅱ</button></div></section>
<div class="obstacle-guide"><span>💧 웅덩이</span><span>▰ 진흙</span><span>✣ 회전 봉</span><span>⚒ 왕복 망치</span><span>↔ 이동 발판</span><span>🛸 UFO 냉동</span><span>↶ 반전 점프대</span><span>🍱 식사</span><span>🥤 음료 휴식</span><span>✦ 앞뒤 견인 광선</span><span>✋ 옷자락 잡기</span><span>👟 장난 발차기</span><span>📱 전화</span><span>🍌 바나나 껍질</span><span>🕳 구멍</span><span>🛏 체력 회복</span><span>🧱 거대한 벽</span><span>🍭 막대사탕 룰렛</span></div><p class="tiny-note">♧ 조작은 필요 없어요. 응원하는 마음만 챙겨오세요!</p></div></div>
<footer class="footer"><span class="footer-brand">SMALL PIXELS. HAPPY MOMENTS.</span><div class="footer-links"><span>최대 35명</span><span>·</span><span>로그인 없이 가볍게</span><span>·</span><span>MADE FOR A LITTLE FUN</span></div></footer></main>
<dialog id="bulk-dialog"><div class="dialog-head"><h2>함께 달릴 이름을 넣어주세요</h2><button data-close aria-label="닫기">×</button></div><p class="dialog-description">한 줄에 한 명씩, 또는 쉼표로 나눠주세요.<br>2~35명 · 이름은 최대 12자 · 같은 이름도 괜찮아요.</p><textarea class="bulk-textarea" id="bulk-input" placeholder="참가자 1&#10;참가자 2&#10;참가자 3" aria-label="참가자 이름 일괄 입력"></textarea><div class="dialog-error" id="bulk-error" aria-live="polite"></div><div class="dialog-actions"><button class="secondary-btn" data-close>취소</button><button class="primary-btn" id="bulk-apply">명단 적용하기</button></div></dialog>
<dialog id="avatar-dialog"><div class="dialog-head"><h2>오늘의 달리기 패션</h2><button data-close aria-label="닫기">×</button></div><p class="dialog-description">어떤 모습이든 달리는 실력은 같아요.</p><div class="avatar-grid" id="avatar-grid"></div><div class="palette-row" id="palette-row"></div><div class="dialog-actions"><button class="primary-btn" data-close>이 모습으로 준비 완료 ✓</button></div></dialog>
<dialog id="help-dialog"><div class="dialog-head"><h2>행운을 만나는 방법</h2><button data-close aria-label="닫기">×</button></div><ol class="help-list"><li>함께 달릴 친구 2~35명의 이름을 넣어요.</li><li>캐릭터를 눌러 좋아하는 모습을 골라요.</li><li>300m·500m·1km 코스와 1등 / 꼴찌 당첨 기준을 정해요.</li><li>출발! 캐릭터는 스스로 장애물을 만나요.</li><li>1등은 도착 순서, 꼴찌는 마지막 한 명이 남는 순간 그 자리에서 확정해요.</li></ol><p class="dialog-description">이름과 설정은 현재 브라우저에 저장돼요. 다른 탭으로 이동하면 경기가 멈추고, 돌아온 뒤 재개할 수 있어요. 새로고침하면 진행 중인 경기는 끝나요.<br><br>도착 시각이 정확히 같으면 경기 시드로 추가 추첨해요. 외형은 성능에 영향을 주지 않아요. 꼴찌도 오늘의 행운의 주인공이에요!</p><div class="dialog-actions"><button class="primary-btn" data-close>좋아요, 달려볼까요?</button></div></dialog>
<dialog id="confirm-dialog"><div class="dialog-head"><h2>잠깐, 확인해주세요</h2></div><p class="dialog-description" id="confirm-message"></p><div class="dialog-actions"><button class="secondary-btn" id="confirm-no">취소</button><button class="primary-btn" id="confirm-yes">확인</button></div></dialog><dialog id="result-dialog" class="result-dialog"></dialog><div class="toast hidden" id="toast" role="status"></div>`;
const settingsTab=$<HTMLButtonElement>('#settings-tab');
const rosterTab=$<HTMLButtonElement>('#roster-tab');
const setupTabs=[settingsTab,rosterTab];
let activeSetupTab=settingsTab;
function showSetupTab(selected:HTMLButtonElement){
  for(const tab of setupTabs){
    const active=tab===selected;
    tab.setAttribute('aria-selected',String(active));
    tab.tabIndex=active?0:-1;
    $(`#${tab.getAttribute('aria-controls')}`).hidden=!active;
  }
}
function selectSetupTab(tab:HTMLButtonElement){
  activeSetupTab=tab;
  showSetupTab(tab);
}
for(const tab of setupTabs){
  tab.onclick=()=>selectSetupTab(tab);
  tab.onkeydown=event=>{
    const next=event.key==='Home'?settingsTab:event.key==='End'?rosterTab:
      event.key==='ArrowLeft'||event.key==='ArrowRight'?setupTabs.find(candidate=>candidate!==tab):null;
    if(!next)return;
    event.preventDefault();
    selectSetupTab(next);
    next.focus();
  };
}
function setSetupLocked(locked:boolean){
  $('#setup-menu').classList.toggle('locked',locked);
  $('#setup-tabs').hidden=locked;
  $('#setup-footer').hidden=locked;
  $('#race-roster-heading').hidden=!locked;
  $('#roster-panel').setAttribute('role',locked?'region':'tabpanel');
  $('#roster-panel').setAttribute('aria-labelledby',locked?'race-roster-heading':'roster-tab');
  document.querySelectorAll<HTMLInputElement>('.name-input').forEach(input=>{
    input.readOnly=locked;
    input.tabIndex=locked?-1:0;
  });
  document.querySelectorAll<HTMLButtonElement>('.avatar-btn').forEach(button=>{button.disabled=locked;});
  showSetupTab(locked?rosterTab:activeSetupTab);
}
const renderer=new Renderer($<HTMLCanvasElement>('#game'));
const lollipopWheel=new LollipopWheel($('#lollipop-overlay'));
let lollipopAge=-1;
const DUEL_SLOW_SECONDS=1.25;
const DUEL_SLOW_RATE=.4;
let duelSlowLeft=0;
let shownOvertake:Race['duelOvertake']=null;
function hasPendingLollipop(activeRace:Race|null){return activeRace?.lollipop?.resolved===false;}
function updateDuelIndicator(active:boolean){
  const tag=$('#stage-tag');
  tag.classList.toggle('duel-slow',active);
  if(state!=='racing'||hasPendingLollipop(race))return;
  if(active&&tag.textContent!=='SLOW'){
    tag.textContent='SLOW';$('#stage-title').textContent='꼴찌 경쟁 · 순위 역전';
  }else if(!active&&tag.textContent==='SLOW'){
    tag.textContent='LIVE';$('#stage-title').textContent='우당탕! 지금 달리는 중';
  }
}
function resetLollipop(){
  lollipopAge=-1;
  lollipopWheel.hide();
}
function animateLollipop(activeRace:Race,delta:number){
  const lollipop=activeRace.lollipop;
  if(!lollipop||lollipop.resolved)return;
  if(lollipopAge<0){
    lollipopAge=0;
    lollipopWheel.prepare(lollipop,activeRace.runners.map(r=>r.participant.name));
    $('#stage-tag').textContent='ROULETTE';
    $('#stage-title').textContent=`막대사탕 룰렛 ${lollipop.round} / ${LOLLIPOP_ROUNDS}`;
    $('#race-news').classList.add('paused');
    tone(620,.22);
  }
  lollipopAge+=delta;
  if(lollipopWheel.render(lollipopAge)){
    activeRace.resolveLollipop();
    if(lollipop.reward==='swap'||lollipop.reward==='restart')duelSlowLeft=0;
    resetLollipop();
    $('#stage-tag').textContent='LIVE';
    $('#stage-title').textContent='우당탕! 지금 달리는 중';
    $('#race-news').classList.remove('paused');
    tone(880,.22);
  }
}
let hadNativeFullscreen=false;
function setFocus(enabled:boolean){
  document.body.classList.toggle('race-focus',enabled);
  $('#race-details').classList.toggle('hidden',!enabled||state==='setup'||state==='results');
  $('#fullscreen').setAttribute('aria-label',enabled?'전체화면 나가기':'전체화면으로 보기');
  $('#fullscreen').title=enabled?'전체화면 나가기':'전체화면으로 보기';
  requestAnimationFrame(()=>renderer.resize());
}
function enterRaceView(){
  setFocus(true);
  // Call synchronously from the Start/Rematch click to preserve user activation.
  if(!document.fullscreenElement&&document.documentElement.requestFullscreen){
    void document.documentElement.requestFullscreen().then(()=>{hadNativeFullscreen=true;renderer.resize();}).catch(()=>{ /* App/webview fallback: viewport-filling race view. */ });
  }
}
function leaveRaceView(){
  setFocus(false);
  if(document.fullscreenElement&&document.exitFullscreen)void document.exitFullscreen().catch(()=>{});
}
document.addEventListener('fullscreenchange',()=>{
  if(document.fullscreenElement)hadNativeFullscreen=true;
  else if(hadNativeFullscreen){hadNativeFullscreen=false;setFocus(false);}
});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!document.fullscreenElement&&!document.querySelector('dialog[open]'))setFocus(false);});
$('#fullscreen').onclick=()=>{if(document.body.classList.contains('race-focus'))leaveRaceView();else enterRaceView();};
$('#race-details').onclick=()=>{const open=$('#race-panel').classList.toggle('show-details');$('#race-details').setAttribute('aria-expanded',String(open));};
const seenEffects=new Set<string>();
let lastTickerId=0;
let tickerNextAt=0;
let tickerMessage='';
const featuredNews=new Set(['grab','kick','phone','boost','banana','pit','sleep','wake','wall','giant','rainbow','lollipop-win','lollipop-global','catch-up','duel-overtake']);
function setRaceNews(message:string,elapsed:number){
  const ticker=$('#race-news'),line=$('#race-news-text');
  tickerMessage=message;line.textContent=message;ticker.title=message;
  line.classList.remove('scrolling');
  const viewport=ticker.clientWidth,travel=viewport+line.scrollWidth;
  const scroll=line.scrollWidth>viewport-12&&!matchMedia('(prefers-reduced-motion: reduce)').matches;
  const seconds=scroll?Math.max(3.4,travel/61):3.4;
  tickerNextAt=elapsed+seconds;
  if(scroll){
    line.style.setProperty('--news-width',`${viewport}px`);
    line.style.setProperty('--news-duration',`${seconds}s`);
    void line.offsetWidth;
    line.classList.add('scrolling');
  }
}
function updateRaceNews(activeRace:Race){
  if(state==='countdown'){
    if(!tickerMessage)setRaceNews('출발 준비 중',0);
    return;
  }
  if(state==='paused'||activeRace.lollipop?.resolved===false)return;
  if(state==='racing'&&tickerMessage==='출발 준비 중'){
    setRaceNews('출발! 운동장 소식을 기다리는 중',activeRace.elapsed);return;
  }
  if(!activeRace.finished&&activeRace.elapsed<tickerNextAt)return;
  const pending=activeRace.events.filter(e=>e.id>lastTickerId);
  const latest=activeRace.finished?pending[0]:[...pending].reverse().find(e=>featuredNews.has(e.kind)&&activeRace.elapsed-e.time<10)??pending[0];
  if(latest){
    lastTickerId=latest.id;
    const prefix=latest.kind==='lollipop-global'||latest.kind==='lollipop'?'🍭 ':`${activeRace.runners[latest.runner].participant.name} · `;
    setRaceNews(prefix+latest.text,activeRace.elapsed);
  }else if(!activeRace.finished&&tickerMessage&&$('#race-news-text').classList.contains('scrolling')){
    setRaceNews(tickerMessage,activeRace.elapsed);
  }
}

function toast(text:string){$('#toast').textContent=text;$('#toast').classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.add('hidden'),3500);}
function persist(){clearTimeout(saveTimer);$('#save-status').textContent='… 저장하는 중';saveTimer=setTimeout(()=>{let ok=false;try{ok=save(localStorage,participants,settings);}catch{}$('#save-status').textContent=ok?'✓ 이름과 설정이 자동 저장되었어요':'! 저장할 수 없어요. 이번 게임은 계속 즐길 수 있어요';$('#save-status').classList.toggle('error',!ok);},350);}
function renderRoster(){
  displayOrder=[...displayOrder.filter(id=>participants.some(p=>p.id===id)),...participants.map(p=>p.id).filter(id=>!displayOrder.includes(id))];
  $('#participant-list').innerHTML=participants.map((p,i)=>`<li class="participant" data-id="${escape(p.id)}"><span class="participant-num">${String(i+1).padStart(2,'0')}</span><button class="avatar-btn" data-avatar="${escape(p.id)}" title="${escape(p.name)} 캐릭터 선택" aria-label="${escape(p.name)} 캐릭터 선택"><img src="${avatarURL(p)}" alt=""/></button><input class="name-input" value="${escape(p.name)}" maxlength="12" data-name="${escape(p.id)}" aria-label="참가자 ${i+1} 이름" autocomplete="off"/><button class="remove-btn" data-remove="${escape(p.id)}" aria-label="참가자 ${i+1} 삭제" ${participants.length<=2?'disabled':''}>×</button></li>`).join('');
  $('#participant-count').textContent=`${participants.length} / 35`;$<HTMLInputElement>('#count').value=String(participants.length);$<HTMLButtonElement>('#add').disabled=participants.length>=35;renderSettings();
}
function renderSettings(){
  document.querySelectorAll<HTMLButtonElement>('[data-distance]').forEach(b=>{const selected=Number(b.dataset.distance)===settings.distanceMeters;b.classList.toggle('active',selected);b.setAttribute('aria-pressed',String(selected));});
  document.querySelectorAll<HTMLButtonElement>('[data-rule]').forEach(b=>{const selected=b.dataset.rule===settings.winnerRule;b.classList.toggle('active',selected);b.setAttribute('aria-pressed',String(selected));});
  $('#summary').innerHTML=`<strong>${participants.length}명</strong>이 <strong>${distanceLabel(settings.distanceMeters)}</strong>를 달려요 <span style="color:#b0b9a0">|</span> <strong>${settings.winnerRule==='first'?'1등':'꼴찌'}</strong> 당첨<small>장애물 앞에선 모두가 평등! 끝날 때까지 알 수 없어요.</small>`;
  $('#sound').textContent=settings.soundEnabled?'♫':'♪̸';$('#sound').setAttribute('aria-label',settings.soundEnabled?'소리 끄기':'소리 켜기');$('#sound').title=settings.soundEnabled?'소리 끄기':'소리 켜기';
}
let audio:AudioContext|null=null;
function unlockAudio(){if(!audio)try{audio=new AudioContext();}catch{}if(audio?.state==='suspended')void audio.resume();}
function tone(freq=520,duration=.12){if(!settings.soundEnabled||!audio)return;try{const o=audio.createOscillator(),g=audio.createGain();o.type='square';o.frequency.value=freq;g.gain.setValueAtTime(.025,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+duration);o.connect(g);g.connect(audio.destination);o.start();o.stop(audio.currentTime+duration);}catch{}}
function dialog(id:string){$<HTMLDialogElement>(id).showModal();}
function ask(message:string):Promise<boolean>{const d=$<HTMLDialogElement>('#confirm-dialog');if(d.open)return Promise.resolve(false);$('#confirm-message').textContent=message;d.returnValue='';d.showModal();return new Promise(resolve=>{d.addEventListener('close',()=>resolve(d.returnValue==='yes'),{once:true});$('#confirm-yes').onclick=()=>d.close('yes');$('#confirm-no').onclick=()=>d.close('no');});}
document.addEventListener('click',e=>{const el=(e.target as HTMLElement).closest<HTMLElement>('[data-close]');if(el)el.closest('dialog')?.close();});
$('#help').onclick=()=>{if(state==='racing'||state==='countdown')pauseRace('이용 가이드를 확인하는 동안 잠시 멈췄어요.');dialog('#help-dialog');};
$('#shuffle-start').onclick=()=>{if(state!=='setup')return;displayOrder=shuffleLineup(displayOrder);toast('같은 출발선에서 위아래 자리만 섞었어요.');};
$('#add').onclick=()=>{if(state!=='setup'||participants.length>=35)return;participants.push(newParticipant(participants.length));renderRoster();persist();$('#participant-list').lastElementChild?.scrollIntoView({block:'nearest'});};
$('#participant-list').addEventListener('input',e=>{const input=e.target as HTMLInputElement;const p=participants.find(p=>p.id===input.dataset.name);if(p){p.name=input.value;persist();}});
$('#participant-list').addEventListener('click',e=>{if(state!=='setup')return;const el=(e.target as HTMLElement).closest<HTMLElement>('[data-remove],[data-avatar]');if(!el)return;if(el.dataset.remove&&participants.length>2){participants=participants.filter(p=>p.id!==el.dataset.remove);renderRoster();persist();}else if(el.dataset.avatar)openAvatar(el.dataset.avatar);});
const applyCount=async()=>{if(state!=='setup')return;const n=Number($<HTMLInputElement>('#count').value);if(!Number.isInteger(n)||n<2||n>35){toast('참가 인원은 2~35명으로 정해주세요.');$<HTMLInputElement>('#count').value=String(participants.length);return;}if(n===participants.length)return;if(n<participants.length&&!await ask(`뒤쪽 참가자 ${participants.length-n}명의 이름과 캐릭터를 삭제할까요?`)){$<HTMLInputElement>('#count').value=String(participants.length);return;}participants=participants.slice(0,n);while(participants.length<n)participants.push(newParticipant(participants.length));renderRoster();persist();};
$('#count').addEventListener('change',applyCount);$('#apply-count').onclick=applyCount;
$('#bulk').onclick=()=>{$<HTMLTextAreaElement>('#bulk-input').value=participants.map(p=>p.name).join('\n');$('#bulk-error').textContent='';dialog('#bulk-dialog');};
$('#bulk-apply').onclick=async()=>{const names=$<HTMLTextAreaElement>('#bulk-input').value.split(/[\n,]/).map(n=>n.trim()).filter(Boolean);if(names.length<2||names.length>35){$('#bulk-error').textContent=`${names.length}명이 입력되었어요. 2~35명으로 정리해주세요.`;return;}if(names.some(n=>n.length>12)){$('#bulk-error').textContent='12자를 넘는 이름이 있어요. 이름을 짧게 정리해주세요.';return;}if(names.length<participants.length&&!await ask(`명단을 바꾸면 뒤쪽 참가자 ${participants.length-names.length}명이 삭제됩니다. 적용할까요?`))return;participants=names.map((name,i)=>({...participants[i]??newParticipant(i),name}));renderRoster();persist();$<HTMLDialogElement>('#bulk-dialog').close();};
let editingId='';
function openAvatar(id:string){editingId=id;renderAvatarChoices();dialog('#avatar-dialog');}
function renderAvatarChoices(){const p=participants.find(p=>p.id===editingId)!;$('#avatar-grid').innerHTML=avatars.map(a=>`<button class="avatar-choice ${a.id===p.avatarId?'selected':''}" data-avatar-choice="${a.id}" aria-pressed="${a.id===p.avatarId}"><img src="${avatarURL({...p,avatarId:a.id})}" alt=""/>${a.name}</button>`).join('');$('#palette-row').innerHTML=palettes.map((color,i)=>`<button class="palette-choice ${p.paletteId===color?'selected':''}" style="background:${color}" data-palette="${color}" aria-label="의상 포인트 색상 ${i+1}" aria-pressed="${p.paletteId===color}"></button>`).join('');}
$('#avatar-dialog').addEventListener('click',e=>{const el=(e.target as HTMLElement).closest<HTMLElement>('[data-avatar-choice],[data-palette]');if(!el)return;const p=participants.find(p=>p.id===editingId)!;if(el.dataset.avatarChoice)p.avatarId=el.dataset.avatarChoice;if(el.dataset.palette)p.paletteId=el.dataset.palette;renderAvatarChoices();renderRoster();persist();});
$('#reset').onclick=async()=>{if(state!=='setup')return;if(await ask('저장된 이름, 캐릭터, 경기 설정을 모두 초기화할까요?')){participants=Array.from({length:8},(_,i)=>newParticipant(i));settings={...defaultSettings};try{localStorage.removeItem(STORAGE_KEY);}catch{}renderRoster();persist();toast('새로운 친구들과 다시 준비했어요.');}};
document.querySelectorAll<HTMLButtonElement>('[data-distance]').forEach(b=>b.onclick=()=>{settings.distanceMeters=Number(b.dataset.distance) as Settings['distanceMeters'];renderSettings();renderPosition();persist();});
document.querySelectorAll<HTMLButtonElement>('[data-rule]').forEach(b=>b.onclick=()=>{settings.winnerRule=b.dataset.rule as 'first'|'last';renderSettings();persist();});
$('#sound').onclick=()=>{unlockAudio();settings.soundEnabled=!settings.soundEnabled;renderSettings();persist();if(settings.soundEnabled)tone(660);};
function validate(){if(participants.length<2||participants.length>35){toast('2~35명이 함께 달릴 수 있어요.');return false;}const empty=participants.find(p=>!p.name.trim());if(empty){toast('모든 친구의 이름을 채워주세요.');selectSetupTab(rosterTab);document.querySelector<HTMLInputElement>(`[data-name="${empty.id}"]`)?.focus();return false;}participants.forEach(p=>p.name=p.name.trim());return true;}
function startRace(){if(!validate())return;leaveRaceView();unlockAudio();persist();const seed=crypto.getRandomValues(new Uint32Array(1))[0];race=new Race(participants,settings.distanceMeters,seed,settings.winnerRule,displayOrder);resetLollipop();renderer.camera=-renderer.width*.24;renderer.targetIndex=0;renderer.candidate=-1;state='countdown';perfFrames=0;perfSeconds=0;countdownLeft=3;countdownTone=4;accumulator=0;lastFrame=0;hudTick=0;seenEffects.clear();$('#last-place-banner').classList.add('hidden');resultCryFrames=[];lastResultCryFrame=-1;lastTickerId=0;tickerNextAt=0;tickerMessage='';$('#race-news').classList.remove('paused');$('#race-panel').classList.remove('show-details');$('#race-details').setAttribute('aria-expanded','false');for(const id of ['#fullscreen','#stage-stop'])$(id).classList.remove('hidden');
  duelSlowLeft=0;shownOvertake=null;
  setSetupLocked(true);$('#race-panel').classList.remove('hidden');$('#hud').classList.remove('hidden');$('#preview-tag').classList.add('hidden');$('#pause').classList.remove('hidden');$('#stage-tag').textContent='READY';$('#stage-title').textContent='두근두근, 출발 준비!';
  $('#overlay').classList.remove('hidden');updateHUD();
}
$('#start').onclick=startRace;
function pauseRace(message='숨 한번 고르고, 다시 달려요.'){if(state!=='racing'&&state!=='countdown')return;resumeState=state;state='paused';lollipopWheel.hide();$('#race-news').classList.add('paused');$('#stage-tag').textContent='PAUSED';$('#overlay').classList.remove('hidden');$('#overlay').innerHTML=`<div class="pause-card"><h3>잠깐, 쉬어가요.</h3><p>${escape(message)}<br>경기 시간은 흐르지 않아요.</p><button class="primary-btn" id="resume">다시 달리기 →</button></div>`;$('#resume').onclick=resumeRace;$('#bottom-pause').textContent='다시 달리기 →';$('#pause').textContent='▶';$('#pause').setAttribute('aria-label','경기 재개');}
function resumeRace(){if(state!=='paused')return;state=resumeState;lastFrame=0;$('#race-news').classList.remove('paused');if(state==='racing')$('#overlay').classList.add('hidden');$('#stage-tag').textContent=race?.lollipop?.resolved===false?'ROULETTE':state==='racing'?'LIVE':'READY';$('#bottom-pause').textContent='잠깐 쉬어가기 Ⅱ';$('#pause').textContent='Ⅱ';$('#pause').setAttribute('aria-label','일시정지');}
function togglePause(){if(state==='paused')resumeRace();else pauseRace();}
$('#pause').onclick=togglePause;$('#bottom-pause').onclick=togglePause;
function setup(){leaveRaceView();$('#last-place-banner').classList.add('hidden');resultCryFrames=[];for(const id of ['#fullscreen','#race-details','#stage-stop'])$(id).classList.add('hidden');state='setup';race=null;resetLollipop();accumulator=0;setSetupLocked(false);$('#race-panel').classList.add('hidden');$('#hud').classList.add('hidden');$('#preview-tag').classList.remove('hidden');$('#pause').classList.add('hidden');$('#overlay').classList.add('hidden');$('#stage-tag').textContent='PREVIEW';$('#stage-title').textContent='숲속 우당탕 운동장';$('.stage-meta').textContent='무조작 · 랜덤 장애물 레이스';$('#bottom-pause').textContent='잠깐 쉬어가기 Ⅱ';$('#pause').textContent='Ⅱ';renderRoster();renderPosition();}
const stopRace=async()=>{const was=state;if(state==='racing'||state==='countdown')pauseRace();if(await ask('이번 경기를 중단하고 설정으로 돌아갈까요? 당첨 결과는 만들지 않아요.'))setup();else if(was==='racing'||was==='countdown')resumeRace();};
$('#stop').onclick=stopRace;$('#stage-stop').onclick=stopRace;
document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseRace('다른 화면으로 이동해서 자동으로 멈췄어요.');});
window.addEventListener('pagehide',()=>{try{save(localStorage,participants,settings);}catch{}});
function renderPosition(){
  const goal=race?.distanceMeters??settings.distanceMeters;
  $('#position-track').innerHTML=participants.map((p,i)=>{
    const runner=race?.runners[i];const percent=runner?Math.max(0,Math.min(100,runner.x/(goal*PIXELS_PER_METER)*100)):0;
    return `<span class="position-dot ${race&&renderer.targetIndex===i?'tracked':''}" style="left:${percent}%;background:${avatars.find(a=>a.id===p.avatarId)!.shirt}" title="${escape(p.name)} · ${runner?.finishTime!==null&&runner?.finishTime!==undefined?'완주':((runner?.x??0)/PIXELS_PER_METER).toFixed(1)+'m'}"></span>`;
  }).join('');
  $('#position-description').textContent=race?`${race.completedCount} / ${participants.length}명 완주 · ${distanceLabel(goal)} 코스`:'같은 출발선에서 함께 시작해요';
  $('#min-distance').textContent='출발 0m';$('#max-distance').textContent=`⚑ 결승 ${distanceLabel(goal)}`;$('#mid-distance').textContent=distanceLabel(goal/2);
}
function updateHUD(){
  if(!race)return;const rank=race.rank();const canvas=$<HTMLCanvasElement>('#game');
  canvas.dataset.worldTime=race.worldTime.toFixed(3);canvas.dataset.elapsed=race.elapsed.toFixed(3);canvas.dataset.completed=String(race.completedCount);canvas.dataset.distance=String(race.distanceMeters);canvas.dataset.lastPlace=race.lastPlaceIndex===null?'':String(race.lastPlaceIndex);
  canvas.dataset.boosted=String(race.runners.filter(r=>r.finishTime===null&&r.status==='running'&&race!.worldTime<Math.max(r.candyBoostUntil,r.boostUntil)).length);
  canvas.dataset.lollipop=race.lollipop?(race.lollipop.resolved?'awarded':'spinning'):'';
  canvas.dataset.lollipopRound=String(race.lollipop?.round??0);
  canvas.dataset.lollipopReward=race.lollipop?.resolved?race.lollipop.reward:'';
  canvas.dataset.giant=race.giant?String(race.giant.runner):'';
  canvas.dataset.rainbow=race.rainbowIndex===null?'':String(race.rainbowIndex);
  canvas.dataset.lanes=race.runners.map(r=>r.lane.toFixed(3)).join(',');
  canvas.dataset.statuses=race.runners.map(r=>r.status).join(',');for(const r of race.runners){seenEffects.add(r.status);if(r.transport)seenEffects.add(r.transport.kind);}for(const impact of race.impacts)seenEffects.add(impact.kind);canvas.dataset.seenEffects=[...seenEffects].join(',');
  const tracked=race.runners[renderer.targetIndex]??rank[0];
  $('#race-progress-label').textContent=`완주 ${race.completedCount} / ${participants.length}명`;
  $('#timer').textContent=tracked.status==='crying'?'꼴찌 확정':tracked.finishTime!==null?'FINISH':`${Math.ceil(Math.max(0,(race.finishX-tracked.x)/PIXELS_PER_METER))}m`;
  $('#follow-rule').textContent=settings.winnerRule==='first'?(race.finished?'🏁 전원 완주!':race.completedCount?'🏁 완주 전 선두를 따라가는 중':'🏆 1등 후보를 따라가는 중'):race.lastPlaceIndex!==null?'🍀 꼴찌 확정!':'🍀 꼴찌 후보를 따라가는 중';
  $('#follow-name').textContent=tracked.participant.name;
  $('.stage-meta').textContent=`${distanceLabel(race.distanceMeters)} 레이스 · 경과 ${clock(race.elapsed)}`;
  $('#ranking-title').textContent=settings.winnerRule==='first'?'⚑ 지금 선두는?':'♧ 지금 맨 뒤는?';
  const shown=settings.winnerRule==='first'?rank.slice(0,5):rank.slice(-5).reverse();
  $('#live-ranking').innerHTML=shown.map(r=>`<li><span class="rank-number">${rank.indexOf(r)+1}</span><img class="rank-avatar" src="${avatarURL(r.participant)}" alt=""/><span class="rank-name">${escape(r.participant.name)}</span><span class="rank-distance">${r.status==='crying'?'눈물의 '+(r.x/PIXELS_PER_METER).toFixed(1)+'m':r.finishTime!==null?'⚑ '+arrivalLabel(r.finishTime):(r.x/PIXELS_PER_METER).toFixed(1)+'m'}</span></li>`).join('');
  updateRaceNews(race);renderPosition();
}
let resultCryFrames:string[]=[];let lastResultCryFrame=-1;
function showResults(){
  if(!race||state==='results')return;state='results';
  $('#stage-stop').classList.add('hidden');$('#race-details').classList.add('hidden');$('#pause').classList.add('hidden');$('#race-panel').classList.add('hidden');
  const completedRace=race;const rank=race.result!;const winner=settings.winnerRule==='first'?rank[0]:rank[rank.length-1];const crying=winner.status==='crying';
  $('#stage-tag').textContent=crying?'LAST':'FINISH';$('#stage-title').textContent=crying?'꼴찌는 그 자리에서 눈물이 뚝뚝…':'끝까지 달린 모두에게 박수!';
  if(crying){renderer.targetIndex=winner.index;renderer.camera=winner.x-renderer.width*.37;$('#last-place-banner').classList.remove('hidden');resultCryFrames=Array.from({length:4},(_,i)=>sprite(winner.participant,i,'cry').toDataURL());}
  const details=crying?`${race.completedCount}명 완주 · ${distanceLabel(race.distanceMeters)} 코스<br>${(winner.x/PIXELS_PER_METER).toFixed(1)}m 그 자리에서 꼴찌 확정`:`${participants.length}명이 ${distanceLabel(race.distanceMeters)}를 완주했어요 · 총 ${arrivalLabel(race.elapsed)}`;
  const d=$<HTMLDialogElement>('#result-dialog');
  d.innerHTML=`<div class="result-eyebrow">A LITTLE LUCK, A HAPPY MOMENT</div><img id="result-emotion" class="result-character ${crying?'crying-character':''}" src="${crying?resultCryFrames[1]:sprite(winner.participant,0,'cheer').toDataURL()}" alt="${crying?'그 자리에서 우는 꼴찌 캐릭터':'당첨 캐릭터'}"/><div class="result-eyebrow">${settings.winnerRule==='first'?'🏆 1등':'🍀 꼴찌'}의 행운을 만난 친구</div><h2>${escape(winner.participant.name)}</h2><div class="result-details">${crying?'눈물은 잠깐, 오늘의 행운은 네 차례!':'오늘의 주인공으로 당첨되었어요!'}<br>${details}</div><ol class="ranking-list result-rankings">${rank.map((r,i)=>`<li class="${r.index===winner.index?'winner':''}"><span class="rank-number">${i+1}</span><img class="rank-avatar" src="${r.status==='crying'?sprite(r.participant,1,'cry').toDataURL():avatarURL(r.participant)}" alt=""/><span class="rank-name">${escape(r.participant.name)} <span style="color:#9aa78b;font-size:9px">#${r.index+1}</span> ${r.index===winner.index?'✦':''}</span><span class="rank-distance">${r.status==='crying'?(r.x/PIXELS_PER_METER).toFixed(1)+'m에서 확정':arrivalLabel(r.finishTime)}</span></li>`).join('')}</ol>${race.tieOccurred?'<p class="result-details">도착 시각이 정확히 같은 참가자는 경기 시드로 추가 추첨했어요.</p>':''}<div class="result-actions"><button class="secondary-btn" id="back-setup">설정으로 돌아가기</button><button class="primary-btn" id="rematch">한 번 더 달리기 ↻</button></div><div class="seed-info">RACE SEED ${race.seed} · ${distanceLabel(race.distanceMeters)} · 오리지널 픽셀아트</div>`;
  d.oncancel=e=>{e.preventDefault();d.close();setup();};
  const reveal=()=>{if(state==='results'&&race===completedRace&&!d.open)d.showModal();};if(crying)setTimeout(reveal,1600);else reveal();
  $('#back-setup').onclick=()=>{d.close();setup();};$('#rematch').onclick=()=>{d.close();startRace();};
  tone(523,.2);setTimeout(()=>tone(659,.2),190);setTimeout(()=>tone(784,.35),380);updateHUD();
}
let slowNotified=false;let lastEventId=0;let perfFrames=0;let perfSeconds=0;
function frame(stamp:number){const now=stamp/1000;const delta=lastFrame?Math.max(0,now-lastFrame):0;lastFrame=now;if(state==='racing'&&delta>0&&delta<1){perfFrames++;perfSeconds+=delta;const canvas=$<HTMLCanvasElement>('#game');canvas.dataset.averageFps=(perfFrames/perfSeconds).toFixed(1);canvas.dataset.measuredSeconds=perfSeconds.toFixed(1);}
  if(state==='countdown'){
    countdownLeft-=delta;const n=Math.max(1,Math.ceil(countdownLeft));if(n!==countdownTone){countdownTone=n;tone(440,.1);}$('#overlay').innerHTML=`<div class="countdown-number">${n}<small>우리 모두, 같은 출발선에서!</small></div>`;
    if(countdownLeft<=0){state='racing';$('#overlay').classList.add('hidden');$('#stage-tag').textContent='LIVE';$('#stage-title').textContent='우당탕! 지금 달리는 중';tone(880,.25);}
  }else if(state==='racing'&&race){
    if(delta>1){pauseRace('화면 처리가 지연되어 경기를 안전하게 멈췄어요.');if(!slowNotified){toast('재개하면 같은 경기 상태에서 계속 달립니다.');slowNotified=true;}}
    else if(hasPendingLollipop(race))animateLollipop(race,delta);
    else {
      const slowed=Math.min(delta,duelSlowLeft);
      duelSlowLeft-=slowed;
      accumulator+=delta-slowed*(1-DUEL_SLOW_RATE);
      while(accumulator>=STEP&&!race.finished){
        race.step();accumulator-=STEP;
        if(race.duelOvertake&&race.duelOvertake!==shownOvertake){
          shownOvertake=race.duelOvertake;
          if(duelSlowLeft===0)accumulator*=DUEL_SLOW_RATE;
          duelSlowLeft=DUEL_SLOW_SECONDS;
        }
        if(hasPendingLollipop(race)){accumulator=0;animateLollipop(race,0);break;}
      }
      if(race.finished){accumulator=0;showResults();}
    }
  }
  const lollipopPause=hasPendingLollipop(race);
  const duelSlow=state==='racing'&&!lollipopPause&&duelSlowLeft>0&&!!race&&race.completedCount===race.runners.length-2;
  if(race&&race.completedCount!==race.runners.length-2)duelSlowLeft=0;
  updateDuelIndicator(duelSlow);
  renderer.draw(participants,race,settings.winnerRule,now,state==='paused'||lollipopPause,
    state==='racing'&&!lollipopPause?accumulator/STEP:1,displayOrder,lollipopAge,duelSlow);
  if(state==='results'&&resultCryFrames.length){const f=Math.floor(now*5)%4;if(f!==lastResultCryFrame){lastResultCryFrame=f;const img=document.querySelector<HTMLImageElement>('#result-emotion');if(img)img.src=resultCryFrames[f];}}
  if(race&&now-hudTick>.15){updateHUD();hudTick=now;const id=race.events[0]?.id??0;if(id!==lastEventId){lastEventId=id;if(state==='racing'){const kind=race.events[0]?.kind;tone(kind==='respawn'?880:kind==='platform'?130:kind==='ufo'?220:330,kind==='respawn'||kind==='platform'?.18:.08);}}}
  requestAnimationFrame(frame);
}
void loadRunnerAtlas().then(loaded=>{
  $<HTMLCanvasElement>('#game').dataset.atlasLoaded=String(loaded);$<HTMLCanvasElement>('#game').dataset.actionsLoaded=String(hasActionAtlas());
  renderRoster();renderPosition();
  if(!loaded)toast('새 캐릭터 이미지를 불러오지 못해 기본 모습으로 표시해요.');
  else if(boot.error)toast('저장 정보를 읽지 못했어요. 새 명단으로 시작할 수 있어요.');
  if(boot.data)persist();else if(!boot.error){persist();toast('친구들의 이름을 입력하고 첫 레이스를 시작해보세요.');}
  requestAnimationFrame(frame);
});
