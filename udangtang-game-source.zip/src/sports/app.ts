import {SKEET_TARGET_COUNT} from './skeet.ts';
import './sports.css';
import {siteHeader,updateHeaderSound} from '../ui/site-header.ts';
import {SportsAudio} from './audio.ts';
import QRCode from 'qrcode';
import {avatars} from '../data/avatars.ts';
import {avatarURL,loadRunnerAtlas} from '../rendering/renderer.ts';
import {SPORTS,PLAYER_COLORS,sportDefinition,type Athlete,type Control,type Match,type RoomView,type Session,type SportId} from './model.ts';
import {applyControl,createMatch,startRound,stepMatch} from './engine.ts';
import {api,ONLINE_ORIGIN,RoomConnection,type SyncReply} from './connection.ts';
import {SportCanvas,stadium} from './render.ts';
import {loadVaultMotions} from './vault-motion.ts';
import {loadSwimmingMotion} from './swimming-motion.ts';
import {loadSkeetMotion} from './skeet-motion.ts';
import {loadArcheryMotion} from './archery-motion.ts';
import {SportsArena} from './arena.ts';
import {applyRemoteInputs,RemoteTimeline,projectRemoteMatch,RemoteClock} from './remote-input.ts';
import {bindSportButton} from './controls.ts';
import {HURDLES} from './hurdles.ts';

const $=<T extends HTMLElement=HTMLElement>(selector:string)=>document.querySelector<T>(selector)!;
const html=(value:string)=>value.replace(/[&<>"']/g,character=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character]!));
const query=new URLSearchParams(location.search);
const sound=new SportsAudio();
let chosen:SportId='swimming';
let selectedSport:SportId='swimming';
let selectedAvatar=0;
let session:Session|null=null;
let connection:RoomConnection|null=null;
let room:RoomView|null=null;
let match:Match|null=null;
let visualMatch:Match|null=null;
let practice=false;
let viewMode:'all'|'mine'='all';
let viewKey='';
let cards:Array<{view:SportCanvas;person:Athlete}>=[];
let arena:SportsArena|null=null;
let lastTime=0;
let accumulator=0;
let lastUi=0;
let lastReplyAt=0;
let localReady=false;
let stopped=false;
const remoteTimeline=new RemoteTimeline();
const remoteClock=new RemoteClock();
let frameRequest:number|null=null;
let unbindControls=()=>{};
const downTimes=new Map<Control,number>();
let qrLink='';
let heroCanvas:HTMLCanvasElement|null=null;
let heroSport:SportCanvas|null=null;

function avatar(person:{id:string;name:string;avatar:number;color:string}) {
  return avatarURL({id:person.id,name:person.name,avatarId:avatars[person.avatar].id,paletteId:person.color});
}
function storeSession(value:Session|null) {
  try {if(value)sessionStorage.setItem('udangtang.sports.session',JSON.stringify(value));else sessionStorage.removeItem('udangtang.sports.session');} catch {}
}
function notice(message:string) {
  $('#sp-message').textContent=message;
  $('#sp-message').hidden=!message;
}
function eventOptions() {
  return SPORTS.map(sport=>`<label class="sp-event-option"><input type="radio" name="sport" value="${sport.id}" ${selectedSport===sport.id?'checked':''}><span>${sport.symbol}</span><strong>${sport.name}</strong></label>`).join('');
}
function chooser() {
  return `<div class="sp-avatar-picker" aria-label="캐릭터 선택">${avatars.map((person,index)=>`<button type="button" data-avatar="${index}" aria-label="${person.name}" aria-pressed="${index===selectedAvatar}"><img src="${avatar({id:'choice',name:person.name,avatar:index,color:PLAYER_COLORS[index]})}" alt=""></button>`).join('')}</div>`;
}
function shell() {
  document.title='우당탕 올림픽 | 우당탕 게임룸';
  document.body.className='sports-body';
  document.body.innerHTML=`${siteHeader('sports',sound.enabled)}<div class="sp-shell">
    <main id="sp-main"></main><dialog id="sp-help-dialog" class="sp-help-dialog"><h2>휴대폰으로 함께하는 우당탕 올림픽</h2><ol><li>방장이 방을 만들고 참가할 종목 하나를 선택해요.</li><li>친구들은 QR 코드나 6자리 방 코드로 참가해요. 최대 8명까지 함께해요.</li><li>모두 준비 완료를 누르면 방장이 경기를 시작해요.</li><li>내 휴대폰의 A·B·C 버튼으로 조작해요. 키보드는 A·S·D예요.</li><li>종목이 끝나면 대기실에서 다음에 할 종목을 골라요.</li></ol><button class="sp-primary" id="sp-help-close">확인</button></dialog><dialog id="sp-practice-dialog" class="sp-help-dialog sp-practice-dialog" aria-labelledby="sp-practice-title"><h2 id="sp-practice-title">혼자 연습하기</h2><p>방 코드 없이 바로 시작해요. 종목과 캐릭터를 골라보세요.</p><form id="sp-practice-form"><label>연습할 종목<select id="sp-practice-sport">${SPORTS.map(sport=>`<option value="${sport.id}">${sport.name}</option>`).join('')}</select></label><label>내 캐릭터<select id="sp-practice-avatar">${avatars.map((person,index)=>`<option value="${index}">${person.name}</option>`).join('')}</select></label><p>터치 A·B·C 또는 키보드 A·S·D로 조작해요.</p><div class="sp-practice-actions"><button type="button" class="sp-outline" id="sp-practice-close">취소</button><button class="sp-primary" type="submit">연습 시작</button></div></form></dialog><div id="sp-message" class="sp-message" role="status" hidden></div>
    <footer class="sp-footer"><span>우당탕 게임룸</span><span>최대 8명 참가 · 한 경기장에서 함께 · A B C 터치 컨트롤</span></footer>
  </div>`;
  $('#site-sound').onclick=()=>{sound.toggle();updateHeaderSound(sound.enabled);};
  $('#help').onclick=()=>$<HTMLDialogElement>('#sp-help-dialog').showModal();
  $('#sp-help-close').onclick=()=>$<HTMLDialogElement>('#sp-help-dialog').close();
  $('#sp-practice-close').onclick=()=>$<HTMLDialogElement>('#sp-practice-dialog').close();
  $('#sp-practice-form').onsubmit=event=>{event.preventDefault();selectedAvatar=Number($<HTMLSelectElement>('#sp-practice-avatar').value);const sport=$<HTMLSelectElement>('#sp-practice-sport').value as SportId;$<HTMLDialogElement>('#sp-practice-dialog').close();startPractice(sport);};
}
function renderLanding() {
  viewKey='landing';heroCanvas=null;cards=[];arena=null;
  $('#sp-main').innerHTML=`<section class="sp-intro"><div><p class="sp-kicker">친구들과 함께하는 아케이드 운동회</p><h1><span class="sp-kicker">우당탕 올림픽</span><br>휴대폰을 들고,<br><em>경기장에 모여요.</em></h1><p>방을 열고 친구들을 초대하세요.<br>큰 화면으로 함께 보고, 내 휴대폰으로 직접 뛰는 8종 경기.</p><div class="sp-intro-meta"><span>최대 8명</span><span>실시간 경기</span><span>버튼 3개</span></div></div><div class="sp-hero-art"><canvas id="sp-hero" width="800" height="370" aria-label="우당탕 올림픽 픽셀 경기장"></canvas><div class="sp-hero-caption"><strong>READY TO PLAY TOGETHER</strong><span>가장 가까운 친구와, 가장 뜨거운 한 판.</span></div></div></section>
    <section class="sp-entry-grid"><article class="sp-panel"><div class="sp-panel-heading"><span class="sp-panel-icon">＋</span><div><h2>새 경기 열기</h2><p>방장 휴대폰이나 메인 PC에서 시작해요.</p></div></div><button class="sp-primary" id="sp-create">방 만들기</button><button class="sp-text-button" id="sp-practice">혼자 연습하기</button></article>
    <article class="sp-panel"><div class="sp-panel-heading"><span class="sp-panel-icon">↗</span><div><h2>친구 방에 참가</h2><p>화면에 보이는 6자리 코드를 입력하세요.</p></div></div><form id="sp-join-form"><div class="sp-join-fields"><label>방 코드<input id="sp-code" maxlength="6" autocapitalize="characters" autocomplete="off" placeholder="ABC123" value="${html(query.get('room')??'')}"></label><label>내 이름<input id="sp-name" maxlength="12" autocomplete="nickname" placeholder="이름을 입력해요" required></label></div>${chooser()}<button class="sp-primary sp-primary-light" type="submit">참가하기</button></form><button class="sp-text-button" id="sp-watch">참가 없이 메인 화면만 보기</button></article></section>
    <section class="sp-disciplines"><div class="sp-section-heading"><h2>오늘의 8종 경기</h2><p>하이퍼 스포츠의 3버튼 조작에서 출발한 우당탕 운동회.</p></div><div class="sp-sport-tabs" role="tablist" aria-label="종목 안내">${SPORTS.map(sport=>`<button role="tab" data-sport="${sport.id}" aria-selected="${sport.id===chosen}"><span style="color:${sport.color}">${sport.symbol}</span>${sport.name}</button>`).join('')}</div><div id="sp-sport-guide"></div></section>`;
  heroCanvas=$<HTMLCanvasElement>('#sp-hero');
  $('#sp-create').onclick=()=>void createRoom();
  $('#sp-practice').onclick=openPractice;
  $('#sp-join-form').onsubmit=event=>{event.preventDefault();void joinRoom();};
  $('#sp-watch').onclick=()=>void watchRoom();
  document.querySelectorAll<HTMLButtonElement>('[data-avatar]').forEach(button=>button.onclick=()=>{
    selectedAvatar=Number(button.dataset.avatar);
    document.querySelectorAll('[data-avatar]').forEach(item=>item.setAttribute('aria-pressed',String(item===button)));
  });
  document.querySelectorAll<HTMLButtonElement>('[data-sport]').forEach(button=>button.onclick=()=>{
    chosen=button.dataset.sport as SportId;
    document.querySelectorAll('[data-sport]').forEach(item=>item.setAttribute('aria-selected',String(item===button)));
    renderGuide();
  });
  renderGuide();
}
function openPractice() {
  $<HTMLSelectElement>('#sp-practice-sport').value=chosen;
  $<HTMLSelectElement>('#sp-practice-avatar').value=String(selectedAvatar);
  $<HTMLDialogElement>('#sp-practice-dialog').showModal();
}
function renderGuide() {
  const sport=sportDefinition(chosen);
  $('#sp-sport-guide').innerHTML=`<div class="sp-guide-art"><canvas id="sp-guide-canvas" aria-label="${sport.name} 경기 미리보기"></canvas></div><div class="sp-guide-copy"><span class="sp-kicker">${sport.english}</span><h3>${sport.description}</h3><ol>${sport.instructions.map(text=>`<li>${text}</li>`).join('')}</ol><div class="sp-mini-controls">${sport.controls.map((label,index)=>`<span><b>${['A','B','C'][index]}</b>${label}</span>`).join('')}</div><button class="sp-outline" id="sp-guide-practice">이 종목 연습하기</button></div>`;
  heroSport=new SportCanvas($('#sp-guide-canvas'));
  $('#sp-guide-practice').onclick=openPractice;
}
async function createRoom() {
  const button=$<HTMLButtonElement>('#sp-create');button.disabled=true;notice('');
  try {
    const token=crypto.randomUUID()+crypto.randomUUID();
    const result=await api<{code:string}>('create',{token});
    selectedSport=chosen;
    session={code:result.code,token,role:'host',playerId:null};
    connect();
  } catch(error) {notice((error as Error).message);button.disabled=false;}
}
async function joinRoom() {
  const name=$<HTMLInputElement>('#sp-name').value.trim();
  const code=$<HTMLInputElement>('#sp-code').value.trim().toUpperCase();
  if(!name||code.length!==6) {notice('6자리 방 코드와 이름을 입력해 주세요.');return;}
  notice('');
  const button=$<HTMLButtonElement>('#sp-join-form button[type=submit]');button.disabled=true;
  try {
    const token=crypto.randomUUID()+crypto.randomUUID();
    const result=await api<SyncReply>('join',{code,token,name,avatar:selectedAvatar});
    session={code,token,role:'player',playerId:result.playerId!};room=result.view;
    connect();
  } catch(error) {notice((error as Error).message);button.disabled=false;}
}
async function watchRoom() {
  const code=$<HTMLInputElement>('#sp-code').value.trim().toUpperCase();
  try {
    const result=await api<SyncReply>('watch',{code});
    session={code,token:'',role:'display',playerId:null};room=result.view;
    connect();
  } catch(error) {notice((error as Error).message);}
}
function connect() {
  if(!session)return;
  remoteClock.reset();practice=false;viewKey='';viewMode=session.role==='player'?'mine':'all';
  storeSession(session);
  const url=new URL(location.href);url.searchParams.set('game','sports');url.searchParams.set('room',session.code);
  url.searchParams.delete('view');history.replaceState(null,'',url);
  connection?.stop();
  connection=new RoomConnection(session);
  connection.onState=receive;
  connection.onError=message=>{notice(`연결 복구 중 · ${message}`);};
  connection.start();
  renderRoom();
}
function receive(reply:SyncReply) {
  lastReplyAt=performance.now();visualMatch=null;notice('');
  if(session?.role==='player'&&match&&reply.view.match===null) {
    localReady=false;
    if(connection)connection.ready=false;
  }
  if(!reply.view.match||reply.view.match.phase==='countdown')remoteClock.reset();
  room=reply.view;
  if(session?.role==='host') {
    if(!match&&room.match)match=room.match;
    if(connection) {
      connection.frame=Math.max(connection.frame,reply.frame??0);
      applyRemoteInputs(match,reply.inputs??[],connection.ack,remoteTimeline);
    }
  } else match=room.match;
  if(session?.role==='player'&&!room.athletes.some(athlete=>athlete.id===session!.playerId)) {
    leave();notice('방장이 참가 목록을 정리했어요. 다시 참가할 수 있어요.');return;
  }
  renderRoom();
  updateRoomUi();
}
function roomUrl(display=false) {
  const base=import.meta.env.DEV?location.origin:ONLINE_ORIGIN;
  const url=new URL(base+'/');url.searchParams.set('game','sports');url.searchParams.set('room',session?.code??'');
  if(display)url.searchParams.set('view','display');
  return url.href;
}
function renderRoom() {
  const currentPhase=match?.phase??'lobby';
  const key=[practice?'practice':session?.role,currentPhase,match?.eventIndex??0,viewMode].join(':');
  if(key===viewKey)return;
  viewKey=key;heroCanvas=null;heroSport=null;arena=null;
  releaseControls();unbindControls();unbindControls=()=>{};
  const host=practice||session?.role==='host';
  const athleteCount=practice?1:room?.athletes.length??0;
  $('#sp-main').innerHTML=`<div class="sp-room-top"><div><p class="sp-kicker">${practice?'PRACTICE ROOM':session?.role==='display'?'STADIUM SCREEN':'LIVE GAME ROOM'}</p><h1>${practice?'혼자 연습하기':currentPhase==='lobby'?'함께할 선수들을 기다려요':sportDefinition(match?.round?.sport??'swimming').name}</h1></div><div class="sp-room-top-actions">${session?`<span class="sp-room-code">ROOM <strong>${session.code}</strong></span>`:''}<button id="sp-leave" class="sp-outline">${practice?'연습 나가기':'방 나가기'}</button></div></div>
    ${currentPhase==='lobby'?`<div class="sp-lobby-grid"><section class="sp-panel"><div class="sp-section-heading"><h2>출전 선수 <span id="sp-player-count">${athleteCount} / 8</span></h2><span id="sp-net-status" class="sp-network">온라인 연결 중</span></div><div id="sp-roster" class="sp-roster"></div>${session?.role==='player'?`<div class="sp-ready-area"><p>종목 안내를 읽고 준비 완료를 눌러주세요.</p><button class="sp-primary" id="sp-ready">준비 완료</button></div>`:''}${host?`<div class="sp-lobby-bottom"><button class="sp-primary" id="sp-begin">경기 시작</button><p id="sp-start-hint"></p></div>`:''}</section><aside class="sp-panel sp-invite"><h2>친구 초대하기</h2><div class="sp-qr-frame"><canvas id="sp-qr" aria-label="휴대폰 참가 QR 코드"></canvas></div><strong class="sp-invite-code">${session?.code??''}</strong><p>휴대폰으로 QR을 찍거나<br>같은 사이트에서 방 코드를 입력하세요.</p><div class="sp-invite-actions"><button id="sp-copy" class="sp-outline">초대 링크 복사</button><a class="sp-outline" href="${roomUrl(true)}" target="_blank" rel="noopener">메인 화면 열기</a></div></aside></div>
      ${host?`<section class="sp-panel sp-event-selector"><div class="sp-section-heading"><h2>진행할 종목</h2><span>8종목 중 한 종목을 골라 플레이해요</span></div><div class="sp-event-options">${eventOptions()}</div></section>`:''}
      <section class="sp-panel sp-lobby-guide"><h2>A · B · C, 세 개의 버튼으로</h2><p>연타는 손가락을 떼었다가 다시 누르세요. 각 종목 시작 전 휴대폰에 조작법이 표시됩니다.</p><div class="sp-mini-sports">${SPORTS.map(sport=>`<span>${sport.symbol} ${sport.name}</span>`).join('')}</div></section>`:
    `<section class="sp-match-panel"><div class="sp-scorebar"><div><span id="sp-event-progress"></span><strong id="sp-live-instruction"></strong></div><div class="sp-scorebar-right"><span id="sp-match-clock">0.0초</span><span id="sp-net-status" class="sp-network">연결 중</span>${session?.role==='player'?`<button id="sp-view-toggle" class="sp-outline">${viewMode==='mine'?'모두 보기':'내 화면 보기'}</button>`:''}<button id="sp-fullscreen" class="sp-outline">화면 확대</button></div></div><div class="sp-screen-wrap"><div id="sp-player-screens" class="sp-player-screens ${viewMode==='mine'?'sp-own-screen':''}"></div><div id="sp-countdown" class="sp-countdown" hidden></div></div><div id="sp-controller-area"></div><div id="sp-results" class="sp-results" hidden></div>${host?`<div class="sp-host-actions"><button id="sp-reset" class="sp-outline">${practice?'다시 연습하기':'대기실로'}</button>${practice?'<button id="sp-change-practice" class="sp-outline">종목 바꾸기</button>':''}</div>`:''}</section>`}`;
  $('#sp-leave').onclick=leave;
  if(currentPhase==='lobby') {cards=[];bindLobby(host);}
  else bindMatch(host);
  updateRoomUi();
}
function bindLobby(host:boolean) {
  $('#sp-copy').onclick=async()=>{
    try {await navigator.clipboard.writeText(roomUrl());notice('초대 링크를 복사했어요.');}
    catch {notice(roomUrl());}
  };
  qrLink=roomUrl();
  void QRCode.toCanvas($<HTMLCanvasElement>('#sp-qr'),qrLink,{width:196,margin:1,color:{dark:'#254a40',light:'#fffdf1'}});
  const ready=$('#sp-ready');
  if(ready)ready.onclick=()=>{localReady=!localReady;if(connection)connection.ready=localReady;updateRoomUi();};
  if(host) {
    $('#sp-begin').onclick=beginMatch;
    document.querySelectorAll<HTMLInputElement>('input[name=sport]').forEach(input=>input.onchange=()=>{
      selectedSport=input.value as SportId;
      updateRoomUi();
    });
  }
}
function beginMatch() {
  const athletes=room?.athletes??[];
  if(!athletes.length||athletes.length>8||athletes.some(athlete=>!athlete.ready||!athlete.connected))return;
  match=createMatch(athletes,[selectedSport]);startRound(match);
  if(connection)connection.match=match;
  viewKey='';renderRoom();
}
function bindMatch(host:boolean) {
  const list=$('#sp-player-screens');
  const athletes=match?.athletes??[];
  const visible=viewMode==='mine'?athletes.filter(athlete=>athlete.id===session?.playerId):athletes;
  const shared=viewMode==='all'&&visible.length>1;
  list.className=shared?'sp-shared-screen':`sp-player-screens sp-single ${viewMode==='mine'?'sp-own-screen':''}`;
  if(shared){
    list.innerHTML=`<canvas id="sp-arena" aria-label="참가자 모두가 함께하는 경기장"></canvas><div class="sp-arena-scores" role="list" aria-label="참가자 경기 현황">${visible.map(person=>`<div class="sp-arena-score" role="listitem" style="--player:${person.color}" data-arena-player="${person.id}"><span><i></i>${html(person.name)}</span><b>0 P</b><small>준비</small><div class="sp-meter"><i></i></div></div>`).join('')}</div>`;
    arena=new SportsArena($<HTMLCanvasElement>('#sp-arena'));cards=[];
  }else{
    arena=null;
    list.innerHTML=visible.map(person=>`<article class="sp-player-card" style="--player:${person.color}" data-player="${person.id}"><div class="sp-player-card-head"><span><i></i>${html(person.name)}</span><b class="sp-player-score">0</b></div><canvas aria-label="${html(person.name)}의 경기 화면"></canvas><div class="sp-player-card-bottom"><span class="sp-player-status">준비</span><div class="sp-meter"><i></i></div></div></article>`).join('');
    cards=visible.map(person=>({person,view:new SportCanvas($<HTMLCanvasElement>(`[data-player="${person.id}"] canvas`))}));
  }
  const full=$('#sp-fullscreen');
  full.onclick=()=>void(document.fullscreenElement?document.exitFullscreen():$('#sp-main').requestFullscreen()).catch(()=>notice('이 브라우저는 화면 확대를 지원하지 않아요.'));
  const toggle=$('#sp-view-toggle');if(toggle)toggle.onclick=()=>{viewMode=viewMode==='mine'?'all':'mine';viewKey='';renderRoom();};
  if(practice||session?.role==='player')renderControls();
  if(host) {
    $('#sp-reset').onclick=()=>void resetLobby();
    if(practice)$('#sp-change-practice').onclick=openPractice;
  }
}
function renderControls() {
  const sport=sportDefinition(match?.round?.sport??'swimming');
  $('#sp-controller-area').innerHTML=`<section class="sp-controller" aria-label="내 게임 컨트롤러"><div class="sp-control-status"><strong id="sp-my-status">준비하세요</strong><span id="sp-input-status">터치 또는 키보드 A · S · D</span></div><div class="sp-control-buttons">${sport.controls.map((label,index)=>`<button class="sp-control sp-control-${index}" data-control="${['A','B','C'][index]}" aria-label="${['A','B','C'][index]} ${label}" ${label==='사용 안 함'?'disabled':''}><strong>${['A','B','C'][index]}</strong><span>${label}</span></button>`).join('')}</div><details class="sp-instructions" open><summary>${sport.name} 조작법</summary><p>${sport.instructions.join('<br>')}</p></details></section>`;
  const bindings=Array.from(document.querySelectorAll<HTMLButtonElement>('[data-control]'),button=>bindSportButton(button,button.dataset.control as Control,press));
  unbindControls=()=>{for(const dispose of bindings)dispose();};
}
function press(button:Control,down:boolean) {
  if(match?.phase!=='playing'){const status=$('#sp-input-status');if(status&&down)status.textContent=match?.phase==='countdown'?'출발 신호를 기다려요':'경기가 진행 중일 때 조작할 수 있어요';return;}
  if(down&&downTimes.has(button)||!down&&!downTimes.has(button))return;
  const heldMs=down?undefined:performance.now()-downTimes.get(button)!;
  if(down)downTimes.set(button,performance.now());else downTimes.delete(button);
  document.querySelector(`[data-control=${button}]`)?.classList.toggle('is-pressed',down);
  const playerId=practice?'practice':session?.playerId;
  if(!playerId)return;
  if(practice)applyControl(match,playerId,button,down,heldMs);
  else connection?.input({button,down,round:match.number,heldMs,at:clientRoundTime(performance.now())});
  if(down&&typeof navigator.vibrate==='function')try{navigator.vibrate(8);}catch{}
  const status=$('#sp-input-status');if(status)status.textContent=`${button} ${down?'입력':'떼기'} · ${practice?'연습 모드':'실시간 전송'}`;
}
function clientRoundTime(now:number){return remoteClock.read(match?.round?.time??0,lastReplyAt,now);}
function releaseControls() {
  for(const button of downTimes.keys())press(button,false);
  downTimes.clear();
}
function updateRoomUi() {
  const host=practice||session?.role==='host';
  const athletes=practice?match?.athletes??[]:room?.athletes??[];
  const net=$('#sp-net-status');
  if(net)net.textContent=practice?'연습 모드':performance.now()-lastReplyAt>4500?'연결 복구 중':'온라인 연결됨';
  if(!match||match.phase==='lobby') {
    const container=$('#sp-roster');if(!container)return;
    const rosterKey=JSON.stringify(athletes.map(athlete=>[athlete.id,athlete.name,athlete.ready,athlete.connected]));
    if(container.dataset.roster!==rosterKey) {
      container.dataset.roster=rosterKey;
      container.innerHTML=athletes.length?athletes.map((person,index)=>`<div class="sp-roster-player"><img src="${avatar(person)}" alt=""><span><strong>${html(person.name)}</strong><small>PLAYER ${index+1}</small></span><b class="${person.ready?'ready':''}">${!person.connected?'연결 끊김':person.ready?'준비 완료':'준비 중'}</b>${host?`<button data-remove="${person.id}" aria-label="${html(person.name)} 내보내기">×</button>`:''}</div>`).join(''):'<div class="sp-empty-roster"><span>♧</span><strong>첫 번째 선수를 기다리고 있어요</strong><p>QR 코드로 접속하면 여기에 표시돼요.</p></div>';
      container.querySelectorAll<HTMLButtonElement>('[data-remove]').forEach(button=>button.onclick=()=>void api<SyncReply>('host',{code:session?.code,token:session?.token,remove:button.dataset.remove}).then(receive).catch(error=>notice(error.message)));
    }
    $('#sp-player-count').textContent=`${athletes.length} / 8`;
    const button=$<HTMLButtonElement>('#sp-begin');
    if(button) {
      button.disabled=!athletes.length||athletes.length>8||athletes.some(athlete=>!athlete.ready||!athlete.connected);
      $('#sp-start-hint').textContent=athletes.length>8?'최대 8명까지 플레이할 수 있어요. 참가 목록을 정리해 주세요.':!athletes.length?'친구가 입장하면 경기를 시작할 수 있어요.':athletes.some(athlete=>!athlete.ready)?'모든 선수가 준비를 마치면 시작해요.':`${sportDefinition(selectedSport).name} 준비 완료!`;
    }
    const ready=$('#sp-ready');if(ready) {ready.textContent=localReady?'준비 완료 ✓ · 취소하기':'준비 완료';ready.setAttribute('aria-pressed',String(localReady));}
    return;
  }
  const currentMatch=visualMatch??match;
  const round=currentMatch.round!;
  const sport=sportDefinition(round.sport);
  $('#sp-event-progress').textContent=`${sport.name} · ${sport.english}`;
  $('#sp-match-clock').textContent=`${round.time.toFixed(1)}초`;
  $('#sp-live-instruction').textContent=match.phase==='results'?'종목 결과':match.phase==='finished'?'종합 결과':sport.instructions[0];
  const countdown=$('#sp-countdown');countdown.hidden=match.phase!=='countdown';
  countdown.textContent=match.phase==='countdown'?String(Math.max(1,Math.ceil(match.countdown))):'';
  for(const {person,view} of cards) {
    const player=round.players.find(candidate=>candidate.id===person.id)!;
    const card=view.canvas.closest('article')!;
    card.querySelector('.sp-player-score')!.textContent=`${Math.round(player.score||person.total).toLocaleString()} P`;
    const status=player.finished?player.result:statusText(player,round.sport);
    card.querySelector('.sp-player-status')!.textContent=status;
    const value=round.sport==='swimming'?player.oxygen:round.sport==='archery'?player.angle/10:player.power;
    (card.querySelector('.sp-meter i') as HTMLElement).style.width=`${Math.max(0,Math.min(1,value))*100}%`;
    view.canvas.dataset.progress=player.progress.toFixed(2);
    view.canvas.dataset.phase=player.phase;
  }
  if(arena)for(const person of match.athletes){
    const player=round.players.find(candidate=>candidate.id===person.id);
    const item=document.querySelector<HTMLElement>(`[data-arena-player="${person.id}"]`);
    if(!player||!item)continue;
    item.querySelector('b')!.textContent=`${Math.round(player.score||person.total).toLocaleString()} P`;
    item.querySelector('small')!.textContent=player.finished?player.result:statusText(player,round.sport);
    const value=round.sport==='swimming'?player.oxygen:round.sport==='archery'?player.angle/10:player.power;
    (item.querySelector('.sp-meter i') as HTMLElement).style.width=`${Math.max(0,Math.min(1,value))*100}%`;
  }
  const mine=round.players.find(player=>player.id===(practice?'practice':session?.playerId));
  const myStatus=$('#sp-my-status');if(myStatus&&mine)myStatus.textContent=mine.finished?mine.result:statusText(mine,round.sport);
  if(match.phase==='results'||match.phase==='finished') {
    const results=$('#sp-results');results.hidden=false;
    const standings=match.phase==='finished'?[...match.athletes].sort((a,b)=>b.total-a.total):[...match.athletes].sort((a,b)=>round.players.find(player=>player.id===b.id)!.score-round.players.find(player=>player.id===a.id)!.score);
    results.innerHTML=`<h2>${practice?'연습 결과':match.phase==='finished'?'오늘의 우당탕 챔피언':'이번 종목 순위'}</h2><ol>${standings.map((person,index)=>`<li><b>${index+1}</b><img src="${avatar(person)}" alt=""><span>${html(person.name)}<small>${round.players.find(player=>player.id===person.id)!.result}</small></span><strong>${(currentMatch.phase==='finished'?person.total:round.players.find(player=>player.id===person.id)!.score).toLocaleString()} P</strong></li>`).join('')}</ol>`;
  }
  if(!host&&room&&Date.now()-room.hostSeen>7000)notice('방장 연결을 기다리고 있어요. 방장 화면을 열어두세요.');
}
function statusText(player:NonNullable<Match['round']>['players'][number],sport:SportId) {
  if(sport==='hurdles'){
    if(player.phase==='fall'||player.phase==='recover')return '허들에 걸렸어요 · 다시 일어나는 중';
    const next=HURDLES[player.stage],distance=next===undefined?null:Math.max(0,next-player.progress);
    return `${player.progress.toFixed(1)} / 100m · ${player.hits}/10 통과 · ${distance===null?'결승선으로!':`다음 허들 ${distance.toFixed(1)}m · B 점프`}`;
  }
  if(sport==='swimming'&&player.phase==='gasping')return '숨이 차서 멈췄어요 · B로 호흡';
  if(sport==='swimming')return `${Math.min(100,player.progress).toFixed(1)}m · ${player.oxygen<=.32?'B로 호흡하세요!':'A · C 연타'}`;
  if(sport==='skeet')return `${player.hits} / ${SKEET_TARGET_COUNT} 명중 · 상자에 들어오면 사격`;
  if(sport==='archery')return `${player.attempts} / ${player.bonus?11:8}발 · 각도 ${player.angle.toFixed(1)} · ${player.score}점`;
  if(sport==='weightlifting')return `${player.weight}kg · ${player.phase==='ready'?'A·C 무게, B 결정':player.phase==='hold'?'버티기! A·C 연타':player.power>=.72?'지금 B!':'A·C로 힘 모으기'}`;
  if(sport==='triple')return `${['홉 35°','스텝 41°','점프 45°'][Math.min(2,player.stage)]} · ${player.phase==='angle'?player.angle.toFixed(0)+'°':'A·C 달리기, B 도약'}`;
  if(sport==='pole')return player.phase==='bend'?'높이 올라갔을 때 B를 놓아요!':'A·C 도움닫기 · 홈 직전 B 유지';
  return player.phase==='angle'?`도약 각도 ${player.angle.toFixed(0)}° · 45–60°에서 B 놓기`:player.phase==='air'?`A로 회전 · ${player.attempts}회 누름 · 8번마다 한 바퀴`:`속도 ${player.speed.toFixed(1)} · A·C 연타, 발판에서 B 누르기`;
}
async function resetLobby() {
  if(practice) {startPractice(chosen);return;}
  if(!session)return;
  try {
    connection?.stop();
    const reply=await api<SyncReply>('host',{code:session.code,token:session.token,reset:true});
    match=null;room=reply.view;viewKey='';connect();
    if(connection)connection.epoch=reply.epoch??0;
  }
  catch(error) {connection?.start();notice((error as Error).message);}
}
function startPractice(sport=chosen) {
  releaseControls();connection?.stop();connection=null;session=null;room=null;storeSession(null);practice=true;viewMode='all';chosen=sport;accumulator=0;
  const person:Athlete={id:'practice',name:'나의 선수',avatar:selectedAvatar,color:PLAYER_COLORS[selectedAvatar],ready:true,connected:true,total:0};
  match=createMatch([person],[sport]);visualMatch=null;startRound(match);viewKey='';renderRoom();
}
function leave() {
  releaseControls();unbindControls();unbindControls=()=>{};connection?.stop();connection=null;session=null;match=null;visualMatch=null;room=null;practice=false;localReady=false;
  storeSession(null);history.replaceState(null,'','?game=sports');viewKey='';renderLanding();notice('');
}
function frame(now:number) {
  sound.sync(match);
  document.body.dataset.audioSource='reference-msx';
  document.body.dataset.audioReady=String(sound.ready);
  const dt=lastTime?Math.min(.25,(now-lastTime)/1000):0;
  lastTime=now;
  if((practice||session?.role==='host')&&match) {
    accumulator+=dt;
    while(accumulator>=1/60) {if(practice)stepMatch(match,1/60);else remoteTimeline.step(match,1/60);accumulator-=1/60;}
    match.updatedAt=Date.now();
    if(connection)connection.match=match;
    renderRoom();
  }
  if(heroCanvas) {
    const g=heroCanvas.getContext('2d')!;g.imageSmoothingEnabled=false;stadium(g,800,370,now/1000,true);
    for(let i=0;i<8;i++) {
      g.save();g.translate(80+i*91,275+i%2*30);
      g.drawImage(spriteForHero(i,now/1000),-32,-57,64,64);g.restore();
    }
    g.fillStyle='#f0cf81';g.font='900 40px sans-serif';g.textAlign='center';g.fillText('LET’S PLAY!',400,92);
  }
  if(heroSport)heroSport.draw({id:'guide',name:'안내',avatar:0,color:PLAYER_COLORS[0],ready:true,connected:true,total:0},null,null,now/1000,chosen);
  visualMatch=match?.round&&match.phase==='playing'&&!practice&&session?.role!=='host'
    ?projectRemoteMatch(match,connection?.unconfirmed??[],clientRoundTime(now)):match;
  const renderRound=visualMatch?.round??null;
  for(const {view,person} of cards)view.draw(person,renderRound?.players.find(player=>player.id===person.id)??null,renderRound,now/1000);
  if(arena&&visualMatch)arena.draw(visualMatch.athletes,renderRound,now/1000,session?.playerId);
  if(now-lastUi>120) {lastUi=now;updateRoomUi();}
  if(!stopped)frameRequest=requestAnimationFrame(frame);
}
// Reuse the existing game's character artwork for a consistent game library.
import {sprite} from '../rendering/renderer.ts';
function spriteForHero(index:number,time:number) {
  return sprite({id:'hero'+index,name:'',avatarId:avatars[index].id,paletteId:PLAYER_COLORS[index]},Math.floor(time*12+index)%8,'run');
}
window.addEventListener('keydown',event=>{
  if(event.repeat||document.querySelector('dialog[open]')||/INPUT|TEXTAREA|SELECT/.test((event.target as HTMLElement).tagName))return;
  const button=({a:'A',s:'B',d:'C'} as Record<string,Control>)[event.key.toLowerCase()];
  if(button) {event.preventDefault();press(button,true);}
});
window.addEventListener('keyup',event=>{
  const button=({a:'A',s:'B',d:'C'} as Record<string,Control>)[event.key.toLowerCase()];if(button)press(button,false);
});
window.addEventListener('blur',releaseControls);
document.addEventListener('pointerdown',()=>void sound.unlock(),{passive:true});
document.addEventListener('keydown',()=>void sound.unlock(),{passive:true});
window.addEventListener('pagehide',()=>{releaseControls();stopped=true;if(frameRequest!==null)cancelAnimationFrame(frameRequest);frameRequest=null;connection?.stop();sound.stop();});
window.addEventListener('pageshow',()=>{if(!stopped)return;stopped=false;lastTime=0;lastReplyAt=0;connection?.start();frameRequest=requestAnimationFrame(frame);});
shell();
renderLanding();
void loadSwimmingMotion();void loadVaultMotions();
void loadSkeetMotion();
void loadArcheryMotion();
void loadRunnerAtlas().then(()=>{
  document.querySelectorAll<HTMLImageElement>('[data-avatar] img').forEach((image,index)=>{image.src=avatar({id:'choice',name:'',avatar:index,color:PLAYER_COLORS[index]});});
});
try {
  const saved=JSON.parse(sessionStorage.getItem('udangtang.sports.session')??'null') as Session|null;
  if(saved&&(!query.get('room')||query.get('room')===saved.code)&&query.get('view')!=='display') {session=saved;connect();}
  else if(query.get('room')&&query.get('view')==='display')void watchRoom();
} catch {}
frameRequest=requestAnimationFrame(frame);
