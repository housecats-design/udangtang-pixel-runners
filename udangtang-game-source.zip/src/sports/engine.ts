import {sportDefinition, type Athlete, type Competitor, type Control, type Match, type SportId, type SportsRound} from './model.ts';
import {createSkeetCourse,SKEET_PREVIEW,skeetBonusAt,skeetShotTarget,skeetSide,type SkeetShot} from './skeet.ts';
import {HURDLES,HURDLE_JUMP_SECONDS,HURDLE_CLEARANCE,hurdleHeight} from './hurdles.ts';

const clamp = (value:number, min:number, max:number) => Math.min(max, Math.max(min, value));
export function createMatch(athletes:Athlete[], events:SportId[]):Match {
  return {phase:'lobby',events:[...events],eventIndex:0,countdown:3,round:null,athletes:structuredClone(athletes),number:0,updatedAt:Date.now()};
}
export function startRound(match:Match) {
  match.number++;
  match.countdown=3;
  match.phase='countdown';
  match.round={sport:match.events[match.eventIndex],time:0,wind:0,completed:false,players:match.athletes.map(athlete => ({
    id:athlete.id,progress:0,speed:0,power:0,oxygen:1,breathAt:-100,phase:'ready',phaseAt:0,
    lastTap:null,lastPulse:-100,angle:0,rotation:0,height:0,weight:180,hits:0,attempts:0,
    bonus:0,score:0,result:'',finished:false,finishAt:null,quality:0,stage:0,shots:[],angles:[],aimAt:null,
    feedback:'',feedbackAt:-100,shotEffects:[],
  }))};
  if(match.round.sport==='skeet')match.round.skeetTargets=createSkeetCourse(crypto.getRandomValues(new Uint32Array(1))[0]);
}
function feedback(player:Competitor, round:SportsRound, message:string) {
  player.feedback=message;
  player.feedbackAt=round.time;
}
function shotEffect(player:Competitor,shot:SkeetShot){
  player.lastTap=shot.side===0?'A':'C';player.lastPulse=shot.at;
  player.shotEffects=[...(player.shotEffects??[]),shot].slice(-8);
}
function finishPlayer(player:Competitor, round:SportsRound, score:number, result:string) {
  if(player.finished)return;
  player.finished=true;
  player.finishAt=round.time;
  player.score=Math.round(Math.max(0,score));
  player.result=result;
  player.height=0;player.speed=0;
}
function pulse(player:Competitor, button:Control, round:SportsRound, amount=1) {
  // Server-received presses are capped, and alternating hands give a stronger stroke.
  if(round.time-player.lastPulse<.045)return;
  const alternating=player.lastTap!==button;
  player.speed=clamp(player.speed+(alternating?amount:amount*.4),0,10);
  player.power=clamp(player.power+(alternating?.075:.035),0,1);
  player.lastTap=button;
  player.lastPulse=round.time;
}
function releaseAngle(player:Competitor, round:SportsRound, heldMs:number|undefined, rate:number) {
  const held=heldMs===undefined?round.time-(player.aimAt??round.time):clamp(heldMs/1000,0,4);
  return clamp(held*rate,0,rate===4?10:75);
}
export function applyControl(match:Match, playerId:string, button:Control, down:boolean, heldMs?:number) {
  if(match.phase!=='playing'||!match.round)return;
  const round=match.round;
  const player=round.players.find(candidate=>candidate.id===playerId);
  if(!player||player.finished)return;
  const time=round.time;
  switch(round.sport) {
    case 'hurdles':
      if(!down||player.phase==='fall'||player.phase==='recover')return;
      if(button==='B'){
        if(player.phase==='ready'||player.phase==='run'){player.phase='jump';player.phaseAt=time;player.height=0;}
      }else{
        if(player.phase==='ready')player.phase='run';
        pulse(player,button,round,.95);
      }
      break;
    case 'swimming':
      if(!down)return;
      swimmingBreath(player,round);
      if(button==='B') {
        if(player.oxygen<=.32||player.phase==='gasping') {
          player.oxygen=1;player.breathAt=time;player.phase='swim';player.phaseAt=time;
          feedback(player,round,'NICE BREATH!');
        }
      } else if(player.phase!=='gasping') {
        pulse(player,button,round,.9);player.oxygen=clamp(player.oxygen-.035,0,1);swimmingBreath(player,round);
      }
      break;
    case 'skeet': {
      if(!down||button==='B')return;
      const course=round.skeetTargets??SKEET_PREVIEW;
      const side=skeetSide(button);
      if(player.skeetAim?.side!==side)player.skeetAim={side,at:time,fromSide:player.skeetAim?.side};
      if(time-player.lastPulse<.105)return;
      if(time<skeetBonusAt(course)) {
        const target=skeetShotTarget(time,side,course,player.shots);
        const hit=!!target&&Math.abs(time-target.hitAt)<=24/target.speed;
        if(target)player.shots.push(target.id);
        player.attempts++;
        shotEffect(player,{id:target?.id??-player.attempts,side,at:time,hit});
        if(hit) {player.hits++;feedback(player,round,'HIT!');}
        else feedback(player,round,'MISS');
      } else if(player.hits===course.length&&time-player.lastPulse>.35) {
        player.bonus+=1000;shotEffect(player,{id:course.length+player.bonus/1000,side,at:time,hit:true,bonus:true});feedback(player,round,'BONUS +1000');
      }
      break;
    }
    case 'vault':
      if((player.phase==='ready'||player.phase==='run')&&down&&button!=='B') {
        player.phase='run';pulse(player,button,round,.95);
      } else if(player.phase==='run'&&button==='B'&&down) {
        player.quality=clamp(1-Math.abs(player.progress-76)/18,0,1);
        player.vault={runSpeed:player.speed,launchAngle:20,peak:0,duration:0,targetRotation:0};
        player.phase='angle';player.phaseAt=time;player.aimAt=time;player.angle=20;
      } else if(player.phase==='angle'&&button==='B'&&!down&&player.vault) {
        const held=heldMs===undefined?time-player.phaseAt:clamp(heldMs/1000,0,2);
        player.angle=clamp(20+held*90,20,80);player.aimAt=null;
        const v=player.vault;v.launchAngle=player.angle;
        const radians=player.angle*Math.PI/180,energy=clamp(v.runSpeed/10,0,1)*player.quality;
        v.peak=20+energy*65*Math.sin(radians);v.duration=1.4+energy*.9+Math.sin(radians)*.4;
        player.quality*=clamp(1-Math.abs(player.angle-52)/60,0,1);
        player.phase='takeoff';player.phaseAt=time;player.progress=76;player.rotation=0;
        feedback(player,round,`${player.angle.toFixed(0)}° 도약 · 공중에서 A!`);
      } else if(player.phase==='air'&&button==='A'&&down&&player.vault&&time-player.lastPulse>=.07) {
        player.attempts++;player.vault.targetRotation+=Math.PI/4;player.lastPulse=time;
      }
      break;
    case 'archery':
      if(player.phase==='ready'&&down) {
        round.wind=Math.round(Math.sin(time*1.9)*3);
        player.quality=round.wind;
        player.phase='aim';feedback(player,round,`바람 ${Math.abs(round.wind)} ${round.wind<0?'←':'→'}`);
      } else if(player.phase==='aim'&&button==='B') {
        if(down&&player.aimAt===null&&(!player.arrow||time-player.arrow.at>=1.05)) {player.aimAt=time;player.phaseAt=time;player.angle=0;}
        if(!down&&player.aimAt!==null) {
          const held=heldMs===undefined?time-player.aimAt:clamp(heldMs/1000,0,4);
          if(held<.5){player.aimAt=null;feedback(player,round,'장전이 끝난 뒤 각도를 맞춰요');return;}
          const angle=clamp((held-.5)*4,0,10);
          const error=Math.abs(angle-5.25+player.quality*.1);
          const points=clamp(10-Math.floor(error*3),0,10);
          player.angle=angle;player.aimAt=null;player.attempts++;player.arrow={at:time,angle,points,error};
          player.score+=player.attempts>8?(points>=9?1000:0):points*100;
          if(points===10)player.hits++;
          feedback(player,round,points===10?'NICE!':`${points}점 · ${angle.toFixed(1)}°`);
          if(player.attempts===8&&player.hits===8) {player.bonus=3000;feedback(player,round,'PERFECT! 사과 보너스 3발');}
          if(player.attempts>=(player.bonus?11:8))player.phase='arrow-end';
        }
      }
      break;
    case 'triple':
      if(down&&button!=='B'&&(player.phase==='ready'||player.phase==='run')) {
        player.phase='run';pulse(player,button,round,.9);
      }
      if(button!=='B')return;
      if(down&&(player.phase==='run'||player.phase==='step')) {
        if(player.stage===0&&player.progress>83) {finishPlayer(player,round,0,'파울');return;}
        player.aimAt=time;player.phase='angle';
      }
      if(!down&&player.phase==='angle') {
        const angle=releaseAngle(player,round,heldMs,45);
        player.angle=angle;player.angles.push(angle);player.aimAt=null;
        const ideal=[35,41,45][player.stage];
        player.quality=clamp(1-Math.abs(angle-ideal)/45,0,1);
        const distance=(3.4+player.speed*.34)*player.quality;
        player.power+=distance;player.phase='flight';player.phaseAt=time;
      }
      break;
    case 'weightlifting':
      if(!down)return;
      if(player.phase==='ready') {
        if(button==='A')player.weight=clamp(player.weight+10,150,280);
        if(button==='C')player.weight=clamp(player.weight-10,150,280);
        if(button==='B') {player.phase='lift';player.phaseAt=time;}
      } else if(button!=='B')pulse(player,button,round,.2);
      else if(player.phase==='lift'&&player.power>=.72) {
        player.phase='hold';player.phaseAt=time;player.quality=0;
        feedback(player,round,'HOLD! 계속 연타하세요');
      }
      break;
    case 'pole':
      if(button!=='B'&&down&&(player.phase==='ready'||player.phase==='run')) {
        player.phase='run';pulse(player,button,round,.8);
      }
      if(button==='B'&&down&&player.phase==='run') {
        player.quality=clamp(1-Math.abs(player.progress-79)/22,0,1);
        player.phase='bend';player.phaseAt=time;
      } else if(button==='B'&&!down&&player.phase==='bend') {
        const held=heldMs===undefined?time-player.phaseAt:heldMs/1000;
        const timing=clamp(1-Math.abs(held-1.15)/1.05,0,1);
        player.power=(3.6+player.speed*.22)*player.quality*timing;
        player.phase='air';player.phaseAt=time;
        feedback(player,round,timing>.85?'PERFECT RELEASE':'장대 놓기');
      }
      break;
  }
}
function swimmingBreath(player:Competitor,round:SportsRound){
  if(player.phase==='gasping')return;
  if(player.oxygen<=.32&&player.phase!=='breath'){player.phase='breath';player.phaseAt=round.time;}
  if(player.oxygen<=0||player.phase==='breath'&&round.time-player.phaseAt>=.7){
    player.phase='gasping';player.phaseAt=round.time;player.speed=0;
    feedback(player,round,'숨이 차요! B로 호흡');
  }
}
function stepSwimming(player:Competitor, round:SportsRound, dt:number) {
  swimmingBreath(player,round);
  if(player.phase==='gasping'){player.speed=0;return;}
  player.speed=Math.max(.3,player.speed-dt*1.55);
  player.oxygen=Math.max(0,player.oxygen-dt*.06);
  swimmingBreath(player,round);
  if(player.phase==='gasping')return;
  player.progress+=player.speed*dt;
  if(player.progress>=100) {player.progress=100;finishPlayer(player,round,15000-round.time*150,`${round.time.toFixed(2)}초`);}
}
function stepHurdles(player:Competitor,round:SportsRound,dt:number){
  const age=round.time-player.phaseAt;
  if(player.phase==='fall'){
    player.rotation=Math.min(1,age/.4)*1.45;player.progress+=dt*.6;
    if(age>=.45){player.phase='recover';player.phaseAt=round.time;}
    return;
  }
  if(player.phase==='recover'){
    player.rotation=1.45*(1-Math.min(1,age/.45));
    if(age>=.45){player.phase='run';player.phaseAt=round.time;player.rotation=0;}
    return;
  }
  player.speed=Math.max(0,player.speed-dt*1.5);player.power=player.speed/10;
  const from=player.progress;
  player.progress+=player.speed*dt;
  player.height=player.phase==='jump'?hurdleHeight(age):0;
  while(player.stage<HURDLES.length&&player.progress>=HURDLES[player.stage]){
    const index=player.stage++,position=HURDLES[index];
    const crossing=round.time-dt+(player.progress>from?Math.max(0,position-from)/(player.progress-from)*dt:dt);
    const height=player.phase==='jump'?hurdleHeight(crossing-player.phaseAt):0;
    if(height>=HURDLE_CLEARANCE){player.hits++;feedback(player,round,`잘 넘었어요! ${player.hits}/10`);}
    else{
      player.shots.push(index);player.attempts++;player.phase='fall';player.phaseAt=round.time;
      player.height=0;player.speed*=.35;feedback(player,round,'허들에 걸렸어요! 다시 일어나요');break;
    }
  }
  if(player.phase==='jump'&&age>=HURDLE_JUMP_SECONDS){player.phase='run';player.phaseAt=round.time;player.height=0;}
  if(player.progress>=100){
    player.progress=100;player.rotation=0;
    finishPlayer(player,round,20000-round.time*200+player.hits*200-player.attempts*150,`${round.time.toFixed(2)}초 · ${player.hits}/10 통과`);
  }
}
function stepVault(player:Competitor, round:SportsRound, dt:number) {
  const age=round.time-player.phaseAt,v=player.vault;
  if(player.phase==='run') {
    player.speed=Math.max(0,player.speed-dt*1.3);player.power=player.speed/10;
    player.progress+=player.speed*dt*1.6;
    if(player.progress>89){player.phase='cry';finishPlayer(player,round,0,'도약 실패');}
  } else if(player.phase==='angle') {
    player.angle=clamp(20+age*90,20,80);
  } else if(player.phase==='takeoff') {
    player.height=Math.sin(Math.min(1,age/.4)*Math.PI/2)*24;
    player.progress=76+Math.min(1,age/.4)*8;
    if(age>=.4){player.phase='horse';player.phaseAt=round.time;}
  } else if(player.phase==='horse') {
    player.height=24+Math.sin(Math.min(1,age/.35)*Math.PI/2)*12;player.progress=84+age*12;
    if(age>=.35){player.phase='air';player.phaseAt=round.time;player.rotation=0;}
  } else if(player.phase==='air'&&v) {
    const flight=Math.min(1,age/v.duration);
    player.progress=88+flight*(25+v.runSpeed*2);player.height=(1-flight)*36+Math.sin(flight*Math.PI)*v.peak;
    player.rotation+=(v.targetRotation-player.rotation)*Math.min(1,dt*14);
    if(flight>=1){
      const upright=Math.abs(Math.sin(player.rotation/2))<.3;
      v.success=player.attempts>=8&&upright&&v.runSpeed>=4&&player.quality>.3;
      player.phase='landing';player.phaseAt=round.time;player.height=0;
      feedback(player,round,v.success?'착지 성공!':'착지 실패…');
    }
  } else if(player.phase==='landing'&&age>=.7){
    if(v?.success){player.phase='salute';finishPlayer(player,round,player.quality*5000+Math.floor(player.attempts/8)*1500+3000,`착지 성공 · ${Math.floor(player.attempts/8)}회전`);}
    else {player.phase='fall';player.phaseAt=round.time;}
  } else if(player.phase==='fall'&&age>=.7){
    player.phase='cry';player.phaseAt=round.time;finishPlayer(player,round,0,'착지 실패');
  }
}
function stepTriple(player:Competitor, round:SportsRound, dt:number) {
  if(player.phase==='run') {
    player.speed=Math.max(1,player.speed-dt*.8);
    player.progress+=player.speed*dt*1.6;
    if(player.progress>84)finishPlayer(player,round,0,'발구름 선 파울');
  } else if(player.phase==='flight') {
    const age=round.time-player.phaseAt;
    player.height=Math.sin(Math.min(1,age/1.1)*Math.PI)*(20+player.quality*22);
    player.progress+=15*dt;
    if(age>=1.1) {
      player.stage++;
      if(player.stage===3) {
        player.bonus=player.power>=19?3000:0;
        player.phase='landing';player.phaseAt=round.time;player.height=0;
      } else {player.phase='step';player.phaseAt=round.time;}
    }
  } else if(player.phase==='landing'&&round.time-player.phaseAt>=1.2){
    finishPlayer(player,round,player.power*500+player.bonus,`${player.power.toFixed(2)}m${player.bonus?' · 비행기 +3000':''}`);
  } else if(player.phase==='step'&&round.time-player.phaseAt>3.5)finishPlayer(player,round,0,'다음 발구름 시간 초과');
}
function stepWeightlifting(player:Competitor, round:SportsRound, dt:number) {
  if(player.phase==='lift'||player.phase==='hold')player.power=Math.max(0,player.power-dt*(.14+(player.weight-150)/600));
  if(player.phase==='hold') {
    if(player.power>.32)player.quality+=dt;
    if(player.quality>=3)finishPlayer(player,round,player.weight*40+1000,`${player.weight}kg 성공!`);
    else if(player.power===0)finishPlayer(player,round,0,'역기를 놓쳤어요');
  }
}
function stepPole(player:Competitor, round:SportsRound, dt:number) {
  if(player.phase==='run') {
    player.speed=Math.max(.7,player.speed-dt*.5);
    player.progress+=player.speed*dt*1.7;
    if(player.progress>91)finishPlayer(player,round,0,'장대 꽂기 실패');
  } else if(player.phase==='bend') {
    const age=round.time-player.phaseAt;
    player.height=Math.sin(Math.min(1,age/1.6)*Math.PI/2)*60;
    player.rotation=-Math.min(1,age/1.6)*1.6;
    if(age>2)finishPlayer(player,round,0,'장대를 놓아주세요');
  } else if(player.phase==='air') {
    const age=round.time-player.phaseAt;
    player.progress=80+age*24;
    player.height=60+Math.sin(Math.min(1,age/2)*Math.PI)*player.power*9-age*25;
    player.rotation=-1.6+age*2;
    if(age>=2) {
      const success=player.power>=4.5;
      player.bonus=success&&player.quality>.9?2000:0;
      finishPlayer(player,round,success?player.power*1500+player.bonus:0,success?`${player.power.toFixed(2)}m 성공${player.bonus?' · 두더지 +2000':''}`:'바를 넘지 못했어요');
    }
  }
}
export function stepMatch(match:Match, dt:number) {
  if(match.phase==='countdown') {
    match.countdown-=dt;
    if(match.countdown<=0)match.phase='playing';
    return;
  }
  if(match.phase!=='playing'||!match.round)return;
  const round=match.round;
  round.time+=dt;
  for(const player of round.players) {
    if(player.finished)continue;
    switch(round.sport) {
      case 'hurdles':stepHurdles(player,round,dt);break;
      case 'swimming':stepSwimming(player,round,dt);break;
      case 'skeet':
        if(round.time>=sportDefinition(round.sport).duration)finishPlayer(player,round,player.hits*350+player.bonus,`${player.hits}/${(round.skeetTargets??SKEET_PREVIEW).length} 명중`);
        break;
      case 'archery':if(player.phase==='arrow-end'&&player.arrow&&round.time-player.arrow.at>=1.5)finishPlayer(player,round,player.score+player.bonus,`${player.score+player.bonus}점`);break;
      case 'vault':stepVault(player,round,dt);break;
      case 'triple':stepTriple(player,round,dt);break;
      case 'weightlifting':stepWeightlifting(player,round,dt);break;
      case 'pole':stepPole(player,round,dt);break;
    }
    if(player.aimAt!==null&&round.sport!=='vault')player.angle=clamp((round.time-player.aimAt-(round.sport==='archery'?.5:0))*(round.sport==='archery'?4:45),0,round.sport==='archery'?10:75);
    if(round.time>=sportDefinition(round.sport).duration&&!player.finished) {
      if(round.sport==='vault')player.phase='cry';
      finishPlayer(player,round,round.sport==='swimming'?player.progress*25:round.sport==='hurdles'?player.progress*35+player.hits*200:player.score,'시간 종료');
    }
  }
  if(round.players.every(player=>player.finished)) {
    // Swimming photo-finish bonus uses a centisecond tie between the middle lanes.
    if(round.sport==='swimming'&&round.players.length>=2) {
      const center=Math.floor(round.players.length/2);
      const a=round.players[center-1],b=round.players[center];
      if(a.progress===100&&b.progress===100&&Math.round(a.finishAt!*100)===Math.round(b.finishAt!*100)) {
        for(const player of [a,b]) {player.bonus+=3000;player.score+=3000;player.result+=' · 포토피니시 +3000';}
      }
    }
    round.completed=true;
    for(const athlete of match.athletes)athlete.total+=round.players.find(player=>player.id===athlete.id)!.score;
    match.phase='results';
  }
}
export function nextRound(match:Match) {
  if(match.phase!=='results')return;
  if(match.eventIndex+1>=match.events.length) {match.phase='finished';return;}
  match.eventIndex++;
  startRound(match);
}
