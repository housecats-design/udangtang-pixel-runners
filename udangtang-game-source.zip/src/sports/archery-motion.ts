import {avatars} from '../data/avatars.ts';
import type {Athlete} from './model.ts';

const SIZE=64,COLUMNS=5;
let atlas:HTMLImageElement|null=null,loading:Promise<boolean>|null=null;
const frames=new Map<string,HTMLCanvasElement>();
export function hasArcheryMotion(){return atlas!==null;}
export function loadArcheryMotion(){return loading??=load();}
async function load(){
  const image=new Image();image.src=`${import.meta.env.BASE_URL}assets/characters/pixellab-archery-sd.png`;
  try{await image.decode();if(image.width!==320||image.height!==256)return false;atlas=image;frames.clear();return true;}
  catch{loading=null;return false;}
}
const rgb=(hex:string)=>[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16));
export function archeryFrame(person:Athlete,index:number){
  if(!atlas)return null;
  index=Math.max(0,Math.min(16,Math.floor(index)));
  const key=`${person.avatar}:${person.color}:${index}`,cached=frames.get(key);if(cached)return cached;
  const canvas=document.createElement('canvas');canvas.width=canvas.height=SIZE;
  const g=canvas.getContext('2d')!;g.imageSmoothingEnabled=false;
  g.drawImage(atlas,index%COLUMNS*SIZE,Math.floor(index/COLUMNS)*SIZE,SIZE,SIZE,0,0,SIZE,SIZE);
  const a=avatars[person.avatar%avatars.length],hair=rgb(a.hair),skin=rgb(a.skin),shirt=rgb(person.color),pants=rgb(a.pants);
  const image=g.getImageData(0,0,SIZE,SIZE),pixels=image.data;
  for(let i=0;i<pixels.length;i+=4){
    if(!pixels[i+3])continue;
    const r=pixels[i],green=pixels[i+1],b=pixels[i+2],y=Math.floor(i/4/SIZE),x=i/4%SIZE;
    let color:number[]|null=null,base=1;
    if(green>r+12&&green>b+4){color=shirt;base=150;}
    // Keep the wooden bow at the right of the sprite brown for every athlete.
    else if(x<44&&y<31&&r>45&&r>green+12&&green>b+3&&green<150){color=hair;base=100;}
    else if(r>170&&green>120&&green/r>.7&&r>green+12&&green>b+6){color=skin;base=200;}
    else if(y>38&&b>r+7&&r<100&&green<110){color=pants;base=55;}
    if(color){const shade=Math.max(.35,Math.min(1.4,(r*.25+green*.6+b*.15)/base));for(let c=0;c<3;c++)pixels[i+c]=Math.round(Math.min(255,color[c]*shade));}
  }
  g.putImageData(image,0,0);frames.set(key,canvas);return canvas;
}
