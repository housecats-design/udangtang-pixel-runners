// Equipment painted into the source takeoff tiles must never move with the athlete.
const standBounds:Record<number,readonly [number,number]>={6:[68,45],7:[61,45],8:[54,46],9:[51,45],10:[46,45],11:[43,44],12:[34,47],13:[28,49],14:[26,49],15:[24,49]};
export function removeVaultStand(pixels:Uint8ClampedArray,index:number,width=96){
 const bounds=standBounds[index];if(!bounds)return;
 const [left,top]=bounds;
 for(let i=0;i<pixels.length;i+=4){
  const x=(i/4)%width,y=Math.floor(i/(width*4));if(x<left||y<top||!pixels[i+3])continue;
  const r=pixels[i],g=pixels[i+1],b=pixels[i+2];
  // The hands are warm skin and the jersey is saturated teal; both stay intact.
  // Below the grip only the stand is present. The upper lip is neutral grey.
  if(y>=58||Math.max(r,g,b)-Math.min(r,g,b)<42&&b-r<23)pixels[i+3]=0;
 }
}
