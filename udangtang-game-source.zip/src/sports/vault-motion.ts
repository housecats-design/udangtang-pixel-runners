import {avatars} from '../data/avatars.ts';
import type {Athlete} from './model.ts';
import {removeVaultStand} from './vault-cutout.ts';
type Clip='takeoff'|'somersault'|'landing';
const counts={takeoff:16,somersault:16,landing:12};
const atlases:Partial<Record<Clip,HTMLImageElement>>={},frames=new Map<string,HTMLCanvasElement>();
export async function loadVaultMotions(){
  await Promise.all((Object.keys(counts) as Clip[]).map(async clip=>{
    const image=new Image();image.src=`${import.meta.env.BASE_URL}assets/characters/pixellab-vault-${clip}.png`;
    try{await image.decode();if(image.width===384)atlases[clip]=image;}catch{}
  }));return Object.keys(atlases).length===3;
}
export function vaultFrame(person:Athlete,clip:Clip,index:number){
  const atlas=atlases[clip];if(!atlas)return null;
  index=Math.min(counts[clip]-1,Math.max(0,Math.floor(index)));
  const key=`${person.avatar}:${person.color}:${clip}:${index}`,cached=frames.get(key);if(cached)return cached;
  const c=document.createElement('canvas');c.width=c.height=96;
  const g=c.getContext('2d')!;g.imageSmoothingEnabled=false;g.drawImage(atlas,index%4*96,Math.floor(index/4)*96,96,96,0,0,96,96);
  const a=avatars[person.avatar%avatars.length],rgb=(s:string)=>[1,3,5].map(i=>parseInt(s.slice(i,i+2),16));
  const pixels=g.getImageData(0,0,96,96),d=pixels.data;
  if(clip==='takeoff')removeVaultStand(d,index);
  for(let i=0;i<d.length;i+=4){
    if(!d[i+3])continue;
    const r=d[i],b=d[i+2],green=d[i+1];
    if(person.avatar===0)continue;
    let color:number[]|null=null,level=1;
    if(green-r>12&&b-r>6){color=rgb(person.color);level=(r*.25+green*.6+b*.15)/130;}
    else if(r>142&&r-green>14&&green-b>9&&green/r>.66){color=rgb(a.skin);level=(r*.25+green*.6+b*.15)/195;}
    else if(r>42&&r-green>12&&green-b>4&&green/r<.78){color=rgb(a.hair);level=(r*.25+green*.6+b*.15)/95;}
    else if(b-r>7&&b-green>2&&r<85&&green<95){color=rgb(a.pants);level=(r*.25+green*.6+b*.15)/55;}
    if(color)for(let j=0;j<3;j++)d[i+j]=Math.min(255,Math.round(color[j]*Math.max(.3,Math.min(1.5,level))));
  }
  g.putImageData(pixels,0,0);
  let minX=96,minY=96,maxX=0,maxY=0;
  for(let y=0;y<96;y++)for(let x=0;x<96;x++)if(d[(y*96+x)*4+3]>80){minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);}
  const normalized=document.createElement('canvas');normalized.width=normalized.height=96;
  const n=normalized.getContext('2d')!;n.imageSmoothingEnabled=false;
  n.drawImage(c,Math.round(48-(minX+maxX)/2),Math.round(clip==='somersault'?48-(minY+maxY)/2:76-maxY));
  frames.set(key,normalized);return normalized;
}
