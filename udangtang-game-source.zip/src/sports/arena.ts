import {athlete,drawSkeet,stadium,target} from './render.ts';
import {drawSwimmingFrame,swimmingFrame} from './swimming-motion.ts';
import {ARENA_WIDTH as W,ARENA_HEIGHT as H,arenaLanes,arenaStations} from './arena-layout.ts';
import {sportDefinition,type Athlete,type Competitor,type SportsRound} from './model.ts';
import {HURDLES} from './hurdles.ts';
import {drawHurdle,drawHurdleAthlete} from './hurdles-render.ts';
import {drawTripleAthlete} from './triple-render.ts';
import {drawSportsHud} from './sports-hud.ts';
import {drawArcher,drawArrow} from './archery-render.ts';
import {drawVault} from './vault-render.ts';
import {hasSkeetMotion} from './skeet-motion.ts';
import {hasArcheryMotion} from './archery-motion.ts';
import {drawGrass,drawTrack,drawPool,drawPoolDeck,drawPoolRope,drawSwimWake,drawMat,drawSand,drawPlatform} from './scenery.ts';

const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));
function box(g:CanvasRenderingContext2D,x:number,y:number,w:number,h:number,color:string){g.fillStyle=color;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}
function stroke(g:CanvasRenderingContext2D,x:number,y:number,ex:number,ey:number,color:string,width=2){g.strokeStyle=color;g.lineWidth=width;g.beginPath();g.moveTo(x,y);g.lineTo(ex,ey);g.stroke();}
function label(g:CanvasRenderingContext2D,text:string,x:number,y:number,color='#365c4c',size=16,align:CanvasTextAlign='left'){
  g.fillStyle=color;g.font=`800 ${size}px "Noto Sans KR",sans-serif`;g.textAlign=align;g.fillText(text,x,y);
}
function personName(g:CanvasRenderingContext2D,person:Athlete,index:number,x:number,y:number,align:CanvasTextAlign='left'){
  label(g,`${index+1}  ${person.name}`,x,y,'#32564a',16,align);
}
function drawPerson(g:CanvasRenderingContext2D,person:Athlete,p:Competitor|undefined,x:number,y:number,time:number,pose:string,scale=1,rotation=0){
  g.save();g.translate(x,y);g.scale(scale,scale);
  athlete(g,person,0,0,time,p?.finished?(p.score>0?'cheer':'idle'):pose,rotation);g.restore();
}
function laneColor(index:number){return index%2?'#ffffff0d':'#ffffff00';}

/** A single world-space canvas; athletes share scenery and course coordinates. */
export class SportsArena {
  private g:CanvasRenderingContext2D;
  constructor(readonly canvas:HTMLCanvasElement){canvas.width=W;canvas.height=H;this.g=canvas.getContext('2d')!;this.g.imageSmoothingEnabled=false;}
  draw(people:Athlete[],round:SportsRound|null,time:number,mine?:string|null){
    if(!round)return;
    const g=this.g,athletes=people.slice(0,8),sport=round.sport,t=round.time;
    if(!athletes.length)return;
    this.canvas.dataset.sport=sport;this.canvas.dataset.players=String(athletes.length);this.canvas.dataset.scene='shared-arena';
    stadium(g,W,350,time);
    box(g,0,220,W,H-220,sport==='swimming'?'#d8e6c9':sport==='weightlifting'?'#b9cba4':'#9dbb80');
    if(sport!=='swimming'&&sport!=='weightlifting')drawGrass(g,0,220,W,H-220);
    label(g,sportDefinition(sport).name,42,55,'#355d51',26);
    label(g,`${athletes.length}명이 함께하는 운동장`,42,84,'#617f69',16);
    if(sport==='swimming')this.swimming(athletes,round,time,mine);
    else if(sport==='hurdles')this.hurdles(athletes,round,t);
    else if(sport==='skeet')this.skeet(athletes,round,t);
    else if(sport==='weightlifting')this.lifting(athletes,round,t);
    else if(sport==='archery')this.archery(athletes,round,t);
    else if(sport==='vault')this.vault(athletes,round,t);
    else this.track(athletes,round,t);
    if(!['skeet','weightlifting'].includes(sport))for(const lane of arenaLanes(athletes.length)){const p=round.players.find(p=>p.id===athletes[lane.index].id);drawSportsHud(g,p??null,sport,28,lane.y+12,122,true);}
    this.canvas.dataset.motion=sport==='swimming'&&swimmingFrame(athletes[0],time)?'higgsfield-swimming':sport==='skeet'&&hasSkeetMotion()?'pixellab-skeet-sd':sport==='archery'&&hasArcheryMotion()?'pixellab-archery-sd':'sports-motion';
  }
  private swimming(people:Athlete[],round:SportsRound,time:number,mine?:string|null){
    const g=this.g,lanes=arenaLanes(people.length),top=lanes[0].top,bottom=lanes.at(-1)!.top+lanes.at(-1)!.height;
    drawPoolDeck(g,160,top,1048,bottom-top);drawPool(g,160,top,1048,bottom-top,people.length,time);
    for(let i=0;i<=lanes.length;i++){
      const y=top+i*lanes[0].height;
      drawPoolRope(g,166,y,1030,i,time,21);
    }
    for(const [index,person] of people.entries()){
      const lane=lanes[index],p=round.players.find(p=>p.id===person.id),travel=clamp(p?.progress??0,0,100);
      box(g,160,lane.top,1048,lane.height,laneColor(index));
      if(person.id===mine)box(g,160,lane.top,1048,lane.height,'#fff4ba22');
      box(g,24,lane.y-15,6,30,person.color);personName(g,person,index,40,lane.y+5);
      box(g,170,lane.y-10,15,20,'#315e68');label(g,String(index+1),177,lane.y+5,'#f9efd0',13,'center');
      box(g,1215,lane.y-11,29,7,'#6b9390');box(g,1218,lane.y-14,24,6,'#fff0c9');stroke(g,1220,lane.y-13,1239,lane.y-13,'#bfaa7e',2);
      const x=220+(travel<=50?travel:100-travel)/50*900,direction=travel>50?-1:1;
      const scale=Math.min(1.15,(lane.height-10)/54),frame=swimmingFrame(person,p?.phase==='gasping'?.9:time+index*.13);
      g.save();g.translate(x,lane.y);g.scale(direction*scale,scale);
      if(p?.finished){g.translate(0,15);g.scale(.8,.8);athlete(g,person,0,0,time,'cheer');}
      else if(frame){if(p?.phase==='gasping'){g.translate(0,Math.sin(time*4)*1.5);g.rotate(-.2);}drawSwimmingFrame(g,frame);}else athlete(g,person,0,0,time,'swim');g.restore();
      if(!p?.finished&&p?.phase!=='gasping')for(let i=0;i<5;i++)box(g,x-direction*(25+i*9),lane.y+8+Math.sin(time*9+i)*3,8,2,'#d2eeea');
      if(!p?.finished&&p?.phase!=='gasping')drawSwimWake(g,x,lane.y,time+index*.13,direction,scale);
      if(p&&p.oxygen<=.32&&!p.finished)label(g,p.phase==='gasping'?'멈춤 · B 호흡!':'B · 호흡!',clamp(x+direction*55,225,1145),lane.y-15,'#a34b48',14,'center');
      if(p?.finished)label(g,'완주',x,lane.y-23,'#fff8d1',14,'center');
    }
    stroke(g,194,top,194,bottom,'#fff6d9',4);stroke(g,1172,top,1172,bottom,'#fff6d9',4);
    label(g,'0 / 100m',194,top-18,'#557762',14,'center');label(g,'50m · 턴',1172,top-18,'#557762',14,'center');
  }
  private skeet(people:Athlete[],round:SportsRound,t:number){
    const g=this.g;
    for(const station of arenaStations(people.length)){
      const person=people[station.index],p=round.players.find(p=>p.id===person.id);
      box(g,station.x-42,station.y+5,84,13,'#b9aa87');stroke(g,station.x-42,station.y+5,station.x+42,station.y+5,'#e9dab5',2);
      for(let i=0;i<4;i++)stroke(g,station.x-30+i*20,station.y+7,station.x-30+i*20,station.y+15,'#938a6c');
      g.save();g.translate(station.x,station.y);g.scale(station.scale,station.scale);g.translate(-240,-229);
      drawSkeet(g,person,p??null,t,false,round.skeetTargets);g.restore();
      box(g,station.x-30,station.y+8,60,3,person.color);
      personName(g,person,station.index,station.x,station.y+35,'center');
      label(g,`${p?.hits??0} 명중`,station.x,station.y+57,'#5c7d59',14,'center');
    }
  }
  private lifting(people:Athlete[],round:SportsRound,t:number){
    const g=this.g;
    box(g,35,285,W-70,H-315,'#c7b48c');
    for(let y=300;y<H;y+=38)stroke(g,35,y,W-35,y,'#e6d5ac',2);
    for(const station of arenaStations(people.length)){
      const person=people[station.index],p=round.players.find(p=>p.id===person.id);
      drawPlatform(g,station.x-95,station.y,190,13);
      box(g,station.x-117,station.y-9,12,20,'#61786a');box(g,station.x+105,station.y-9,12,20,'#61786a');
      const pose=p?.phase==='hold'||p?.finished&&p.score>0?'overhead':'lift';
      drawPerson(g,person,p,station.x,station.y-4,t,pose,1.15);
      label(g,`${p?.weight??180}kg`,station.x,station.y-98,'#5f6552',18,'center');
      for(let i=0;i<3;i++)box(g,station.x+50+i*12,station.y-73,8,8,(p?.quality??0)>i?'#fff4bc':'#839274');
      personName(g,person,station.index,station.x,station.y+37,'center');
    }
  }
  private archery(people:Athlete[],round:SportsRound,t:number){
    const g=this.g;
    for(const lane of arenaLanes(people.length)){
      const person=people[lane.index],p=round.players.find(p=>p.id===person.id),floor=lane.y+22;
      box(g,20,lane.top,W-40,lane.height,laneColor(lane.index));
      stroke(g,175,lane.top+lane.height-2,1170,lane.top+lane.height-2,'#d6dfac',1);
      drawPlatform(g,183,floor+2,65,7);label(g,String(lane.index+1),168,lane.y+4,'#f4edc8',13,'center');
      personName(g,person,lane.index,32,lane.y+4);
      g.save();g.translate(215,floor);g.scale(.85,.85);const archer=drawArcher(g,person,p??null,t);g.restore();
      const y=lane.y-5;
      stroke(g,1125,y+15,1115,floor+7,'#7d7854',3);stroke(g,1125,y+15,1136,floor+7,'#7d7854',3);target(g,1125,y,Math.min(24,lane.height*.32));
      stroke(g,1010,lane.y-5,1022,lane.y-5,'#fff9d8');stroke(g,1016,lane.y-11,1016,lane.y+1,'#fff9d8');
      drawArrow(g,p??null,t,{x:215+archer.arrowStart.x*.85,y:floor+archer.arrowStart.y*.85},{x:1125,y},.85);
      label(g,`${p?.score??0}점`,1200,lane.y+5,'#486d4f',15,'right');
    }
  }
  private vault(people:Athlete[],round:SportsRound,t:number){
    const g=this.g;
    for(const lane of arenaLanes(people.length)){
      const person=people[lane.index],p=round.players.find(p=>p.id===person.id);
      personName(g,person,lane.index,28,lane.y+5);
      drawTrack(g,160,lane.y+3,995,34,1,false);label(g,String(lane.index+1),176,lane.y+25,'#fff0cd',15,'center');
      g.save();g.translate(160,lane.y+20);g.scale(2.15,.85);g.translate(0,-210);
      drawVault(g,person,p??null,t,false,true);g.restore();
    }
  }
  private track(people:Athlete[],round:SportsRound,t:number){
    const g=this.g,lanes=arenaLanes(people.length),sport=round.sport;
    const top=lanes[0].top,bottom=lanes.at(-1)!.top+lanes.at(-1)!.height;
    drawTrack(g,160,top,1048,bottom-top,lanes.length);
    stroke(g,220,top,220,bottom,'#fff2ca',3);
    for(const lane of lanes){
      const person=people[lane.index],p=round.players.find(p=>p.id===person.id),floor=lane.y+20;
      box(g,160,lane.top,1048,lane.height,laneColor(lane.index));personName(g,person,lane.index,28,lane.y+5);
      const x=220+clamp(p?.progress??0,0,140)/140*850;
      let pose=p?.phase==='ready'?'idle':'run',rotation=0;
      if(sport==='vault'){
        box(g,725,floor-23,53,11,'#ad7658');box(g,730,floor-12,5,14,'#616e55');box(g,768,floor-12,5,14,'#616e55');
        box(g,680,floor-1,29,4,'#f4cf81');box(g,920,floor+1,220,10,'#77afb0');
        if(p?.phase==='horse'){pose='pose';rotation=p.rotation;}
        if(p?.phase==='air'){pose='jump';rotation=p.rotation;}
      }else if(sport==='triple'){
        stroke(g,682,lane.top+5,682,lane.top+lane.height-5,'#fff4d7',3);
        drawSand(g,960,lane.top+6,225,lane.height-12);
        for(let meter=0;meter<4;meter++){stroke(g,970+meter*61,lane.top+lane.height-3,970+meter*61,lane.top+lane.height,'#fff1c5',2);}
        if(p?.phase==='flight')pose='jump';
      }else{
        drawMat(g,950,floor+1,230,12);stroke(g,970,floor-100,970,floor,'#f9e9c1',4);
        stroke(g,1090,floor-100,1090,floor,'#f9e9c1',4);stroke(g,965,floor-85,1095,floor-85,'#e9c275',3);
        for(let yy=floor-92;yy<floor;yy+=12){stroke(g,969,yy,975,yy,'#85977a',1);stroke(g,1089,yy,1095,yy,'#85977a',1);}box(g,702,floor-1,11,4,'#55725e');box(g,704,floor-1,6,2,'#e8d49f');
        if(p?.phase==='bend'){
          g.strokeStyle='#f6e3b8';g.lineWidth=4;g.beginPath();g.moveTo(706,floor);g.quadraticCurveTo(760,floor-35,x,floor-p.height*.7-30);g.stroke();
        }else if(p?.phase==='run'||p?.phase==='ready')stroke(g,x-12,floor-25,x+110,floor-65,'#f6e3b8',3);
        if(p?.phase==='air'||p?.phase==='bend'){pose='jump';rotation=p.rotation;}
      }
      if(sport==='triple')drawTripleAthlete(g,person,p??null,x,floor,t,.85);
      else drawPerson(g,person,p,x,floor-(p?.height??0)*.7,t,pose,.85,rotation);
      if(p?.finished)label(g,p.result,x,floor+16,'#4a5c47',12,'center');
    }
  }
  private hurdles(people:Athlete[],round:SportsRound,t:number){
    const g=this.g,lanes=arenaLanes(people.length),top=lanes[0].top,bottom=lanes.at(-1)!.top+lanes.at(-1)!.height;
    drawTrack(g,160,top,1048,bottom-top,lanes.length);
    stroke(g,220,top,220,bottom,'#fff2ca',3);
    for(const meter of [0,25,50,75,100])label(g,`${meter}m`,220+meter*9.4,top-16,'#5d795d',14,'center');
    const motions:string[]=[];
    for(const lane of lanes){
      const person=people[lane.index],p=round.players.find(p=>p.id===person.id);if(!p)continue;
      const floor=lane.y+23;
      box(g,160,lane.top,1048,lane.height,laneColor(lane.index));personName(g,person,lane.index,28,lane.y+5);
      for(const [i,position] of HURDLES.entries())drawHurdle(g,220+position*9.4,floor,.78,p.shots.includes(i));
      const pose=drawHurdleAthlete(g,person,p,220+Math.min(100,p.progress)*9.4,floor,t,.78);
      motions.push(pose.source);
    }
    this.canvas.dataset.hurdleMotions=motions.join(' ');
    for(let row=0;row<Math.ceil((bottom-top)/10);row++)for(let col=0;col<2;col++)box(g,1165+col*7,top+row*10,7,10,(row+col)%2?'#3d5c4e':'#fff3d3');
  }
}
