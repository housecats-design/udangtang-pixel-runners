import type {Control} from './model.ts';

export const SKEET_TARGET_COUNT=32;
export const SKEET_DURATION=29;
export const SKEET_GATES=[{x:155,y:125},{x:325,y:125}] as const;
export type SkeetTarget={id:number;side:0|1;hitAt:number;launchAt:number;exitAt:number;speed:number;rise:number;wave:number;rhythm:'quick'|'stagger'|'triple'|'reverse'};
export type SkeetShot={id:number;side:0|1;at:number;hit:boolean;bonus?:boolean};
export type SkeetAim={side:0|1;at:number;fromSide?:0|1};
const patterns:[(0|1)[],number[],SkeetTarget['rhythm']][]=[
  [[0,1],[.26],'quick'],[[1,0],[.24],'reverse'],[[0,1,0],[.22,.28],'triple'],
  [[1,0],[.68],'stagger'],[[1,1,0],[.26,.4],'triple'],[[0,1],[.62],'stagger'],
  [[0,1,1,0],[.21,.27,.22],'quick'],[[1,0],[.19],'quick'],[[0,0,1],[.24,.5],'triple'],
  [[1,0,1],[.44,.2],'triple'],[[0,1],[.36],'reverse'],[[1,0,0,1],[.22,.24,.2],'quick'],
];
export function createSkeetCourse(seed:number):SkeetTarget[]{
  let state=seed>>>0;
  const random=()=>{state=(state+0x6d2b79f5)|0;let x=Math.imul(state^state>>>15,1|state);x^=x+Math.imul(x^x>>>7,61|x);return ((x^x>>>14)>>>0)/4294967296;};
  const order=patterns.map((_,i)=>i);
  for(let i=order.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[order[i],order[j]]=[order[j],order[i]];}
  const targets:SkeetTarget[]=[];let at=1.05;
  for(const [wave,index] of order.entries()){
    const [sides,gaps,rhythm]=patterns[index],flip=random()<.5;
    for(const [i,rawSide] of sides.entries()){
      if(i)at+=Math.max(.18,gaps[i-1]+(random()-.5)*.035);
      const side=(flip?1-rawSide:rawSide) as 0|1;
      const speed=(rhythm==='quick'?215:180)+random()*28;
      targets.push({id:targets.length,side,hitAt:at,launchAt:at-175/speed,exitAt:at+175/speed,speed,rise:-32+random()*38,wave,rhythm});
    }
    at+=1.15+random()*.25;
  }
  return targets;
}
// A fixed preview is shared by every renderer; live rounds carry their own course.
export const SKEET_PREVIEW=createSkeetCourse(73019);
export function skeetSide(button:Control):0|1{return button==='A'?0:1;}
export function skeetMotionIndex(time:number,side:0|1,shot:SkeetShot|undefined){
  const age=shot?time-shot.at:Infinity;
  return shot?.side===side&&age>=0&&age<.6?Math.min(15,4+Math.floor(age/.6*12)):0;
}
export function skeetTarget(time:number,target:SkeetTarget){
  const dt=time-target.hitAt,gate=SKEET_GATES[target.side];
  return {x:gate.x+(target.side===0?1:-1)*target.speed*dt,y:gate.y+target.rise*dt+80*dt*dt};
}
export function skeetHit(time:number,side:0|1,course:SkeetTarget[]=SKEET_PREVIEW){
  return course.some(target=>target.side===side&&Math.abs(time-target.hitAt)<=24/target.speed);
}
export function skeetShotTarget(time:number,side:0|1,course:SkeetTarget[],spent:number[]){
  return course.filter(target=>target.side===side&&time>=target.launchAt&&time<=target.exitAt&&!spent.includes(target.id))
    .sort((a,b)=>Math.abs(time-a.hitAt)-Math.abs(time-b.hitAt))[0];
}
export function skeetBonusAt(course:SkeetTarget[]){return Math.max(...course.map(target=>target.exitAt))+.25;}
export function skeetRhythm(time:number,course:SkeetTarget[]){
  const next=course.find(target=>target.exitAt>=time&&target.hitAt>=time-.12);
  if(!next||time<next.launchAt-.1)return '';
  return {quick:'빠른 연사',stagger:'시간차 발사',triple:'연속 표적',reverse:'순서를 읽어요'}[next.rhythm];
}
export function skeetReaction(time:number,shot:SkeetShot|undefined){
  const age=shot?time-shot.at:Infinity;
  return {age,recoil:age>=0&&age<.32?Math.sin(Math.min(1,age/.08)*Math.PI/2)*Math.exp(-age*13):0,
    flash:age>=0&&age<.12,impact:age>=0&&age<.8};
}
