import {avatars} from '../data/avatars.ts';
import {sprite} from '../rendering/renderer.ts';
import {type Athlete, type Competitor, type SportsRound, type SportId} from './model.ts';
import {SKEET_DURATION,SKEET_GATES,SKEET_PREVIEW,skeetTarget,skeetReaction,skeetHit,skeetPose,skeetBonusAt,skeetRhythm,type SkeetTarget,type SkeetShot,type SkeetAim} from './skeet.ts';
import {skeetFrame,skeetMuzzle} from './skeet-motion.ts';
import {drawSwimmingFrame,swimmingFrame,SWIMMING_WIDTH_SCALE} from './swimming-motion.ts';
import {HURDLES,hurdleHeight,hurdleJumpCue} from './hurdles.ts';
import {drawHurdle,drawHurdleAthlete} from './hurdles-render.ts';
import {drawArcher,drawArrow} from './archery-render.ts';
import {archeryDemo,ARCHERY_LOAD_SECONDS} from './archery.ts';
import {drawTripleAthlete} from './triple-render.ts';
import {drawSportsHud} from './sports-hud.ts';
import {drawVault} from './vault-render.ts';
import {drawStadium,drawTrack,drawPool,drawPoolDeck,drawPoolRope,drawSwimWake,drawSkeetGate,drawSand,drawMat,drawPlatform} from './scenery.ts';
const TAU=Math.PI*2;
function rect(g:CanvasRenderingContext2D,x:number,y:number,w:number,h:number,color:string) {
  g.fillStyle=color;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));
}
function line(g:CanvasRenderingContext2D,x:number,y:number,ex:number,ey:number,color:string,width=3) {
  g.strokeStyle=color;g.lineWidth=width;g.lineCap='square';g.beginPath();g.moveTo(x,y);g.lineTo(ex,ey);g.stroke();
}
function ellipse(g:CanvasRenderingContext2D,x:number,y:number,rx:number,ry:number,color:string) {
  g.fillStyle=color;g.beginPath();g.ellipse(x,y,rx,ry,0,0,TAU);g.fill();
}
export function stadium(g:CanvasRenderingContext2D,w:number,h:number,time:number,night=false) {
  drawStadium(g,w,h,time,night);
}
export function athlete(g:CanvasRenderingContext2D,person:Athlete,x:number,y:number,time:number,pose:string,rotation=0) {
  const palette=avatars[person.avatar%avatars.length];
  g.save();g.translate(x,y);g.rotate(rotation);
  if(pose==='run'||pose==='idle'||pose==='cheer'||pose==='cry') {
    const image=sprite({id:person.id,name:person.name,avatarId:palette.id,paletteId:person.color},Math.floor(time*14)%8,pose);
    g.drawImage(image,-32,-57,64,64);
  } else {
    const skin=palette.skin,edge='#344a47';
    const move=Math.sin(time*14)*7;
    ellipse(g,0,3,15,3,'#224b4525');
    if(pose==='swim') {
      g.scale(SWIMMING_WIDTH_SCALE,1);
      line(g,-12,-7,13,-7,person.color,9);
      line(g,-10,-7,-25,-8+move,skin,5);line(g,9,-7,22,-13-move,skin,5);
      line(g,-15,-5,-27,1+move*.4,palette.pants,5);
      rect(g,13,-19,12,12,skin);rect(g,12,-21,13,5,person.color);rect(g,22,-17,5,3,edge);
    } else {
      const crouch=pose==='lift'?9:0;
      line(g,-4,-17+crouch,-9,0,edge,7);line(g,6,-17+crouch,12,0,edge,7);
      rect(g,-13,-1,10,4,'#fff6df');rect(g,7,-1,12,4,'#fff6df');
      rect(g,-10,-36+crouch,20,21,edge);rect(g,-8,-35+crouch,16,16,person.color);
      rect(g,-10,-53+crouch,22,18,skin);rect(g,-12,-55+crouch,25,6,palette.hair);rect(g,7,-46+crouch,3,4,edge);
      if(pose==='shoot'||pose==='bow') {
        line(g,-7,-30,21,-29,skin,5);line(g,7,-28,19,-34,skin,5);
        if(pose==='shoot') {line(g,8,-34,39,-43,edge,4);rect(g,8,-34,9,8,'#b88159');}
        else {g.strokeStyle='#b77f49';g.lineWidth=3;g.beginPath();g.arc(23,-30,23,-1.4,1.4);g.stroke();line(g,27,-52,27,-8,'#fff5d8',1);line(g,10,-30,45,-30,'#5b6850',2);}
      } else if(pose==='lift'||pose==='overhead') {
        const armY=pose==='lift'?-10:-64;
        line(g,-9,-31+crouch,-20,armY,skin,5);line(g,9,-31+crouch,20,armY,skin,5);
        line(g,-36,armY,36,armY,'#d1ddcf',4);
        for(const side of [-1,1]) {rect(g,side*27-5,armY-14,9,28,'#344d53');rect(g,side*34-3,armY-10,5,20,person.color);}
      } else {line(g,-9,-28,-15,-15,skin,5);line(g,9,-28,20,-19,skin,5);}
    }
  }
  g.restore();
}
export function target(g:CanvasRenderingContext2D,x:number,y:number,r=22) {
  ellipse(g,x+2,y+3,r+3,r+3,'#34594a35');ellipse(g,x,y,r+2,r+2,'#526b5a');
  for(const [i,color] of ['#f7f2dc','#293f4c','#63b2cf','#ed8274','#f4cc71'].entries())ellipse(g,x,y,r*(1-i*.18),r*(1-i*.18),color);
  line(g,x-2,y,x+2,y,'#ad794b',1);line(g,x,y-2,x,y+2,'#ad794b',1);
}
function clay(g:CanvasRenderingContext2D,x:number,y:number,time:number,id:number,direction:number){
  const colors=[['#ed9f52','#ffdd91'],['#cf7563','#ffbd91'],['#c29f64','#f5e0a0']][id%3];
  for(let i=1;i<=3;i++)line(g,x-direction*(12+i*5),y+i*.5,x-direction*(14+i*5),y+i*.5,'#fff2cd66',1);
  g.save();g.translate(x,y);g.rotate(Math.sin(time*15+id)*.22);
  ellipse(g,0,3,10,4,'#635342');ellipse(g,0,0,10,4.5,colors[0]);ellipse(g,0,-1.4,7,2.5,colors[1]);
  line(g,-7,1,7,1,'#9f684a',1);line(g,-5,-2,4,-2,'#fff0ba',1);g.restore();
}
function skeetShooter(g:CanvasRenderingContext2D,person:Athlete,time:number,shots:SkeetShot[],aim?:SkeetAim){
  const last=shots.at(-1),previous=shots.at(-2);
  const side=aim?.side??last?.side??1,facing=side===0?-1:1;
  const currentAim=aim??(last?{side,at:last.at,fromSide:previous?.side??1}:undefined);
  const pose=skeetPose(time,side,last,currentAim),motion=skeetFrame(person,pose);
  const visualShot=last&&pose.shotAt!==null?{...last,at:pose.shotAt}:undefined;
  const {recoil,flash}=skeetReaction(time,motion?visualShot:last?.side===side?last:undefined);
  const age=time-(aim?.at??last?.at??-100);
  const turn=Math.min(1,Math.max(0,age/.24)),ease=turn*turn*(3-2*turn);
  const fromSide=aim?aim.fromSide:previous?.side;
  const from=fromSide===undefined?0:fromSide===0?-14:14;
  const offset=last||aim?from+((side===0?-14:14)-from)*ease:Math.sin(time*1.6)*2;
  const x=240+offset,y=229;
  const a=avatars[person.avatar%avatars.length],edge='#344a47';
  const muzzle=motion?skeetMuzzle(pose):{x:facing*63,y:-68},muzzleX=muzzle.x,muzzleY=muzzle.y;
  ellipse(g,x,232,23,4,'#28494030');
  g.save();g.translate(x,y);
  if(motion){
    g.save();g.scale(pose.mirror?-1:1,1);g.drawImage(motion,-48,-90,96,96);g.restore();
  }else{
  g.save();g.translate(-facing*recoil*5,0);g.scale(facing,1);
  g.rotate(-recoil*.06);
  // Bent knees, planted feet and two separate arms keep the gun attached to the hands.
  line(g,-5,-16,-12,-8,edge,8);line(g,-12,-8,-17,0,edge,7);
  line(g,6,-16,13,-7,edge,8);line(g,13,-7,18,0,edge,7);
  line(g,-5,-16,-12,-8,a.pants,5);line(g,6,-16,13,-7,a.pants,5);
  rect(g,-22,-1,12,4,'#fff7df');rect(g,13,-1,12,4,'#fff7df');
  rect(g,-11,-32,23,19,edge);rect(g,-8,-31,17,16,person.color);
  rect(g,-7,-29,5,8,'#d7f0de');
  const identity=sprite({id:person.id,name:person.name,avatarId:a.id,paletteId:person.color},0,'idle');
  g.drawImage(identity,0,0,64,35,-32,-59,64,35);
  line(g,-7,-26,9,-15,edge,8);line(g,9,-15,25,-31,edge,7);
  line(g,-7,-26,9,-15,a.skin,5);line(g,9,-15,25,-31,a.skin,4);
  line(g,8,-26,25,-14,edge,8);line(g,25,-14,36,-39,edge,7);
  line(g,8,-26,25,-14,a.skin,5);line(g,25,-14,36,-39,a.skin,4);
  line(g,13,-24,60,-65,edge,6);line(g,14,-25,34,-42,'#b7865e',6);
  line(g,33,-42,61,-66,'#b9c7b8',3);
  g.restore();
  }
  if(flash){
    g.fillStyle='#fff0ad';g.strokeStyle='#e9a657';g.lineWidth=2;g.beginPath();
    for(let i=0;i<12;i++){const r=i%2?5:14,angle=i/12*TAU;const px=muzzleX+Math.cos(angle)*r,py=muzzleY+Math.sin(angle)*r;i?g.lineTo(px,py):g.moveTo(px,py);}g.closePath();g.fill();g.stroke();
  }
  g.restore();
  return {x,y,facing,muzzleX:x+muzzleX,muzzleY:y+muzzleY,shot:last,visualShot,pose,generated:!!motion};
}
export function drawSkeet(g:CanvasRenderingContext2D,person:Athlete,p:Competitor|null,t:number,ground=true,course:SkeetTarget[]=SKEET_PREVIEW){
  if(ground){rect(g,0,163,480,87,'#a1ba82');rect(g,201,231,78,12,'#c6b694');line(g,201,231,279,231,'#e8d6ac',2);for(let i=0;i<4;i++)line(g,210+i*18,233,210+i*18,242,'#a89676',1);}
  const clock=p?t:t%SKEET_DURATION;
  const demo:SkeetShot[]=p?[]:course.filter(target=>target.hitAt<=clock).map(target=>({id:target.id,side:target.side,at:target.hitAt,hit:true}));
  const shots=p?.shotEffects??demo;
  const shooter=skeetShooter(g,person,clock,shots,p?.skeetAim);
  for(const side of [0,1] as const){
    const gate=SKEET_GATES[side],last=[...shots].reverse().find(shot=>shot.side===side);
    const reaction=skeetReaction(clock,last),active=reaction.impact;
    drawSkeetGate(g,gate.x,gate.y,side,active,!!last?.hit);
    if(active){g.fillStyle=last!.hit?'#315843':'#9b5c4e';g.font='900 14px sans-serif';g.fillText(last!.hit?'명중!':'빗나감',gate.x,gate.y+40-reaction.age*7);}
  }
  for(const disc of course){
    if(clock<disc.launchAt||clock>disc.exitAt||shots.some(shot=>shot.id===disc.id&&shot.hit))continue;
    const point=skeetTarget(clock,disc);clay(g,point.x,point.y,clock-disc.launchAt,disc.id,disc.side===0?1:-1);
  }
  for(const shot of shots){
    const shown=shooter.generated&&shot===shooter.shot?shooter.visualShot:shot;
    const {age,impact}=skeetReaction(clock,shown);if(!impact)continue;
    const disc=course.find(target=>target.id===shot.id);
    const point=shot.bonus?{x:240+Math.sin(shot.at*3)*145,y:65}:disc?skeetTarget(shot.at,disc):SKEET_GATES[shot.side];
    if(age<.1){line(g,shooter.muzzleX,shooter.muzzleY,point.x,point.y,shot.hit?'#fff1b4':'#f8e8c080',1);}
    if(shot.hit){
      g.save();g.globalAlpha=1-age/.8;
      for(let i=0;i<9;i++){
        const angle=i/9*TAU+shot.side,speed=24+(i%3)*30;
        const x=point.x+Math.cos(angle)*speed*age,y=point.y+Math.sin(angle)*speed*age+70*age*age;
        g.save();g.translate(x,y);g.rotate(angle+age*5);rect(g,-3,-2,6,4,i%2?'#ffda84':'#cb8054');g.restore();
      }
      if(age<.25){g.strokeStyle='#fff1bd';g.lineWidth=2;g.beginPath();g.arc(point.x,point.y,5+age*65,0,TAU);g.stroke();}
      g.restore();
    }
  }
  if(clock>=skeetBonusAt(course)&&p?.hits===course.length)target(g,240+Math.sin(clock*3)*145,65,13);
  const rhythm=skeetRhythm(clock,course);if(rhythm){g.fillStyle='#466a50';g.font='bold 11px sans-serif';g.textAlign='center';g.fillText(rhythm,240,246);}
  return {...shooter,clock,course};
}
export class SportCanvas {
  private g:CanvasRenderingContext2D;
  constructor(readonly canvas:HTMLCanvasElement) {
    canvas.width=480;canvas.height=250;
    this.g=canvas.getContext('2d')!;this.g.imageSmoothingEnabled=false;
  }
  draw(person:Athlete,player:Competitor|null,round:SportsRound|null,time:number,previewSport:SportId='swimming') {
    const g=this.g,w=480,h=250;
    const sport=round?.sport??previewSport;
    stadium(g,w,h,time);
    const t=round?.time??time;
    const p=player;
    const x=70+(p?.progress??(time*4)%100)/140*310;
    const floor=210;
    switch(sport) {
      case 'hurdles': {
        const previewCycle=time%2.2;
        const progress=p?.progress??8+previewCycle*6;
        const camera=Math.max(0,Math.min(1440,progress*18-110));
        const ground=222,runnerX=60+progress*18-camera;
        drawTrack(g,0,190,w,60,1,false);rect(g,0,239,w,3,'#f3d8b0');
        for(let meter=0;meter<=100;meter+=10){
          const mark=60+meter*18-camera;rect(g,mark,244,2,6,'#f1c8a0');
          g.font='bold 10px monospace';g.fillStyle='#8b6952';g.textAlign='center';g.fillText(String(meter),mark,185);
        }
        for(const [i,position] of HURDLES.entries()){
          const x=60+position*18-camera;if(x>-40&&x<w+40)drawHurdle(g,x,ground,1,p?.shots.includes(i));
        }
        const finish=1860-camera;
        for(let row=0;row<5;row++)for(let col=0;col<2;col++)rect(g,finish+col*5,199+row*9,5,9,(row+col)%2?'#3c5a4b':'#fff6db');
        const jumpAge=previewCycle-.45;
        const preview=p??{phase:jumpAge>=0&&jumpAge<.72?'jump':'run',phaseAt:time-jumpAge,height:jumpAge>=0&&jumpAge<.72?hurdleHeight(jumpAge):0,speed:8,finished:false,rotation:0} as Competitor;
        const pose=drawHurdleAthlete(g,person,preview,runnerX,ground,p?t:time);
        this.canvas.dataset.motion=pose.source;
        this.canvas.dataset.motionFrame=String(pose.frame);
        const next=HURDLES[p?.stage??0],distance=next===undefined?null:next-progress;
        const cue=!!p&&p.phase==='run'&&distance!==null&&hurdleJumpCue(distance,p.speed);
        this.canvas.dataset.jumpCue=String(cue);
        this.canvas.dataset.nextHurdle=distance===null?'finish':distance.toFixed(2);
        this.canvas.dataset.height=String(p?.height??0);
        this.canvas.dataset.hurdlesCleared=String(p?.hits??0);
        if(cue){
          g.fillStyle='#fff0b8';g.font='900 15px sans-serif';g.textAlign='center';g.fillText('B · 점프!',runnerX,151);
        }
        break;
      }
      case 'swimming': {
        drawPoolDeck(g,0,157,w,93);drawPool(g,0,157,w,93,4,t);
        for(let row=0;row<4;row++) {
          const y=164+row*23;
          drawPoolRope(g,0,y,w,row,t,16);
        }
        rect(g,34,158,4,92,'#f5f3da');rect(g,442,158,5,92,'#f5f3da');
        const travel=p?.progress??(time*9)%100;
        const swimX=84+(travel<=50?travel:100-travel)/50*312;
        g.save();g.translate(swimX,202);if(travel>50)g.scale(-1,1);
        const gasping=p?.phase==='gasping';
        const swim=swimmingFrame(person,gasping?.9:time);
        if(gasping){g.translate(0,Math.sin(time*4)*1.5);g.rotate(-.2);}
        const breathing=p?Math.max(0,1-(t-p.breathAt)/.65):0;
        if(breathing>0)g.rotate(-Math.sin(breathing*Math.PI)*.09);
        if(swim)drawSwimmingFrame(g,swim,-36);else athlete(g,person,0,0,t,'swim');
        g.restore();
        if(!gasping&&!p?.finished)drawSwimWake(g,swimX,202,time,travel>50?-1:1,.8);
        this.canvas.dataset.phase=p?.phase??'preview';
        this.canvas.dataset.motion=swim?'higgsfield-swimming':'fallback';
        const direction=travel>50?-1:1;
        if(!gasping&&!p?.finished)for(let i=0;i<6;i++){
          const phase=(time*3+i/6)%1;
          ellipse(g,swimX-direction*(16+i*7),202+Math.sin(time*11+i)*3,5+phase*3,1.5,'#e1f1e5');
          if(i%2===0)rect(g,swimX-direction*16+Math.sin(time*12+i)*20,191-Math.sin(phase*Math.PI)*10,2,3,'#c6e9e6');
        }
        if(breathing>0){g.fillStyle='#fff5d0';g.font='bold 11px sans-serif';g.textAlign='center';g.fillText('후우!',swimX+direction*28,163);}
        if(p&&p.oxygen<=.32&&!p.finished) {g.fillStyle='#ed706b';g.font='900 19px sans-serif';g.textAlign='center';g.fillText(gasping?'멈춤 · B로 숨 쉬기!':'BREATH!',swimX,174);}
        break;
      }
      case 'skeet': {
        const shooter=drawSkeet(g,person,p,t,true,round?.skeetTargets);
        this.canvas.dataset.motion=shooter.generated?'pixellab-skeet-sd':'sports-motion';
        this.canvas.dataset.motionClip=shooter.pose.turning?'turn':shooter.pose.frame?'shot':'aim';
        this.canvas.dataset.motionFrame=String(shooter.pose.frame);
        this.canvas.dataset.hitWindow=([0,1] as const).filter(side=>skeetHit(shooter.clock,side,shooter.course)).map(side=>side===0?'left':'right').join(' ');
        this.canvas.dataset.direction=shooter.facing===-1?'left':'right';
        const reaction=skeetReaction(shooter.clock,shooter.shot);
        this.canvas.dataset.shot=reaction.impact?(shooter.shot!.hit?'hit':'miss'):'ready';
        break;
      }
      case 'archery': {
        rect(g,45,floor+1,90,8,'#c5b18a');line(g,47,floor+1,134,floor+1,'#f8e2b5',2);
        g.save();g.translate(85,floor);const archer=drawArcher(g,person,p,t);g.restore();
        const cy=125;
        line(g,379,cy+24,365,230,'#7b7454',4);line(g,379,cy+24,391,230,'#7b7454',4);target(g,379,cy,34);
        drawArrow(g,p??archeryDemo(t),t,{x:85+archer.arrowStart.x,y:floor+archer.arrowStart.y},{x:379,y:cy});
        g.fillStyle='#fff7df';g.font='bold 16px sans-serif';g.textAlign='left';const wind=p&&p.phase!=='ready'?p.quality:round?.wind??2;g.fillText(`WIND ${wind} ${wind<0?'←':'→'}`,265,31);
        if(p?.aimAt!==null&&p?.aimAt!==undefined&&t-p.aimAt>=ARCHERY_LOAD_SECONDS){g.fillStyle='#355d4b';g.font='900 18px sans-serif';g.fillText(`각도 ${p.angle.toFixed(1)} · 중앙 5.0–5.5`,180,195);}
        this.canvas.dataset.motion=archer.generated?'pixellab-archery-sd':'sports-motion';
        this.canvas.dataset.motionFrame=String(archer.pose.frame);
        this.canvas.dataset.motionClip=archer.pose.clip;
        this.canvas.dataset.phase=p?.aimAt!==null&&p?.aimAt!==undefined?(t-p.aimAt<ARCHERY_LOAD_SECONDS?'loading':'aiming'):p?.arrow&&t-p.arrow.at<.8?'arrow-flight':'ready';
        break;
      }
      case 'vault':
        drawVault(g,person,p,t);this.canvas.dataset.phase=p?.phase??'preview';
        break;
      case 'triple':
        drawTrack(g,0,188,w,57,1,false);rect(g,247,188,5,55,'#fff3d2');drawSand(g,328,188,145,55);
        for(let i=0;i<4;i++){rect(g,348+i*31,245,2,5,'#faf0ca');g.fillStyle='#7f7052';g.font='bold 8px sans-serif';g.fillText(String(16+i),348+i*31,183);}
        drawTripleAthlete(g,person,p,x,floor,t);
        this.canvas.dataset.phase=p?.phase??'preview';
        if(p?.finished){g.fillStyle='#345b4a';g.font='bold 15px sans-serif';g.textAlign='center';g.fillText(p.result,240,246);}
        break;
      case 'weightlifting':
        drawPlatform(g,90,215,300,15);
        rect(g,34,211,16,19,'#647c70');rect(g,430,211,16,19,'#647c70');rect(g,32,210,20,3,'#c5a77b');rect(g,428,210,20,3,'#c5a77b');
        athlete(g,person,240,floor,t,p?.phase==='hold'||p?.finished&&p.score>0?'overhead':'lift');
        for(let i=0;i<3;i++)ellipse(g,333+i*25,141,7,7,(p?.quality??0)>i?'#d6ed8d':'#6e8379');
        break;
      case 'pole':
        drawTrack(g,0,188,330,57,1,false);drawMat(g,335,209,130,25);rect(g,344,94,5,120,'#f7ebca');rect(g,407,94,5,120,'#f7ebca');
        for(let y=105;y<209;y+=13){line(g,344,y,350,y,'#8b9a7a',1);line(g,407,y,413,y,'#8b9a7a',1);}rect(g,306,208,9,5,'#566b5c');rect(g,307,208,5,2,'#e4cf99');
        rect(g,340,105,77,3,'#e5b056');
        if(p?.phase==='bend')line(g,309,floor,x+4,floor-p.height-10,'#f1e0b6',3);
        else if(p?.phase==='run'||!p)line(g,x-15,floor-25,x+80,floor-75,'#f1e0b6',3);
        athlete(g,person,x,floor-(p?.height??0),t,p?.phase==='air'||p?.phase==='bend'?'idle':'run',p?.rotation??0);
        break;
    }
    if(sport!=='vault')drawSportsHud(g,p,sport,12,12);
    if(p?.finished&&sport!=='vault'&&sport!=='triple') {
      g.fillStyle='#193f3bbb';g.fillRect(0,0,w,h);
      athlete(g,person,240,173,t,p.score>0?'cheer':'idle');
      g.fillStyle='#f4e9cc';g.textAlign='center';g.font='900 24px sans-serif';g.fillText(p.result,240,204);
      g.fillStyle=person.color;g.font='bold 17px monospace';g.fillText(`+${p.score.toLocaleString()} POINTS`,240,230);
    } else if(p&&t-p.feedbackAt<1.2) {
      g.font='900 20px sans-serif';g.textAlign='center';g.fillStyle='#183e3bcc';g.fillRect(65,64,350,34);
      g.fillStyle='#fff0b8';g.fillText(p.feedback,240,88);
    }
  }
}
