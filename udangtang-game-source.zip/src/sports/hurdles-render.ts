import {avatars} from '../data/avatars.ts';
import {sprite} from '../rendering/renderer.ts';
import {motionFrame,sequenceFrame} from '../rendering/generated-motions.ts';
import {HURDLE_JUMP_SECONDS} from './hurdles.ts';
import type {Athlete,Competitor} from './model.ts';

export function drawHurdle(g:CanvasRenderingContext2D,x:number,floor:number,scale=1,fallen=false){
  g.save();g.translate(x,floor);g.scale(scale,scale);
  if(fallen)g.rotate(1.35);
  g.fillStyle='#8a7453';g.fillRect(-11,-2,24,3);g.fillRect(-2,-27,4,27);
  g.fillStyle='#f7edd5';g.fillRect(-14,-29,30,6);
  g.fillStyle='#dd8e78';for(let i=0;i<3;i++)g.fillRect(-13+i*10,-29,5,6);
  g.restore();
}
export function drawHurdleAthlete(g:CanvasRenderingContext2D,person:Athlete,p:Competitor,x:number,floor:number,time:number,scale=1){
  const a=avatars[person.avatar%avatars.length],identity={id:person.id,name:person.name,avatarId:a.id,paletteId:person.color};
  const age=time-p.phaseAt;
  g.save();g.translate(x,floor);
  g.fillStyle='#294e4128';g.beginPath();g.ellipse(0,3,14*scale,3*scale,0,0,Math.PI*2);g.fill();
  g.scale(scale,scale);g.translate(0,-p.height);
  if(p.phase==='fall'||p.phase==='recover'){
    g.translate(0,-19);g.rotate(p.rotation);g.drawImage(sprite(identity,0,'idle'),-32,-36,64,64);
    g.restore();
    for(let i=0;i<4;i++){
      const t=Math.max(0,age)+i*.08;g.fillStyle=i%2?'#f7dda1':'#edc090';
      g.fillRect(x-12-i*6,floor-3-Math.sin(t*7)*4,4,3);
    }
    return {source:'runner',frame:0};
  }
  if(p.finished||p.phase!=='jump'){
    const pose=p.finished?'cheer':p.phase==='ready'||p.speed<.15?'idle':'run';
    g.drawImage(sprite(identity,Math.floor(time*(8+p.speed))%8,pose),-32,-56,64,64);
  }else{
    const index=sequenceFrame(age,HURDLE_JUMP_SECONDS,12);
    const jump=motionFrame(identity,'jump',index);
    g.drawImage(jump?.canvas??sprite(identity,3,'jump'),-32,-56,64,64);
    g.restore();
    return {source:jump?'higgsfield-jump':'fallback-jump',frame:index};
  }
  g.restore();
  return {source:'runner',frame:Math.floor(time*(8+p.speed))%8};
}
