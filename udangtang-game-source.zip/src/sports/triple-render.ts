import {avatars} from '../data/avatars.ts';
import {sprite} from '../rendering/renderer.ts';
import {motionFrame,sequenceFrame} from '../rendering/generated-motions.ts';
import type {Athlete,Competitor} from './model.ts';
export function drawTripleAthlete(g:CanvasRenderingContext2D,person:Athlete,p:Competitor|null,x:number,floor:number,t:number,scale=1){
  const a=avatars[person.avatar%avatars.length],identity={id:person.id,name:person.name,avatarId:a.id,paletteId:person.color},phase=p?.phase??'run',age=t-(p?.phaseAt??0);
  const landing=phase==='landing'||p?.finished&&p.stage===3;
  g.save();g.translate(x,floor);g.scale(scale,scale);g.translate(0,-(p?.height??0));
  if(landing){
    // Seat-first sand-pit landing differs from the knee-led jump in flight.
    const u=Math.min(1,age/.8);g.translate(u*12,4+u*5);g.rotate(-.32-u*.18);
    const image=motionFrame(identity,'jump',8)?.canvas??sprite(identity,3,'jump');
    g.drawImage(image,-32,-50,64,64);
    g.fillStyle=a.pants;g.fillRect(4,-13,15,6);g.fillStyle='#fff2da';g.fillRect(17,-12,10,5);
  }else if(phase==='flight'){
    const progress=Math.min(1,age/1.1),index=sequenceFrame(age,1.1,12);
    const jump=motionFrame(identity,'jump',index);
    // Hop/step retain one bent leg; the last jump extends both legs towards the pit.
    g.rotate((p?.stage===0?-.1:p?.stage===1?.08:-.18)*Math.sin(progress*Math.PI));
    g.drawImage(jump?.canvas??sprite(identity,3,'jump'),-32,-56,64,64);
    if(p?.stage===2&&progress>.65){g.fillStyle=a.pants;g.fillRect(0,-15,17,6);g.fillStyle='#fff2db';g.fillRect(15,-15,9,5);}
  }else{
    if(phase==='angle'||phase==='step')g.scale(1,.9);
    g.drawImage(sprite(identity,Math.floor(t*(8+(p?.speed??0)))%8,phase==='ready'||phase==='angle'||phase==='step'?'idle':'run'),-32,-56);
  }
  g.restore();
  if(landing&&age<1.2){
    for(let i=0;i<24;i++){
      const v=28+(i%6)*10,dir=i%2?1:-1,u=Math.max(0,age);
      const dx=dir*v*u,dy=-Math.sin(i*2.3)*v*u+70*u*u-6;
      if(dy>12)continue;
      g.globalAlpha=Math.max(0,1-u/1.2);g.fillStyle=['#f5df9e','#cfab6d','#fff0c3'][i%3];g.fillRect(x+dx*scale,floor+dy*scale,(2+i%3)*scale,(2+i%2)*scale);
    }g.globalAlpha=1;
    g.strokeStyle='#b99a68';g.lineWidth=3*scale;g.beginPath();g.moveTo(x-13*scale,floor+7*scale);g.lineTo(x+Math.min(1,age/.8)*33*scale,floor+7*scale);g.stroke();
  }
}
