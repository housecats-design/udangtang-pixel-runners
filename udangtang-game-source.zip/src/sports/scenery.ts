// Canvas-only scenery shared by the personal view and the eight-player arena.
const TAU=Math.PI*2;
const box=(g:CanvasRenderingContext2D,x:number,y:number,w:number,h:number,color:string)=>{g.fillStyle=color;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
const stroke=(g:CanvasRenderingContext2D,x:number,y:number,ex:number,ey:number,color:string,width=1)=>{g.strokeStyle=color;g.lineWidth=width;g.beginPath();g.moveTo(x,y);g.lineTo(ex,ey);g.stroke();};
const oval=(g:CanvasRenderingContext2D,x:number,y:number,rx:number,ry:number,color:string)=>{g.fillStyle=color;g.beginPath();g.ellipse(x,y,rx,ry,0,0,TAU);g.fill();};
function tile(w:number,h:number,paint:(g:CanvasRenderingContext2D)=>void){const c=document.createElement('canvas');c.width=Math.ceil(w);c.height=Math.ceil(h);const g=c.getContext('2d')!;g.imageSmoothingEnabled=false;paint(g);return c;}
const stands=new Map<string,HTMLCanvasElement>();
export function drawStadium(g:CanvasRenderingContext2D,w:number,h:number,time:number,night=false){
 const key=`${w}:${h}:${night}`;let base=stands.get(key);
 if(!base){base=tile(w,h,b=>{
  const sky=b.createLinearGradient(0,0,0,h*.7);sky.addColorStop(0,night?'#173f49':'#86cdd3');sky.addColorStop(1,night?'#528b80':'#e2f0da');b.fillStyle=sky;b.fillRect(0,0,w,h);
  oval(b,w*.81,h*.13,18,18,night?'#f8d896':'#fff3bb');
  const top=h*.37;
  box(b,0,top-9,w,63,'#b7bca0');
  for(let row=0;row<4;row++){
   const y=top+row*12;box(b,0,y+7,w,5,row%2?'#819e89':'#9cb49a');stroke(b,0,y+11,w,y+11,'#5b8278');
   for(let col=0;col<w/14;col++){
    const x=col*14+row%2*5;if(Math.floor(x)%210<12)continue;
    const shirts=['#ebad70','#d77f7b','#4b857d','#f1dfad','#6c9eae','#a89ab3'],skin=['#f1c68f','#d79e73','#b9805f'][(col+row*2)%3];
    box(b,x+1,y+1,6,4,'#46554c');box(b,x+2,y+3,5,5,skin);box(b,x,y+8,9,4,shirts[(col*7+row*3)%6]);box(b,x+5,y+4,1,1,'#4b5548');
   }
  }
  for(let x=0;x<w;x+=210){box(b,x,top,10,49,'#d9d6b8');for(let y=top+7;y<top+49;y+=9)stroke(b,x,y,x+10,y,'#a6ad96');}
  box(b,0,top-12,w,6,'#355f59');box(b,0,top-12,w,2,'#fbefd1');
  box(b,0,top+49,w,12,'#355d56');stroke(b,0,top+50,w,top+50,'#e7e5bc',2);stroke(b,0,top+60,w,top+60,'#244e48');
  for(let x=8;x<w;x+=35)box(b,x,top+50,2,10,'#7d9a80');
  box(b,0,h*.63,w,h*.37,'#9bb879');box(b,0,h*.63,w,5,'#d4dfa8');
  for(let x=8;x<w;x+=29){const y=h*.69+(x*7%17);stroke(b,x,y,x+3,y-4,'#87a66d');stroke(b,x+3,y,x+6,y-3,'#87a66d');}
  box(b,0,h*.76,w,h*.24,'#d28e70');for(let row=0;row<3;row++)stroke(b,0,h*.79+row*17,w,h*.79+row*17,'#f4d7af',2);
 });stands.set(key,base);}
 g.drawImage(base,0,0);
 for(let i=0;i<5;i++){const x=((i*(w/4.2)+time*3)%(w+100))-50,y=18+i%3*14;box(g,x,y,55,9,'#f2faf0');box(g,x+12,y-6,27,7,'#f2faf0');}
 const top=h*.37;
 for(let i=0;i<8;i++){
  const x=i*w/7+15;box(g,x,top-34,2,23,'#527970');g.fillStyle=['#efb774','#df8b83','#80b8c1'][i%3];g.beginPath();g.moveTo(x+2,top-34);g.lineTo(x+18,top-28+Math.sin(time*2+i)*2);g.lineTo(x+2,top-21);g.fill();
 }
 // Sparse waving hands make the crowd lively without obscuring the field.
 for(let i=0;i<w/65;i++){const x=29+i*65,y=top+8+(i%3)*12,up=Math.sin(time*2+i*1.9)>.15;stroke(g,x,y,x-3,y-(up?7:2),'#f2d0a0',2);stroke(g,x+8,y,x+11,y-(up?5:2),'#e6b88a',2);}
}
export function drawGrass(g:CanvasRenderingContext2D,x:number,y:number,w:number,h:number){
 for(let row=0;row<Math.ceil(h/60);row++)box(g,x,y+row*60,w,Math.min(60,h-row*60),row%2?'#a3bd83':'#9bb77d');
 for(let yy=y+16;yy<y+h;yy+=37)for(let xx=x+19;xx<x+w;xx+=73){stroke(g,xx,yy,xx+3,yy-3,'#8da96f');stroke(g,xx+3,yy,xx+5,yy-4,'#b4ca93');}
}
const tracks=new Map<string,HTMLCanvasElement>();
export function drawTrack(g:CanvasRenderingContext2D,x:number,y:number,w:number,h:number,count=1,numbers=true){
 const key=`${w}:${h}:${count}:${numbers}`;let cached=tracks.get(key);
 if(!cached){cached=tile(w,h,b=>{
  const lh=h/count;box(b,0,0,w,h,'#ca896e');
  for(let i=0;i<count;i++){
   box(b,0,i*lh,w,lh,i%2?'#d69a79':'#cf9173');stroke(b,0,i*lh,w,i*lh,'#ffebc7',2);
   for(let xx=13;xx<w;xx+=29){const yy=i*lh+9+(xx*17%Math.max(8,Math.floor(lh-16)));box(b,xx,yy,2,1,'#b57b6255');box(b,xx+9,yy+4,3,1,'#edb28b66');}
   if(numbers&&lh>=30){b.font=`bold ${Math.min(26,lh*.43)}px sans-serif`;b.textAlign='center';b.fillStyle='#b67d61';b.fillText(String(i+1),23,i*lh+lh*.65+1);b.fillStyle='#fff0cf';b.fillText(String(i+1),22,i*lh+lh*.65);}
  }
  stroke(b,0,h-2,w,h-2,'#ffebc7',2);box(b,0,0,3,h,'#f5d6af');box(b,w-3,0,3,h,'#f5d6af');
 });tracks.set(key,cached);}
 g.drawImage(cached,x,y);
}
const pools=new Map<string,HTMLCanvasElement>();
export function drawPool(g:CanvasRenderingContext2D,x:number,y:number,w:number,h:number,lanes:number,time:number){
 const key=`${w}:${h}:${lanes}`;let base=pools.get(key);
 if(!base){base=tile(w,h,b=>{
  const water=b.createLinearGradient(0,0,0,h);water.addColorStop(0,'#65bac7');water.addColorStop(.5,'#409eae');water.addColorStop(1,'#61b2bc');b.fillStyle=water;b.fillRect(0,0,w,h);
  const ts=w>600?35:20;
  for(let xx=0;xx<w;xx+=ts)stroke(b,xx,0,xx,h,'#d4efdc15');for(let yy=0;yy<h;yy+=ts)stroke(b,0,yy,w,yy,'#d4efdc1a');
  for(let lane=0;lane<lanes;lane++){
   const cy=(lane+.5)*h/lanes;box(b,16,cy-2,w-32,4,'#236d7e55');box(b,22,cy-h/lanes*.24,4,h/lanes*.48,'#236d7e66');box(b,w-26,cy-h/lanes*.24,4,h/lanes*.48,'#236d7e66');
  }
  box(b,0,0,5,h,'#d1f0df44');box(b,w-5,0,5,h,'#276e8155');
 });pools.set(key,base);}
 g.save();g.beginPath();g.rect(x,y,w,h);g.clip();g.drawImage(base,x,y);
 for(let row=0;row<Math.ceil(h/23);row++)for(let col=0;col<Math.ceil(w/50);col++){
  const xx=x+col*50+(row%2)*17+Math.sin(time*.8+row+col)*7,yy=y+row*23+10+Math.sin(time*1.2+col*.6+row)*4;
  stroke(g,xx,yy,xx+13+Math.sin(time+col)*4,yy-2,'#c7ede45c',1);stroke(g,xx+8,yy-2,xx+16,yy-5,'#a6e0db35');
 }g.restore();
}
export function drawPoolRope(g:CanvasRenderingContext2D,x:number,y:number,w:number,index:number,time:number,spacing=20){
 stroke(g,x,y,x+w,y,'#345f684d',3);
 for(let xx=0;xx<w;xx+=spacing){const wave=Math.sin(time*1.8+xx*.035+index)*.6,red=(Math.floor(xx/spacing)+index)%5===0,color=red?'#d77f75':'#f2d48b';box(g,x+xx,y-2+wave,spacing*.66,4,color);box(g,x+xx+1,y-2+wave,spacing*.6,1,red?'#f3aea0':'#fff0bd');box(g,x+xx+2,y+2+wave,spacing*.5,1,'#497e8050');}
}
export function drawPoolDeck(g:CanvasRenderingContext2D,x:number,y:number,w:number,h:number){
 box(g,x-9,y-9,w+18,h+18,'#f4e8c9');for(let xx=x-8;xx<x+w+9;xx+=26){stroke(g,xx,y-8,xx,y-1,'#c9c8ae');stroke(g,xx,y+h+1,xx,y+h+8,'#c9c8ae');}box(g,x-4,y-4,w+8,4,'#fff6db');box(g,x-4,y+h,w+8,4,'#819e94');
}
export function drawSwimWake(g:CanvasRenderingContext2D,x:number,y:number,time:number,dir:number,scale=1){
 g.save();g.translate(x,y);g.scale(dir*scale,scale);
 for(let i=0;i<5;i++){const u=(time*1.6+i/5)%1;g.globalAlpha=(1-u)*.7;g.strokeStyle='#e6faf0';g.lineWidth=1;g.beginPath();g.ellipse(-23-i*7-u*9,6,7+u*9,2+u*2,0,0,TAU);g.stroke();if(i<3)box(g,-8-i*8,2-Math.sin(u*Math.PI)*13,2,2,'#e1f6e9');}
 g.restore();
}
export function drawSkeetGate(g:CanvasRenderingContext2D,x:number,y:number,side:number,active=false,hit=false){
 g.save();g.fillStyle=active?(hit?'#2a705eeb':'#93584ae6'):'#234d4be6';g.fillRect(x-24,y-22,48,44);
 g.strokeStyle='#f9e5b7';g.lineWidth=6;g.strokeRect(x-24,y-22,48,44);g.strokeStyle=active?(hit?'#ffe28a':'#f6a38b'):'#2c5149';g.lineWidth=3;g.strokeRect(x-24,y-22,48,44);
 for(const dx of [-1,1])for(const dy of [-1,1]){stroke(g,x+dx*24,y+dy*22,x+dx*17,y+dy*22,'#efc375',3);stroke(g,x+dx*24,y+dy*22,x+dx*24,y+dy*15,'#efc375',3);}
 stroke(g,x-4,y,x+4,y,'#f9eac48c');stroke(g,x,y-4,x,y+4,'#f9eac48c');
 box(g,x-28,y-40,56,13,'#31594d');g.fillStyle='#fff0cc';g.font='bold 10px sans-serif';g.textAlign='center';g.fillText(side===0?'A · 왼쪽':'C · 오른쪽',x,y-30);g.restore();
}
export function drawVaultEquipment(g:CanvasRenderingContext2D){
 // A single fixed apparatus; no animation frame is allowed to supply another vault.
 oval(g,284,213,39,3,'#36574730');
 for(const x of [258,304]){box(g,x-3,184,7,28,'#455f5b');box(g,x-2,187,2,22,'#a2b3a2');box(g,x-7,210,15,4,'#4c6457');box(g,x-4,211,9,1,'#9aa990');}
 box(g,250,173,68,15,'#83513e');box(g,252,171,64,13,'#b97b51');box(g,255,170,57,4,'#e2aa75');box(g,254,183,60,3,'#976144');stroke(g,259,175,309,175,'#c99566');
 for(const x of [256,311]){box(g,x,178,2,2,'#f3cea0');box(g,x,180,2,1,'#614c3c');}
 box(g,226,209,30,5,'#806f4b');box(g,228,207,26,4,'#edc778');stroke(g,231,208,249,208,'#fff0ba');
 drawMat(g,335,213,130,16);
}
export function drawMat(g:CanvasRenderingContext2D,x:number,y:number,w:number,h:number){
 box(g,x+3,y+3,w, h,'#31564e25');box(g,x,y,w,h,'#4f8991');box(g,x,y,w,Math.max(3,h*.62),'#7db9bc');box(g,x+2,y+1,w-4,2,'#b8dad0');
 for(let xx=x+w/3;xx<x+w-2;xx+=w/3)stroke(g,xx,y+2,xx,y+h-2,'#4f8d93');stroke(g,x+2,y+h-3,x+w-2,y+h-3,'#42747d');
}
export function drawSand(g:CanvasRenderingContext2D,x:number,y:number,w:number,h:number){
 box(g,x-3,y-3,w+6,h+6,'#8e8b65');box(g,x-1,y-1,w+2,h+2,'#f3dfae');box(g,x,y,w,h,'#dfca95');
 for(let yy=y+7;yy<y+h;yy+=11)for(let xx=x+6;xx<x+w-4;xx+=17){box(g,xx,yy+(xx%3),2,1,'#b59c6b');box(g,xx+6,yy+3,3,1,'#f4e2ae');}
 for(let yy=y+5;yy<y+h;yy+=12)stroke(g,x+5,yy,x+w-5,yy,'#c6b17d55');
}
export function drawPlatform(g:CanvasRenderingContext2D,x:number,y:number,w:number,h:number){
 box(g,x,y,w,h,'#9d8660');box(g,x+2,y-3,w-4,5,'#e5c894');stroke(g,x+5,y-2,x+w-5,y-2,'#fff0c3');
 for(let xx=x+15;xx<x+w;xx+=35)stroke(g,xx,y,xx,y+h-1,'#716b50');
}
