import {applyControl,stepMatch} from './engine.ts';
import type {ButtonInput,Match} from './model.ts';
export type RemoteInput=ButtonInput&{playerId:string};
export function remoteRoundTime(roundTime:number,lastReplyMs:number,nowMs:number){return roundTime+Math.min(1.5,Math.max(0,(nowMs-lastReplyMs)/1000));}
export class RemoteClock{
  private value=0;
  reset(){this.value=0;}
  read(roundTime:number,lastReplyMs:number,nowMs:number){this.value=Math.max(this.value,remoteRoundTime(roundTime,lastReplyMs,nowMs));return this.value;}
}
const WINDOW=1.5,EPS=1e-7;
type Command=RemoteInput&{time:number;order:number};
type Snapshot={time:number;known:number;state:Match};
/** The PC keeps a short authoritative history so delayed phone input uses its original game state. */
export class RemoteTimeline {
  private match:Match|null=null;
  private round=0;
  private clock=0;
  private order=0;
  private snapshots:Snapshot[]=[];
  private commands:Command[]=[];
  private lastInputTimes:Record<string,number>={};
  private ensure(match:Match){
    if(this.match===match&&this.round===match.number)return;
    this.match=match;this.round=match.number;this.clock=match.round?.time??0;this.order=0;this.commands=[];this.snapshots=[];this.lastInputTimes={};
    this.capture(match);
  }
  private capture(match:Match){
    this.snapshots.push({time:this.clock,known:this.order,state:structuredClone(match)});
    while(this.snapshots.length>1&&this.snapshots[1].time<this.clock-WINDOW-EPS)this.snapshots.shift();
    const oldest=this.snapshots[0];
    this.commands=this.commands.filter(c=>c.time>oldest.time+EPS||c.order>oldest.known);
  }
  step(match:Match,dt:number){
    this.ensure(match);
    if(match.phase==='countdown'){
      stepMatch(match,dt);
      if(match.phase as string==='playing'){this.clock=0;this.snapshots=[];this.capture(match);}
      return;
    }
    if(match.phase!=='playing'&&match.phase!=='results')return;
    stepMatch(match,dt);this.clock+=dt;this.capture(match);
  }
  receive(match:Match,inputs:RemoteInput[],ack:Record<string,number>){
    this.ensure(match);
    const incoming:Command[]=[];
    for(const input of inputs){
      if(input.seq<=(ack[input.playerId]??0))continue;
      ack[input.playerId]=input.seq;
      if(input.round!==match.number||!match.round||match.phase==='countdown')continue;
      const requested=Number.isFinite(input.at)?Math.min(this.clock,Math.max(0,input.at!)):this.clock;
      const time=Math.max(this.lastInputTimes[input.playerId]??0,requested);
      if(time<this.clock-WINDOW-EPS)continue;
      this.lastInputTimes[input.playerId]=time;incoming.push({...input,time,order:++this.order});
    }
    if(!incoming.length)return;
    this.commands.push(...incoming);
    const present=this.clock,first=Math.min(...incoming.map(c=>c.time));
    const base=[...this.snapshots].reverse().find(s=>s.time<=first+EPS)??this.snapshots[0];
    const replay=this.commands.filter(c=>c.time>base.time+EPS||c.order>base.known).sort((a,b)=>a.time-b.time||a.order-b.order);
    Object.assign(match,structuredClone(base.state));this.clock=base.time;
    this.snapshots=this.snapshots.filter(s=>s.time<base.time-EPS);
    const advance=(target:number)=>{while(this.clock<target-EPS){const dt=Math.min(1/60,target-this.clock);stepMatch(match,dt);this.clock+=dt;if(this.clock<target-EPS)this.capture(match);}};
    for(let i=0;i<replay.length;){
      const time=replay[i].time;advance(time);
      do{const command=replay[i++];applyControl(match,command.playerId,command.button,command.down,command.heldMs);}while(i<replay.length&&Math.abs(replay[i].time-time)<EPS);
      this.capture(match);
    }
    advance(present);this.capture(match);
  }
}
export function applyRemoteInputs(match:Match|null,inputs:RemoteInput[],ack:Record<string,number>,timeline?:RemoteTimeline){
  if(match&&timeline){timeline.receive(match,inputs,ack);return;}
  for(const input of inputs){
    if(input.seq<=(ack[input.playerId]??0))continue;
    if(match&&input.round===match.number){
      const round=match.round!,present=round.time;
      if(Number.isFinite(input.at))round.time=Math.max(present-.8,Math.min(present,input.at!));
      applyControl(match,input.playerId,input.button,input.down,input.heldMs);round.time=present;
    }
    ack[input.playerId]=input.seq;
  }
}

/** Predict only the view; the PC remains authoritative and reconciles every reply. */
export function projectRemoteMatch(match:Match,inputs:RemoteInput[],targetTime:number):Match{
  const projected=structuredClone(match);if(!projected.round||projected.phase!=='playing')return projected;
  const target=Math.max(projected.round.time,Math.min(projected.round.time+WINDOW,targetTime));
  const commands=inputs.filter(c=>c.round===projected.number&&(c.at??target)<=target+EPS).sort((a,b)=>(a.at??target)-(b.at??target)||a.seq-b.seq);
  const advance=(to:number)=>{while(projected.phase==='playing'&&projected.round!.time<to-EPS)stepMatch(projected,Math.min(1/60,to-projected.round!.time));};
  for(const input of commands){const time=Math.min(target,input.at??target);advance(time);const present=projected.round.time;projected.round.time=time;applyControl(projected,input.playerId,input.button,input.down,input.heldMs);projected.round.time=present;}
  advance(target);return projected;
}
