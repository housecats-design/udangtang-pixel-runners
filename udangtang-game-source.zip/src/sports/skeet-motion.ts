import {avatars} from '../data/avatars.ts';
import type {Athlete} from './model.ts';
import type {SkeetPose} from './skeet.ts';

const SIZE=64,COLUMNS=6;
let atlas:HTMLImageElement|null=null;
let loading:Promise<boolean>|null=null;
const frames=new Map<string,HTMLCanvasElement>();
export function hasSkeetMotion(){return atlas!==null;}
export function loadSkeetMotion(){return loading??=load();}
async function load(){
  const image=new Image();image.src=`${import.meta.env.BASE_URL}assets/characters/pixellab-skeet-sd.png`;
  try{
    await image.decode();if(image.width!==384||image.height!==320)return false;
    atlas=image;frames.clear();return true;
  }catch{loading=null;return false;}
}
const rgb=(hex:string)=>[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16));
// PixelLab option 02: keep its round silhouette, face, gun and pixel shading.
// Every athlete shares the generated motion with their saved color palette.
export function skeetFrame(person:Athlete,pose:SkeetPose){
  if(!atlas)return null;
  const index=pose.clip==='turn'?pose.frame:17+pose.frame;
  const key=`${person.avatar}:${person.color}:${index}`,cached=frames.get(key);if(cached)return cached;
  const canvas=document.createElement('canvas');canvas.width=canvas.height=SIZE;
  const g=canvas.getContext('2d')!;g.imageSmoothingEnabled=false;
  g.drawImage(atlas,index%COLUMNS*SIZE,Math.floor(index/COLUMNS)*SIZE,SIZE,SIZE,0,0,SIZE,SIZE);
  const a=avatars[person.avatar%avatars.length],hair=rgb(a.hair),skin=rgb(a.skin),shirt=rgb(person.color),pants=rgb(a.pants);
  const image=g.getImageData(0,0,SIZE,SIZE),pixels=image.data;
  for(let i=0;i<pixels.length;i+=4){
    if(!pixels[i+3])continue;
    const r=pixels[i],green=pixels[i+1],b=pixels[i+2],y=Math.floor(i/4/SIZE),x=i/4%SIZE;
    let color:number[]|null=null,base=1;
    if(green>r+12&&green>b+4){color=shirt;base=150;}
    else if(y<30&&r>45&&r>green+12&&green>b+3&&green<150){color=hair;base=100;}
    else if(r>165&&green>110&&r>green+12&&green>b+6&&(y<32||x<42)){color=skin;base=200;}
    else if(y>36&&b>r+5&&r<100&&green<120){color=pants;base=55;}
    if(color){
      const shade=Math.max(.35,Math.min(1.4,(r*.25+green*.6+b*.15)/base));
      for(let c=0;c<3;c++)pixels[i+c]=Math.round(Math.min(255,color[c]*shade));
    }
  }
  g.putImageData(image,0,0);frames.set(key,canvas);return canvas;
}
// Gun-tip coordinates in the original 64px source, before mirroring/scaling.
const shotTips=[[54,24],[54,24],[55,29],[54,29],[55,29],[55,29],[54,25],[54,25],[54,24]];
const turnTips=[[54,24],[54,24],[54,24],[55,26],[55,29],[54,30],[51,32],[46,33],[37,35],[28,35],[21,34],[15,31],[12,29],[11,27],[10,25],[10,24],[10,24]];
export function skeetMuzzle(pose:SkeetPose){
  const [x,y]=(pose.clip==='turn'?turnTips:shotTips)[pose.frame];
  return {x:(pose.mirror?32-x:x-32)*1.5,y:(y-60)*1.5};
}
