import {avatars} from '../data/avatars.ts';
import {hasRunnerAtlas,sprite} from '../rendering/renderer.ts';
import type {Athlete} from './model.ts';

// Retarget the PixelLab anticipation/recoil/recovery onto each original runner.
// The face, hair, jersey, shorts and shoes remain the actual saved character art.
const poses=[
  [0,0],[0,.02],[0,.05],[0,.10],[.15,.22],[.6,.55],[1,.8],[.85,.75],
  [.65,.6],[.4,.4],[.25,.25],[.13,.15],[.06,.08],[.02,.03],[0,0],[0,0],
] as const;
const frames=new Map<string,HTMLCanvasElement>();
let ready=false;
export function hasSkeetMotion(){return ready&&hasRunnerAtlas();}
export function loadSkeetMotion(){ready=true;frames.clear();return true;}
export function skeetMuzzle(index:number){
  const [recoil,lift]=poses[Math.min(15,Math.max(0,Math.floor(index)))];
  return {x:43-recoil*3,y:-55-lift*3};
}
const shade=(hex:string,amount:number)=>'#'+[1,3,5].map(i=>Math.max(0,Math.min(255,parseInt(hex.slice(i,i+2),16)+amount)).toString(16).padStart(2,'0')).join('');
export function skeetFrame(person:Athlete,index:number){
  if(!hasSkeetMotion())return null;
  index=Math.min(15,Math.max(0,Math.floor(index)));
  const key=`${person.avatar}:${person.color}:${index}`,cached=frames.get(key);if(cached)return cached;
  const a=avatars[person.avatar%avatars.length],identity={id:person.id,name:person.name,avatarId:a.id,paletteId:person.color};
  const body=document.createElement('canvas');body.width=body.height=64;
  const b=body.getContext('2d')!;b.imageSmoothingEnabled=false;b.drawImage(sprite(identity,0,'idle'),0,0);
  // Replace only the running arms; preserve all of the original head/body pixels.
  b.clearRect(6,34,18,13);b.clearRect(41,33,17,13);
  const canvas=document.createElement('canvas');canvas.width=canvas.height=96;
  const g=canvas.getContext('2d')!;g.imageSmoothingEnabled=false;g.translate(32,88);
  const [recoil,lift]=poses[index],edge='#344a47',muzzle=skeetMuzzle(index);
  g.save();g.scale(1,1-recoil*.035);g.drawImage(body,-32,-56);g.restore();
  const line=(x:number,y:number,ex:number,ey:number,color:string,width:number)=>{g.strokeStyle=color;g.lineWidth=width;g.lineCap='square';g.beginPath();g.moveTo(x,y);g.lineTo(ex,ey);g.stroke();};
  const skin=a.skin,shadow=shade(skin,-35),light=shade(skin,18);
  // Small shaded arms brace the stock; both hands stay attached through recoil.
  const handX=15-recoil*2,handY=-29-lift*2,frontX=29-recoil*2.5,frontY=-42-lift*2.5;
  line(-8,-22,4,-15,edge,7);line(4,-15,handX,handY,edge,7);
  line(-8,-22,4,-15,shadow,5);line(4,-15,handX,handY,skin,5);
  line(-8,-23,3,-17,light,2);line(5,-16,handX-1,handY-1,light,2);
  line(8,-23,19,-16,edge,7);line(19,-16,frontX,frontY,edge,7);
  line(8,-23,19,-16,shadow,5);line(19,-16,frontX,frontY,skin,5);
  line(9,-24,19,-18,light,2);line(20,-18,frontX-1,frontY,light,2);
  const stockX=5-recoil*2,stockY=-25-lift*2;
  line(stockX,stockY,muzzle.x,muzzle.y,edge,5);
  line(stockX,stockY,22-recoil*2,-39-lift*2,'#9c643c',5);
  line(stockX+1,stockY-1,22-recoil*2,-40-lift*2,'#d6a66c',2);
  line(23-recoil*2,-40-lift*2,muzzle.x,muzzle.y,'#a4b3ae',3);
  line(24-recoil*2,-41-lift*2,muzzle.x,muzzle.y-1,'#e0e5d5',1);
  // Fingers in front of the fore-end make the grip readable.
  line(frontX-2,frontY+1,frontX+1,frontY-1,skin,3);
  frames.set(key,canvas);return canvas;
}
