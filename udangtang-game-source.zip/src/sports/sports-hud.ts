import type {Competitor,SportId} from './model.ts';
const speedSports=new Set<SportId>(['swimming','hurdles','vault','triple','pole']);
export function drawSportsHud(g:CanvasRenderingContext2D,p:Competitor|null,sport:SportId,x:number,y:number,width=210,compact=false){
  if(!p)return;
  const speed=speedSports.has(sport),angle=sport==='archery'&&p.aimAt!==null||sport==='vault'&&p.phase==='angle'||sport==='triple'&&p.phase==='angle';
  if(!speed&&!angle&&sport!=='weightlifting')return;
  const value=sport==='weightlifting'?p.power:p.speed/10;
  g.save();g.translate(x,y);g.fillStyle='#fff9e7ed';g.fillRect(0,0,width,compact?26:43);
  g.fillStyle='#385e4d';g.textAlign='left';g.font=`bold ${compact?10:12}px sans-serif`;
  if(angle){
    const max=sport==='archery'?10:sport==='vault'?80:75,ideal=sport==='archery'?5.25:sport==='vault'?52:[35,41,45][Math.min(2,p.stage)],range=sport==='archery'?.3:sport==='vault'?8:4;
    const loading=sport==='archery'&&p.angle===0;
    g.fillText(loading?'화살 장전 → 각도 준비':`${compact&&speed?'속도 '+Math.round(p.speed*10)+'% · ':''}각도 ${p.angle.toFixed(sport==='archery'?1:0)}${sport==='archery'?'':'°'} · 목표 ${ideal}${sport==='archery'?'':'°'}`,8,compact?10:15);
    g.fillStyle='#d9dfc7';g.fillRect(8,compact?16:25,width-16,compact?6:9);
    g.fillStyle='#91ba76';g.fillRect(8+(width-16)*(ideal-range)/max,compact?16:25,(width-16)*range*2/max,compact?6:9);
    g.fillStyle='#ed9975';g.fillRect(7+(width-16)*Math.min(1,p.angle/max),compact?14:22,3,compact?10:15);
  }else{
    g.fillText(`${sport==='weightlifting'?'파워':'속도'} ${Math.round(Math.max(0,Math.min(1,value))*100)}%${compact?'':' · A / C 교차 연타'}`,8,compact?10:15);
    g.fillStyle='#d9dfc7';g.fillRect(8,compact?16:25,width-16,compact?6:9);
    g.fillStyle=p.phase==='gasping'?'#dd8c7f':'#6fb6a1';g.fillRect(8,compact?16:25,(width-16)*Math.max(0,Math.min(1,value)),compact?6:9);
  }
  g.restore();
  if(angle&&speed&&!compact)drawSportsHud(g,{...p,phase:'run'},sport,x+width+8,y,width,false);
}

