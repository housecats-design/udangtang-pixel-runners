import type {Match} from './model.ts';

type Clip = 'round-intro' | 'ready' | 'race-theme' | 'round-end';
const CLIPS:Clip[]=['round-intro','ready','race-theme','round-end'];
export class SportsAudio {
  enabled=true;
  private context:AudioContext|null=null;
  private gain:GainNode|null=null;
  private buffers=new Map<Clip,AudioBuffer>();
  private loading:Promise<void>|null=null;
  private playing:AudioBufferSourceNode|null=null;
  private scene='';
  private shotsHeard=new Set<string>();
  private shotNoise:AudioBuffer|null=null;

  constructor() {
    try {this.enabled=localStorage.getItem('udangtang.sports.sound')!=='off';} catch {}
  }
  async unlock() {
    if(!this.enabled)return;
    try {
      this.context??=new AudioContext();
      if(!this.gain) {
        this.gain=this.context.createGain();
        this.gain.gain.value=.18;
        this.gain.connect(this.context.destination);
      }
      if(this.context.state==='suspended')await this.context.resume();
      this.loading??=Promise.all(CLIPS.map(async clip=>{
        const response=await fetch(`${import.meta.env.BASE_URL}assets/sports/audio/${clip}.wav`);
        if(!response.ok)throw new Error(`Cannot load reference audio: ${clip}`);
        this.buffers.set(clip,await this.context!.decodeAudioData(await response.arrayBuffer()));
      })).then(()=>{}).catch(()=>{this.loading=null;});
      await this.loading;
    } catch { /* A failed audio device or asset does not interrupt the match. */ }
  }
  toggle() {
    this.enabled=!this.enabled;
    try {localStorage.setItem('udangtang.sports.sound',this.enabled?'on':'off');} catch {}
    this.scene='';
    if(this.enabled)void this.unlock();
    else this.stop();
  }
  sync(match:Match|null) {
    if(!this.enabled||!this.context||this.context.state!=='running'||this.buffers.size!==CLIPS.length)return;
    if(!match||match.phase==='countdown')this.shotsHeard.clear();
    if(match?.round?.sport==='skeet')for(const player of match.round.players)for(const shot of player.shotEffects??[]){
      const key=`${match.number}:${player.id}:${shot.id}`;
      if(this.shotsHeard.has(key))continue;
      this.shotsHeard.add(key);
      const age=match.round.time-shot.at;
      if(age>=0&&age<.45)this.skeetShot(shot.hit);
    }
    if(this.shotsHeard.size>300)this.shotsHeard=new Set([...this.shotsHeard].slice(-150));
    const phase=match?.phase??'lobby';
    const key=`${match?.number??0}:${phase}`;
    if(key===this.scene)return;
    this.scene=key;
    const clip:Clip=phase==='playing'?'race-theme':phase==='countdown'?'ready':phase==='results'||phase==='finished'?'round-end':'round-intro';
    this.stop();
    const source=this.context.createBufferSource();
    source.buffer=this.buffers.get(clip)!;
    source.loop=clip==='race-theme';
    source.connect(this.gain!);
    source.start();
    this.playing=source;
  }
  private skeetShot(hit:boolean){
    const ctx=this.context!,now=ctx.currentTime;
    this.shotNoise??=ctx.createBuffer(1,Math.floor(ctx.sampleRate*.075),ctx.sampleRate);
    const data=this.shotNoise.getChannelData(0);
    for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*(1-i/data.length)**3;
    const noise=ctx.createBufferSource(),volume=ctx.createGain();
    noise.buffer=this.shotNoise;volume.gain.setValueAtTime(.45,now);volume.gain.exponentialRampToValueAtTime(.01,now+.075);
    noise.connect(volume);volume.connect(this.gain!);noise.start(now);
    if(hit){
      const ping=ctx.createOscillator(),ring=ctx.createGain();ping.type='triangle';
      ping.frequency.setValueAtTime(1700,now+.025);ping.frequency.exponentialRampToValueAtTime(800,now+.16);
      ring.gain.setValueAtTime(.12,now+.025);ring.gain.exponentialRampToValueAtTime(.001,now+.18);
      ping.connect(ring);ring.connect(this.gain!);ping.start(now+.025);ping.stop(now+.18);ping.onended=()=>{ping.disconnect();ring.disconnect();};
    }
    noise.onended=()=>{noise.disconnect();volume.disconnect();};
  }
  stop() {
    try {this.playing?.stop();} catch {}
    this.playing?.disconnect();
    this.playing=null;
  }
  get ready() {return this.buffers.size===CLIPS.length;}
}
