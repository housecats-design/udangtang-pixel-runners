import type {SkeetShot,SkeetAim,SkeetTarget} from './skeet.ts';
export type SportId = 'swimming' | 'skeet' | 'vault' | 'archery' | 'triple' | 'weightlifting' | 'pole' | 'hurdles';
export type Control = 'A' | 'B' | 'C';
export type SportDefinition = {
  id: SportId; name: string; english: string; symbol: string; color: string;
  description: string; controls: [string, string, string]; instructions: string[]; duration: number;
};
export const SPORTS: SportDefinition[] = [
  {id:'hurdles',name:'100m 장애물 달리기',english:'100M HURDLES',symbol:'▥',color:'#d68c69',duration:55,
    description:'번갈아 달리고, 타이밍 맞춰 뛰어넘어요.',controls:['달리기 · 왼발','허들 점프','달리기 · 오른발'],
    instructions:['A와 C를 번갈아 연타하면 더 빠르게 달려요.','허들에 가까워지면 B를 한 번 눌러 뛰어넘어요.','허들 10개를 넘어 100m 결승선에 먼저 도착하세요. 걸려도 다시 일어나 달릴 수 있어요.']},
  {id:'swimming',name:'100m 자유형',english:'FREESTYLE',symbol:'≈',color:'#49bbd2',duration:50,
    description:'물살을 가르는 리듬, 한 번의 호흡.',controls:['왼팔 젓기','호흡','오른팔 젓기'],
    instructions:['A와 C를 번갈아 빠르게 눌러 헤엄쳐요.','빨간 BREATH 신호 후 0.7초 안에 B! 놓치면 멈추며 B로 회복해요.','100m를 먼저 완주할수록 높은 점수를 받아요.']},
  {id:'skeet',name:'클레이 사격',english:'SKEET SHOOTING',symbol:'◎',color:'#e5b25e',duration:29,
    description:'엇갈리는 순서와 빠른 연사, 32개의 표적.',controls:['왼쪽 사격','사용 안 함','오른쪽 사격'],
    instructions:['왼쪽 표적이 상자에 들어오면 A, 오른쪽은 C를 눌러요.','좌우·우좌·같은 쪽 연속·시간차 발사가 섞여요. 표적마다 한 발!','빠르게 지나가는 표적 32개를 모두 맞히면 보너스에 도전해요.']},
  {id:'vault',name:'도마',english:'VAULTING',symbol:'↗',color:'#ef8d77',duration:25,
    description:'도움닫기부터 착지까지, 한 번에.',controls:['달리기 · 공중 회전','누르고 각도 · 떼서 도약','달리기'],
    instructions:['A·C를 번갈아 연타해 도움닫기 속도를 올려요.','발판 직전 B를 누르고 45~60°에서 떼어 도약해요.','공중에서 A를 8번씩 눌러 한 바퀴! 발을 아래로 펴고 착지하세요.']},
  {id:'archery',name:'양궁',english:'ARCHERY',symbol:'⊕',color:'#9bad65',duration:60,
    description:'바람을 읽고, 손끝으로 정중앙.',controls:['풍향 결정','누르고 각도 · 떼서 발사','풍향 결정'],
    instructions:['아무 버튼으로 바람을 결정해요.','B를 누르면 먼저 화살을 장전해요. 장전 후 5.0~5.5에서 떼세요.','고정 과녁으로 날아가는 화살을 확인하세요. 기본 8발!']},
  {id:'triple',name:'세단뛰기',english:'TRIPLE JUMP',symbol:'⌁',color:'#dbad65',duration:28,
    description:'홉, 스텝, 점프. 세 번의 완벽한 순간.',controls:['달리기','누르고 각도 · 떼서 점프','달리기'],
    instructions:['A·C 연타로 속도를 올리고 발구름 선에 접근해요.','B를 눌렀다 떼며 홉 35° · 스텝 41° · 점프 45°를 맞혀요.','선을 넘기 전에 첫 점프를 시작해야 해요.']},
  {id:'weightlifting',name:'역도',english:'WEIGHTLIFTING',symbol:'⊣',color:'#aa94d0',duration:30,
    description:'무게를 고르고, 끝까지 버티기.',controls:['무게 올리기 · 힘','결정 · 들어 올리기','무게 내리기 · 힘'],
    instructions:['A·C로 무게를 고르고 B로 결정해요.','A·C 연타로 힘을 모으고 반짝이는 순간 B!','들어 올린 뒤에도 A·C를 눌러 심판의 합격을 받아요.']},
  {id:'pole',name:'장대높이뛰기',english:'POLE VAULT',symbol:'⌒',color:'#6da9cc',duration:25,
    description:'장대를 꽂고, 하늘을 넘는 타이밍.',controls:['도움닫기','누르고 꽂기 · 떼서 놓기','도움닫기'],
    instructions:['A·C로 도움닫기 속도를 올려요.','홈에 가까워지면 B를 누르고 유지해요.','몸이 장대 꼭대기에 올라갔을 때 B를 놓아 바를 넘어요.']},
];
export function sportDefinition(id: SportId) { return SPORTS.find(sport => sport.id === id)!; }
export type Athlete = {id:string; name:string; avatar:number; color:string; ready:boolean; connected:boolean; total:number};
export type Competitor = {
  id:string; progress:number; speed:number; power:number; oxygen:number; breathAt:number;
  phase:string; phaseAt:number; lastTap:Control|null; lastPulse:number; angle:number; rotation:number;
  height:number; weight:number; hits:number; attempts:number; bonus:number; score:number;
  result:string; finished:boolean; finishAt:number|null; quality:number; stage:number;
  vault?:{runSpeed:number;launchAngle:number;peak:number;duration:number;targetRotation:number;success?:boolean};
  arrow?:{at:number;angle:number;points:number;error:number};
  shots:number[]; angles:number[]; aimAt:number|null; feedback:string; feedbackAt:number;shotEffects?:SkeetShot[];skeetAim?:SkeetAim;
};
export type SportsRound = {sport:SportId; time:number; wind:number; players:Competitor[]; completed:boolean;skeetTargets?:SkeetTarget[]};
export type Match = {phase:'lobby'|'countdown'|'playing'|'results'|'finished'; events:SportId[]; eventIndex:number;
  countdown:number; round:SportsRound|null; athletes:Athlete[]; number:number; updatedAt:number};
export type ButtonInput = {seq:number; button:Control; down:boolean; round:number; heldMs?:number; at?:number};
export type RoomView = {code:string; athletes:Athlete[]; match:Match|null; revision:number; hostSeen:number; expires:number};
export type Session = {code:string; token:string; playerId:string|null; role:'host'|'player'|'display'};
export const PLAYER_COLORS = ['#49c4b2','#f2b957','#ee8c9a','#78ade6','#b49bde','#ec9364','#9bb66b','#df7688','#58b7cf','#d2b383'];
