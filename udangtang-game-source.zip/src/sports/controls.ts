import type {Control} from './model.ts';

/** Safari touch input does not depend on PointerEvent capture or a synthetic click. */
export function bindSportButton(button:HTMLButtonElement,control:Control,press:(control:Control,down:boolean)=>void,releaseTarget:EventTarget=window){
  const touches=new Set<number>(),pointers=new Set<number>();
  let held=false,lastPhysical=-Infinity;
  const emit=()=>{const next=touches.size>0||pointers.size>0;if(next!==held){held=next;press(control,next);}};
  const physical=()=>{lastPhysical=performance.now();};
  const touchStart=(event:Event)=>{
    const e=event as TouchEvent;e.preventDefault();physical();
    for(const touch of Array.from(e.changedTouches))touches.add(touch.identifier);emit();
  };
  const touchEnd=(event:Event)=>{
    const e=event as TouchEvent;e.preventDefault();physical();
    for(const touch of Array.from(e.changedTouches))touches.delete(touch.identifier);emit();
  };
  const pointerDown=(event:Event)=>{
    const e=event as PointerEvent;
    e.preventDefault();physical();pointers.add(e.pointerId);emit();
    // Capture is only an optional aid for a mouse/pen dragged outside the button.
    // Safari can throw here; the actual press must already have been delivered.
    if(e.pointerType!=='touch')try{button.setPointerCapture?.(e.pointerId);}catch{}
  };
  const pointerEnd=(event:Event)=>{
    const e=event as PointerEvent;
    if(pointers.delete(e.pointerId)){physical();emit();}
  };
  const release=()=>{touches.clear();pointers.clear();emit();};
  const click=(event:Event)=>{
    event.preventDefault();
    // VoiceOver and browsers that deliver only a click still operate the controller.
    // A touch/pointer already handled above must not become a second stroke.
    if(held||performance.now()-lastPhysical<500)return;
    press(control,true);press(control,false);
  };
  const listeners:Array<[EventTarget,string,EventListener,AddEventListenerOptions?]>=[
    [button,'touchstart',touchStart,{passive:false}],[button,'touchend',touchEnd,{passive:false}],
    [button,'touchcancel',touchEnd,{passive:false}],[button,'pointerdown',pointerDown],
    [button,'pointerup',pointerEnd],[button,'pointercancel',pointerEnd],[button,'lostpointercapture',pointerEnd],
    [button,'click',click],[releaseTarget,'pointerup',pointerEnd],[releaseTarget,'pointercancel',pointerEnd],
    [releaseTarget,'blur',release],[releaseTarget,'pagehide',release],
  ];
  for(const [target,type,listener,options] of listeners)target.addEventListener(type,listener,options);
  return ()=>{for(const [target,type,listener] of listeners)target.removeEventListener(type,listener);release();};
}
