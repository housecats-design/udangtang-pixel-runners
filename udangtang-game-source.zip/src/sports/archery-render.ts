import {avatars} from '../data/avatars.ts';
import {sprite} from '../rendering/renderer.ts';
import type {Athlete,Competitor} from './model.ts';
import {archeryPose,archeryDemo,ARCHERY_LOAD_SECONDS,ARROW_FLIGHT} from './archery.ts';
import {archeryFrame} from './archery-motion.ts';
export {ARROW_FLIGHT} from './archery.ts';
export function drawArcher(g:CanvasRenderingContext2D,person:Athlete,p:Competitor|null,t:number){
  const pose=archeryPose(p??archeryDemo(t),t),motion=archeryFrame(person,pose.frame);
  if(motion){
    g.drawImage(motion,-40,-75,80,80);
    if(pose.clip==='loading'){g.fillStyle='#fff1c5';g.font='bold 11px sans-serif';g.textAlign='center';g.fillText('화살 장전 중',0,-78);}
    return {generated:true,pose,arrowStart:{x:26.25,y:-35}};
  }
  const a=avatars[person.avatar%avatars.length],loading=p?.aimAt!==null&&p?.aimAt!==undefined;
  const load=loading?Math.min(1,(t-p!.aimAt!)/ARCHERY_LOAD_SECONDS):1,age=p?.arrow?t-p.arrow.at:100;
  const recoil=age<.25?Math.sin(age/.25*Math.PI)*4:0,draw=loading?load:age<.25?1-age/.25:0;
  g.drawImage(sprite({id:person.id,name:person.name,avatarId:a.id,paletteId:person.color},0,'idle'),-32,-56);
  const line=(x:number,y:number,ex:number,ey:number,color:string,width=3)=>{g.strokeStyle=color;g.lineWidth=width;g.beginPath();g.moveTo(x,y);g.lineTo(ex,ey);g.stroke();};
  // Front arm braces the bow; the rear hand takes an arrow, nocks and draws it.
  const handX=25-draw*22,handY=-29-(1-load)*14;
  line(-4,-24,handX,handY,a.skin,5);line(9,-24,30,-29,a.skin,5);
  g.strokeStyle='#b17a4e';g.lineWidth=3;g.beginPath();g.moveTo(31,-53);g.quadraticCurveTo(51-recoil,-29,31,-5);g.stroke();
  line(31,-53,handX,-29,'#f5e7bd',1);line(handX,-29,31,-5,'#f5e7bd',1);
  if(loading){line(handX,-29,49,-29,'#fff2c5',2);line(48,-29,43,-32,'#5c6452',2);}
  if(loading&&load<1){g.fillStyle='#fff1c5';g.font='bold 11px sans-serif';g.textAlign='center';g.fillText('화살 장전 중',0,-66);}
  return {generated:false,pose,arrowStart:{x:45,y:-29}};
}
export function drawArrow(g:CanvasRenderingContext2D,p:Pick<Competitor,'arrow'|'quality'>|null,t:number,start:{x:number;y:number},target:{x:number;y:number},scale=1){
  if(!p?.arrow)return;
  const age=t-p.arrow.at;if(age<0)return;
  const impactY=target.y+Math.max(-65,Math.min(65,(p.arrow.angle-5.25+p.quality*.1)*16))*scale;
  if(age<ARROW_FLIGHT){
    const u=age/ARROW_FLIGHT,x=start.x+(target.x-start.x)*u,y=start.y+(impactY-start.y)*u-Math.sin(Math.PI*u)*42*scale;
    const slope=(impactY-start.y-42*scale*Math.PI*Math.cos(Math.PI*u))/(target.x-start.x);
    g.save();g.translate(x,y);g.rotate(Math.atan(slope));
    g.strokeStyle='#35524a';g.lineWidth=4.5*scale;g.beginPath();g.moveTo(-35*scale,0);g.lineTo(5*scale,0);g.stroke();g.strokeStyle='#fff3bb';g.lineWidth=2.5*scale;g.stroke();
    g.fillStyle='#43544b';g.beginPath();g.moveTo(8*scale,0);g.lineTo(0,-4*scale);g.lineTo(0,4*scale);g.fill();
    g.fillStyle='#e29c7d';g.fillRect(-32*scale,-3*scale,7*scale,6*scale);g.restore();
    for(let i=1;i<4;i++){g.fillStyle='#fff7d5'+['99','66','33'][i-1];g.fillRect(x-i*17*scale,y,8*scale,2*scale);}
  }else{
    const hitAge=age-ARROW_FLIGHT;
    g.strokeStyle='#fdf0c5';g.lineWidth=2*scale;g.beginPath();g.moveTo(target.x-22*scale,impactY);g.lineTo(target.x,impactY);g.stroke();
    if(hitAge<.65){
      g.save();g.globalAlpha=1-hitAge/.65;g.strokeStyle=p.arrow.points>=8?'#ffe17d':'#f3b49a';g.lineWidth=3*scale;g.beginPath();g.arc(target.x,impactY,(7+hitAge*45)*scale,0,Math.PI*2);g.stroke();
      for(let i=0;i<8;i++){const a=i*Math.PI/4,r=(12+hitAge*40)*scale;g.fillStyle='#fff1b5';g.fillRect(target.x+Math.cos(a)*r,impactY+Math.sin(a)*r,3*scale,3*scale);}
      g.restore();
    }
  }
}
