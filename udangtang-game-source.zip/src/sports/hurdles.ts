// Shared by simulation and both camera views so visible hurdles match collisions.
export const HURDLES=Array.from({length:10},(_,index)=>13+index*8.5);
export const HURDLE_JUMP_SECONDS=.72;
export const HURDLE_CLEARANCE=22;
export function hurdleHeight(age:number){return Math.sin(Math.min(1,Math.max(0,age/HURDLE_JUMP_SECONDS))*Math.PI)*46;}
export function hurdleJumpCue(distance:number,speed:number){return speed>.2&&distance/speed>=.18&&distance/speed<=.42;}
