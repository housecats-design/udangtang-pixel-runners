import type {Competitor} from './model.ts';

export const ARCHERY_LOAD_SECONDS=.5;
export const ARCHERY_SHOT_COOLDOWN=1.05;
export const ARROW_FLIGHT=.8;
type ArcherState=Pick<Competitor,'aimAt'|'arrow'>;
export type ArcheryPose={frame:number;clip:'ready'|'loading'|'aiming'|'release'|'recover'};

// Play sections of the actual PixelLab performance; hold the drawn bow until B is released.
export function archeryPose(p:ArcherState,t:number):ArcheryPose{
  if(p.aimAt!==null){
    const age=Math.max(0,t-p.aimAt);
    if(age<ARCHERY_LOAD_SECONDS)return {frame:4+Math.min(4,Math.floor(age/ARCHERY_LOAD_SECONDS*5)),clip:'loading'};
    const aiming=[8,9,10,11,12,11,10,9];
    return {frame:aiming[Math.floor((age-ARCHERY_LOAD_SECONDS)*6)%aiming.length],clip:'aiming'};
  }
  const age=p.arrow?t-p.arrow.at:Infinity;
  if(age>=0&&age<.24)return {frame:13+Math.min(2,Math.floor(age/.08)),clip:'release'};
  if(age>=.24&&age<.48)return {frame:[2,3,4][Math.min(2,Math.floor((age-.24)/.08))],clip:'recover'};
  return {frame:4,clip:'ready'};
}

// The landing-page guide uses the same loading, hold and release poses as live play.
export function archeryDemo(t:number):ArcherState&{quality:number}{
  const cycle=((t%4.5)+4.5)%4.5,base=t-cycle;
  return {quality:0,aimAt:cycle>=.8&&cycle<2.6?base+.8:null,
    arrow:cycle>=2.6?{at:base+2.6,angle:5.25,points:10,error:0}:undefined};
}
