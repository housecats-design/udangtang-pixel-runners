import {avatars} from '../data/avatars.ts';
import {motionFrame} from '../rendering/generated-motions.ts';
import {sprite} from '../rendering/renderer.ts';
import {vaultFrame} from './vault-motion.ts';
import {drawSportsHud} from './sports-hud.ts';
import {drawVaultEquipment,drawTrack} from './scenery.ts';
import type {Athlete,Competitor} from './model.ts';
export function drawVault(g:CanvasRenderingContext2D,person:Athlete,p:Competitor|null,t:number,hud=true,arena=false){
  const a=avatars[person.avatar%avatars.length],identity={id:person.id,name:person.name,avatarId:a.id,paletteId:person.color};
  const phase=p?.phase??'run',age=t-(p?.phaseAt??0),floor=210;
  const progress=p?.progress??((t*15)%140),x=45+Math.min(140,progress)/140*350;
  drawTrack(g,0,195,330,35,1,false);drawVaultEquipment(g);
  g.fillStyle='#2a4a3425';g.beginPath();g.ellipse(x,floor+3,16,3,0,0,Math.PI*2);g.fill();
  let image:HTMLCanvasElement|null=null,rotation=0;
  if(phase==='takeoff')image=vaultFrame(person,'takeoff',age/.4*6);
  if(phase==='horse')image=vaultFrame(person,'takeoff',6+age/.35*10);
  if(phase==='air'){
    const fraction=((p?.rotation??0)%(Math.PI*2))/(Math.PI*2);
    image=vaultFrame(person,'somersault',4+fraction*12);
    if((p?.attempts??0)===0)image=vaultFrame(person,'takeoff',15);
  }
  if(phase==='landing'||phase==='salute')image=vaultFrame(person,'landing',phase==='salute'?11:4+age/.7*8);
  g.save();g.translate(x,floor-(p?.height??0)*(arena?.3:1));if(arena)g.scale(.3,.76);
  if(phase==='cry')g.drawImage(sprite(identity,Math.floor(age*6),'cry'),-32,-56);
  else if(phase==='fall'||phase==='landing'&&p?.vault?.success===false){
    const u=phase==='fall'?Math.min(1,age/.7):Math.min(1,age/.7)*.45;
    const fall=motionFrame(identity,'fall',Math.floor(u*5));
    if(fall)g.drawImage(fall.canvas,-32,-56);else{g.translate(0,-18);g.rotate(u*1.35);g.drawImage(sprite(identity,0,'idle'),-32,-38);}
  }else if(image){
    // Fixed canvas anchor; only the world trajectory moves the athlete.
    const stretch=phase==='takeoff'?1+(p?.vault?.runSpeed??0)*.007:1;
    g.scale(1,stretch);g.rotate(rotation);g.drawImage(image,-48,-76,96,96);
  }else{
    if(phase==='angle')g.scale(1,.88);
    g.drawImage(sprite(identity,Math.floor(t*(8+(p?.speed??0)))%8,phase==='ready'||phase==='angle'?'idle':'run'),-32,-56);
  }
  g.restore();
  if(phase==='landing'||phase==='fall')for(let i=0;i<7;i++){const u=Math.min(.7,age);g.fillStyle=i%2?'#e7dfb8':'#fff0cc';g.fillRect(x+(i-3)*u*19,floor-3-Math.sin(u*4+i)*4,3,2);}
  if(hud&&p){
    drawSportsHud(g,p,'vault',12,12);
    g.textAlign='center';g.font='bold 12px sans-serif';g.fillStyle='#345b49';
    if(phase==='run')g.fillText(progress>64?'B 누르고 각도 준비!':'A / C 번갈아 달리기',240,246);
    if(phase==='air'){
      g.fillText(`A 회전 ${p.attempts}/8 · ${Math.round((p.rotation%(Math.PI*2))/(Math.PI*2)*360)}° · 발이 아래로!`,240,246);
      g.strokeStyle='#f6dfa2';g.lineWidth=4;g.beginPath();g.arc(414,100,20,-Math.PI/2,-Math.PI/2+p.rotation%(Math.PI*2));g.stroke();
    }
    if(p.finished)g.fillText(p.result,240,246);
  }
}
