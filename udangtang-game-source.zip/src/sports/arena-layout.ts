export const ARENA_WIDTH=1280,ARENA_HEIGHT=760;
export function arenaLanes(count:number){
  const size=Math.max(1,Math.min(8,count)),height=Math.min(96,480/size);
  const top=260+(480-size*height)/2;
  return Array.from({length:size},(_,index)=>({index,top:top+index*height,y:top+(index+.5)*height,height}));
}
export function arenaStations(count:number){
  const size=Math.max(1,Math.min(8,count)),columns=Math.min(4,size),rows=Math.ceil(size/columns),width=1120/columns;
  return Array.from({length:size},(_,index)=>({index,x:80+width*(index%columns+.5),
    y:rows===1?570:430+Math.floor(index/columns)*225,scale:Math.min(1.25,width/260)}));
}
