import {avatars} from '../data/avatars.ts';
import type {Athlete} from './model.ts';

const WIDTH=96,HEIGHT=64,COLUMNS=12,FRAMES=72,FPS=12;
// Shorten the body, retaining the original head width and height.
export const SWIMMING_WIDTH_SCALE=.75;
export function drawSwimmingFrame(g:CanvasRenderingContext2D,frame:CanvasImageSource,y=-32){
  const width=WIDTH*SWIMMING_WIDTH_SCALE;
  const headStart=64,headWidth=WIDTH-headStart,bodyWidth=width-headWidth;
  g.drawImage(frame,0,0,headStart,HEIGHT,-width/2,y,bodyWidth,HEIGHT);
  g.drawImage(frame,headStart,0,headWidth,HEIGHT,-width/2+bodyWidth,y,headWidth,HEIGHT);
}
let atlas:HTMLImageElement|null=null;
const frames=new Map<string,HTMLCanvasElement>();
const rgb=(hex:string)=>[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16));
export async function loadSwimmingMotion(){
  const image=new Image();image.src=`${import.meta.env.BASE_URL}assets/characters/higgsfield-swimming.png`;
  try {await image.decode();if(image.width!==1152||image.height!==384)return false;atlas=image;frames.clear();return true;}
  catch{return false;}
}
// One generated swimming performance is shared, with each saved character's colors.
export function swimmingFrame(person:Athlete,time:number){
  if(!atlas)return null;
  const index=Math.floor(Math.max(0,time)*FPS)%FRAMES,key=`${person.avatar}:${person.color}:${index}`;
  const cached=frames.get(key);if(cached)return cached;
  const canvas=document.createElement('canvas');canvas.width=WIDTH;canvas.height=HEIGHT;
  const g=canvas.getContext('2d')!;g.imageSmoothingEnabled=false;
  g.drawImage(atlas,index%COLUMNS*WIDTH,Math.floor(index/COLUMNS)*HEIGHT,WIDTH,HEIGHT,0,0,WIDTH,HEIGHT);
  if(person.avatar!==0){
    const a=avatars[person.avatar%avatars.length],skin=rgb(a.skin),hair=rgb(a.hair),shirt=rgb(person.color),pants=rgb(a.pants);
    const image=g.getImageData(0,0,WIDTH,HEIGHT),pixels=image.data;
    for(let i=0;i<pixels.length;i+=4){
      if(!pixels[i+3])continue;
      const r=pixels[i],green=pixels[i+1],b=pixels[i+2],x=(i/4)%WIDTH;
      let color:number[]|null=null,brightness=1;
      if(green-r>12&&b-r>6&&green>b-20){color=shirt;brightness=(r*.25+green*.6+b*.15)/130;}
      else if(r>145&&r-green>14&&green-b>9&&green/r>.66){color=skin;brightness=(r*.25+green*.6+b*.15)/195;}
      else if(x>45&&r>42&&r-green>12&&green-b>4&&green/r<.78){color=hair;brightness=(r*.25+green*.6+b*.15)/95;}
      else if(x<60&&b-r>7&&b-green>2&&r<85&&green<95&&b<135){color=pants;brightness=(r*.25+green*.6+b*.15)/55;}
      if(color)for(let c=0;c<3;c++)pixels[i+c]=Math.round(Math.min(255,color[c]*Math.max(.3,Math.min(1.5,brightness))));
    }
    g.putImageData(image,0,0);
  }
  frames.set(key,canvas);return canvas;
}
