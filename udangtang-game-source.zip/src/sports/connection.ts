import type {ButtonInput, Match, RoomView, Session} from './model.ts';
export const ONLINE_ORIGIN='https://udangtang-pixel-runners.housecats850262.chatgpt.site';
export const API_BASE=import.meta.env?.DEV?'/sports-api':`${ONLINE_ORIGIN}/sports-api`;
export type SyncReply = {view:RoomView; playerId?:string; ack?:number; frame?:number; epoch?:number; inputs?:Array<ButtonInput&{playerId:string}>};
export async function api<T>(action:string,body:Record<string,unknown>):Promise<T> {
  const response=await fetch(`${API_BASE}/${action}`,{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify(body),signal:AbortSignal.timeout(8000)});
  const result=await response.json();
  if(!response.ok)throw new Error(result.error??'연결을 확인해 주세요.');
  return result;
}
export type RoomTransport=(action:string,body:Record<string,unknown>)=>Promise<SyncReply>;
export class RoomConnection {
  pending:ButtonInput[]=[];
  seq=Date.now();
  frame=Date.now();
  epoch=0;
  ack:Record<string,number>={};
  ready:boolean|undefined;
  match:Match|null=null;
  onState:(reply:SyncReply)=>void=()=>{};
  onError:(message:string)=>void=()=>{};
  private timer:ReturnType<typeof setTimeout>|null=null;
  private active=false;
  private generation=0;
  private syncing:number|null=null;
  readonly session:Session;
  private request:RoomTransport;
  constructor(session:Session,request:RoomTransport=api){this.session=session;this.request=request;}
  input(input:Omit<ButtonInput,'seq'>) {
    this.pending.push({...input,seq:++this.seq});
    // Send a fresh touch immediately rather than waiting for the next poll.
    if(this.active&&this.syncing!==this.generation){if(this.timer)clearTimeout(this.timer);this.timer=null;void this.sync();}
  }
  start() {if(this.active)return;this.active=true;this.generation++;void this.sync();}
  stop() {this.active=false;this.generation++;if(this.timer)clearTimeout(this.timer);this.timer=null;}
  async sync() {
    const generation=this.generation;
    if(!this.active||this.syncing===generation)return;
    this.syncing=generation;
    try {
      const host=this.session.role==='host';
      const result=await this.request(host?'host':this.session.role==='display'?'watch':'sync',{
        code:this.session.code,token:this.session.token,
        ...(host?{match:this.match,frame:++this.frame,epoch:this.epoch,ack:this.ack}:{inputs:this.pending.slice(0,40),ready:this.ready}),
      });
      if(!this.active||generation!==this.generation)return;
      if(result.ack!==undefined)this.pending=this.pending.filter(input=>input.seq>result.ack!);
      if(!host){
        const current=result.view.match;
        // Old round inputs must never occupy all 40 slots and block a rematch.
        this.pending=this.pending.filter(input=>current?.phase==='playing'&&input.round===current.number);
      }
      if(result.epoch!==undefined)this.epoch=result.epoch;
      this.onState(result);
    } catch(error) {if(this.active&&generation===this.generation)this.onError((error as Error).message);}
    finally{if(this.syncing===generation)this.syncing=null;}
    if(this.active&&generation===this.generation)this.timer=setTimeout(()=>void this.sync(),this.session.role==='display'?180:100);
  }
}
