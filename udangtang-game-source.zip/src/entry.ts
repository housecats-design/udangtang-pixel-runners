import {raceShell,sitePage,updatePageMetadata} from './site-pages.ts';
const page=sitePage(location.search);
updatePageMetadata(page);
if(page==='sports') {
  void import('./sports/app.ts');
} else if(page==='race') {
  document.querySelector('main')!.outerHTML=raceShell();
  void import('./main.ts');
} else {
  void import('./hub.ts');
}
