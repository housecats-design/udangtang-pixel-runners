import './hub.css';
import {siteHeader} from './ui/site-header.ts';
import {avatars} from './data/avatars.ts';
import {loadRunnerAtlas,sprite} from './rendering/renderer.ts';
import {SportCanvas} from './sports/render.ts';
document.body.className='hub-body';
document.body.insertAdjacentHTML('afterbegin',siteHeader('home',false));
document.body.insertAdjacentHTML('beforeend',`<dialog class="hub-help" id="hub-help"><h2>우당탕 게임룸에 오신 걸 환영해요!</h2><p><strong>우당탕 달리기</strong><br>참가자 이름을 넣고 달리면 끝! 자동으로 펼쳐지는 레이스로 1등 또는 꼴찌를 뽑아요.</p><p><strong>우당탕 올림픽</strong><br>방을 만들고 방 코드로 친구들을 초대해요. 최대 8명이 각자의 휴대폰으로 A·B·C 버튼을 눌러 경기해요. 혼자 연습도 가능해요.</p><button id="hub-help-close">알겠어요</button></dialog>`);
const help=document.querySelector<HTMLDialogElement>('#hub-help')!;
document.querySelector<HTMLButtonElement>('#help')!.onclick=()=>help.showModal();
document.querySelector<HTMLButtonElement>('#hub-help-close')!.onclick=()=>help.close();
const canvas=document.querySelector<HTMLCanvasElement>('#hub-race-art')!;
const g=canvas.getContext('2d')!;
const olympics=new SportCanvas(document.querySelector<HTMLCanvasElement>('#hub-olympics-art')!);
const background=new Image();background.src=`${import.meta.env.BASE_URL}assets/maps/woodland-festival-v1.png`;
void loadRunnerAtlas();
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
let last=0;
function draw(now:number) {
  requestAnimationFrame(draw);
  if(document.hidden||now-last<1000/(reduced?1:24))return;last=now;
  const t=reduced?1:now/1000;
  g.imageSmoothingEnabled=false;
  g.fillStyle='#d7e6b4';g.fillRect(0,0,660,300);
  if(background.complete&&background.naturalWidth)g.drawImage(background,0,0,660,300);
  // Keep the existing runners and map art together on the game-room card.
  for(let i=0;i<6;i++) {
    const x=65+i*100+Math.sin(t*1.6+i)*8,y=186+(i%2)*35;
    g.fillStyle='#596b4b40';g.beginPath();g.ellipse(x+35,y+64,20,4,0,0,Math.PI*2);g.fill();
    const person={id:'preview-'+i,name:'',avatarId:avatars[i].id,paletteId:avatars[i].shirt};
    g.drawImage(sprite(person,Math.floor(t*12+i)%8),x,y,78,78);
  }
  olympics.draw({id:'preview',name:'',avatar:2,color:'#ee8c9a',ready:true,connected:true,total:0},null,null,t,'hurdles');
}
requestAnimationFrame(draw);
