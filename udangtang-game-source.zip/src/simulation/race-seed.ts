import type {Participant,Settings} from '../data/avatars.ts';
import {PIXELS_PER_METER,Race} from './engine.ts';

export type RaceSeedRequest = {
  participants:Participant[];
  distanceMeters:Settings['distanceMeters'];
  winnerRule:Settings['winnerRule'];
  lineup:string[];
  selectedId:string;
};

const MAX_STEPS = 60_000;

function scoreRace(request:RaceSeedRequest, seed:number, selectedIndex:number){
  const {participants,distanceMeters,winnerRule,lineup}=request;
  const race=new Race(participants,distanceMeters,seed,winnerRule,lineup);
  const selected=race.runners[selectedIndex];
  let wasContested=false;
  for(let step=0;step<MAX_STEPS;step++){
    race.step();
    // The rainbow event has its own guaranteed result and can hold runners at the finish.
    if(race.rainbowIndex!==null)return null;
    if(step%30===0&&selected.x>race.finishX*.5&&selected.x<race.finishX*.88){
      const gap=winnerRule==='first'
        ?Math.max(...race.runners.map(runner=>runner.x))-selected.x
        :selected.x-Math.min(...race.runners.map(runner=>runner.x));
      if(gap>PIXELS_PER_METER*2)wasContested=true;
    }
    if(winnerRule==='first'&&race.completedCount>0){
      const [winner,second]=race.rank();
      if(winner!==selected)return null;
      if(second.finishTime===null)continue;
      const gap=second.finishTime-winner.finishTime!;
      if(gap<=0)return null;
      return Math.abs(gap-.65)+(wasContested?0:1);
    }
    if(winnerRule==='last'){
      if(selected.finishTime!==null)return null;
      if(!race.finished)continue;
      if(race.lastPlaceIndex!==selectedIndex||race.tieOccurred)return null;
      const gap=(race.finishX-selected.x)/PIXELS_PER_METER;
      if(gap<1)return null;
      return Math.abs(gap-10)/10+(wasContested?0:1);
    }
  }
  return null;
}

export function findRaceSeed(
  request:RaceSeedRequest,
  candidates:Iterable<number>,
  readyToStart:(score:number)=>boolean=score=>score<=.55,
):number|null{
  const selectedIndex=request.participants.findIndex(participant=>participant.id===request.selectedId);
  if(selectedIndex<0)return null;
  let bestSeed:number|null=null;
  let bestScore=Infinity;
  for(const seed of candidates){
    const score=scoreRace(request,seed,selectedIndex);
    if(score!==null&&score<bestScore){
      bestSeed=seed;
      bestScore=score;
    }
    if(bestSeed!==null&&readyToStart(bestScore))break;
  }
  return bestSeed;
}
