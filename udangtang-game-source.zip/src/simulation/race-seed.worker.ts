import {findRaceSeed,type RaceSeedRequest} from './race-seed.ts';

function* candidateSeeds(deadline:number){
  const seeds=crypto.getRandomValues(new Uint32Array(512));
  for(const seed of seeds){
    if(performance.now()>=deadline)return;
    yield seed;
  }
}

self.addEventListener('message',(event:MessageEvent<RaceSeedRequest>)=>{
  const started=performance.now();
  const seed=findRaceSeed(event.data,candidateSeeds(started+18_000),score=>
    score<=.55||performance.now()-started>=3_000);
  self.postMessage(seed);
});
