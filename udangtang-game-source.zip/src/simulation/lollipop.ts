import {animals} from '../data/avatars.ts';

export const LOLLIPOP_ROUNDS=2;
export const CANDY_BOOST_SECONDS=4;
export const CANDY_SPEED_MULTIPLIER=4;
export const PASS_SECONDS=8;
export const STAMINA_SECONDS=10;
export const RIDE_SECONDS=7;

export const vehicles=[
  {id:'car',name:'자동차',pace:1.65},
  {id:'scooter',name:'킥보드',pace:1.35},
  {id:'bike',name:'자전거',pace:1.48},
] as const;
export type Vehicle=(typeof vehicles)[number];

export const lollipopRewards=[
  {id:'blank',label:'꽝',weight:17,individual:false},
  {id:'restart',label:'전원 출발선',weight:2,individual:false},
  {id:'pass',label:'장애물 프리패스',weight:14,individual:true},
  {id:'stamina',label:'무한 체력',weight:15,individual:true},
  {id:'swap',label:'1위 ↔ 꼴찌',weight:12,individual:false},
  {id:'ride',label:'탈것 타기',weight:14,individual:true},
  {id:'animal',label:'동물 변신',weight:10,individual:true},
  {id:'giant',label:'거대화',weight:6,individual:true},
  {id:'boost',label:'속도 4배',weight:10,individual:true},
] as const;

export type LollipopReward=(typeof lollipopRewards)[number]['id'];
export type Lollipop={round:number;winner:number;reward:LollipopReward;variant:number;at:number;resolved:boolean};

export function pickLollipopReward(roll:number):LollipopReward{
  let ticket=roll*100;
  for(const reward of lollipopRewards){
    ticket-=reward.weight;
    if(ticket<0)return reward.id;
  }
  return 'boost';
}

export function lollipopDescription({reward,variant}:Lollipop):string{
  switch(reward){
    case 'blank':return '꽝! 그대로 달려요.';
    case 'restart':return '모든 주자가 다시 출발선으로!';
    case 'pass':return `${PASS_SECONDS}초 동안 장애물을 통과해요!`;
    case 'stamina':return `${STAMINA_SECONDS}초 동안 체력이 100%로 유지돼요!`;
    case 'swap':return '1위와 꼴찌가 서로 자리를 바꿔요!';
    case 'ride':return `${RIDE_SECONDS}초 동안 ${vehicles[variant].name} 타고 달려요!`;
    case 'animal':return `${animals[variant].name} 모습으로 변신! 경기 끝까지 이 모습으로 달려요!`;
    case 'giant':return '거대화! 발을 디딜 때마다 다른 주자들이 잠깐 멈춰요.';
    case 'boost':return `${CANDY_BOOST_SECONDS}초간 체력과 관계없이 달리기 속도 ${CANDY_SPEED_MULTIPLIER}배!`;
  }
}

