import {animalAvatar,animals,type Animal,type Participant} from '../data/avatars.ts';
import {CANDY_BOOST_SECONDS,CANDY_SPEED_MULTIPLIER,PASS_SECONDS,RIDE_SECONDS,STAMINA_SECONDS,lollipopDescription,lollipopRewards,pickLollipopReward,vehicles,type Lollipop,type Vehicle} from './lollipop.ts';
export const STEP=1/60;
export const BASE_SPEED=187.5;
export const MIN_SPEED=150;
export const SPEED_RANGE=90;
export const PIXELS_PER_METER=10;
export const BOOST_SECONDS=5;
export const GIANT_CHANCE=.01;
export const RAINBOW_CHANCE=.001;
export const LANE_COUNT=7;
export const WALL_HEIGHT=112;
export type ObstacleType='puddle'|'mud'|'spinner'|'hammer'|'platform'|'spring'|'banana'|'hole'|'wall';
export type Obstacle={id:number;x:number;width:number;type:ObstacleType;phase:number;band?:{center:number;span:number}};
export type Status='running'|'frozen'|'fallen'|'splash'|'falling'|'pit-fall'|'banana-cry'|'sleeping'|'eating'|'drinking'|'phoning'|'grabbing'|'kicking'|'grabbed'|'launched'|'abducted'|'climbing'|'finished'|'crying';
export type Transport={kind:'spring'|'beam-forward'|'beam-back'|'kick-bump';from:number;to:number;started:number;duration:number;height:number;startZ:number};
export type Runner={
  participant:Participant;index:number;x:number;previousX:number;z:number;vz:number;
  speed:number;target:number;nextSpeed:number;rng:number;status:Status;until:number;
  protectUntil:number;handled:Set<number>;attempted:Set<number>;jumpAt:Map<number,number>;
  obstacleRetries:Map<number,'pending'|'skip'>;retryRng:number;
  tie:number;respawn:number;respawnAt:number;statusStarted:number;statusX:number;finishTime:number|null;transport:Transport|null;nextBreak:number;breakRng:number;
  stamina:number;boostUntil:number;speedBoost:number;
  lane:number;startLane:number;previousLane:number;laneTarget:number;nextLane:number;laneRng:number;
  damageAt:number;damageAmount:number;damageRng:number;
  rainbow:boolean;candyBoostUntil:number;finishHeld:boolean;gait:number;
  obstaclePassUntil:number;infiniteStaminaUntil:number;animal:Animal|null;ride:{kind:Vehicle;until:number}|null;
};
export type Impact={id:number;kind:'fall'|'respawn'|'roulette';runner:number;x:number;at:number};
export type RaceEvent={id:number;time:number;runner:number;text:string;kind:string};
export type Beam={index:number;mode:'forward'|'back';phase:'warning'|'moving'|'blocked';fire:number;end:number;catchUp?:boolean};
export type Contact={kind:'grab'|'kick';actor:number;target:number;started:number;hitAt:number;end:number;attempted:boolean;hit:boolean};
export type Giant={runner:number;started:number;end:number;nextStep:number;stompAt:number;stompUntil:number};
export type DuelOvertake={leader:number;trailer:number};
const widths:Record<ObstacleType,number>={puddle:64,mud:108,spinner:34,hammer:42,platform:92,spring:54,banana:26,hole:53,wall:66};
const types:ObstacleType[]=['puddle','mud','spinner','hammer','platform','spring','banana','hole'];
const mechanicalTypes=['spinner','platform','hammer'] as const;
const COURSE_SPACING=335;
const EXTRA_OBSTACLE_OFFSET=210;
const STOMP_INTERVAL=.73;
const CATCH_UP_GAP=50*PIXELS_PER_METER;
const CATCH_UP_BUFFER=7*PIXELS_PER_METER;
const MAX_CATCH_UP_DISTANCE=90*PIXELS_PER_METER;
const LOLLIPOP_PROGRESS=[.70,.85] as const;
export function hash(n:number):number{n=Math.imul(n^(n>>>16),0x21f0aaad);n=Math.imul(n^(n>>>15),0x735a2d97);return (n^(n>>>15))>>>0;}
export function seededRandom(state:number):[number,number]{const s=(state+0x6d2b79f5)>>>0;let t=Math.imul(s^(s>>>15),1|s);t^=t+Math.imul(t^(t>>>7),61|t);return [((t^(t>>>14))>>>0)/4294967296,s];}
function random(r:Runner){const [n,s]=seededRandom(r.rng);r.rng=s;return n;}
function breakRandom(r:Runner){const [n,s]=seededRandom(r.breakRng);r.breakRng=s;return n;}
export function actionBlend(age:number,remaining:number){
  const t=Math.max(0,Math.min(1,age/.34,remaining/.3));
  return t*t*(3-2*t);
}
function progress(elapsed:number,duration:number){
  const t=Math.max(0,Math.min(1,elapsed/duration));
  return t*t*(3-2*t);
}
function laneCenter(lane:number){return (lane+.5)/LANE_COUNT;}
function clampLane(lane:number){return Math.min(.94,Math.max(.06,lane));}
function laneBand(seed:number){
  const lanes=1+seed%3;
  const start=(seed>>>8)%(LANE_COUNT-lanes+1);
  return {center:(start+lanes/2)/LANE_COUNT,span:lanes/LANE_COUNT};
}
export function inObstacleBand(obstacle:Obstacle,lane:number){
  return !obstacle.band||Math.abs(lane-obstacle.band.center)<=obstacle.band.span/2;
}
export function staminaPace(stamina:number){return stamina>.5?1:.70+.16*stamina/.5;}
export class Race {
  seed:number;distanceMeters:number;finishX:number;winnerRule:'first'|'last';lastPlaceIndex:number|null=null;
  /** Real running time and physics clock. Arrival times decide the race; no time limit. */
  elapsed=0;worldTime=0;finished=false;runners:Runner[];events:RaceEvent[]=[];obstacles:Obstacle[]=[];
  nextUfo=8;ufo:{index:number;warn:number;fire:number;end:number}|null=null;
  nextBeam=14;beam:Beam|null=null;
  private nextCatchUp=0;
  private lastDuelLeader:number|null=null;
  duelOvertake:DuelOvertake|null=null;
  nextContact=6;contact:Contact|null=null;
  giant:Giant|null=null;rainbowIndex:number|null=null;rainbowStarted=-Infinity;lollipop:Lollipop|null=null;
  private giantAt:number;private rainbowAt:number;private wall:Obstacle|null;
  private contactKind:Contact['kind']='grab';private contactRng:number;
  impacts:Impact[]=[];private impactId=0;private rng:number;private eventId=0;private generated=0;
  private extraObstacles=0;
  result:Runner[]|null=null;tieOccurred=false;
  get completedCount(){return this.runners.filter(r=>r.finishTime!==null).length;}
  get lollipopRounds(){return this.distanceMeters<150?0:this.distanceMeters===300?1:LOLLIPOP_PROGRESS.length;}
  constructor(participants:Participant[],distanceMeters:number,seed:number,winnerRule:'first'|'last'='first',lineup:readonly string[]=[]){
    if(participants.length<2||participants.length>35||!Number.isFinite(distanceMeters)||distanceMeters<=0)throw new Error('참가자는 2~35명, 거리는 양수여야 합니다.');
    this.winnerRule=winnerRule;this.seed=seed>>>0;this.rng=hash(seed);this.distanceMeters=distanceMeters;this.finishX=distanceMeters*PIXELS_PER_METER;
    this.contactRng=hash(seed+105943);this.contactKind=this.contactRng%2===0?'grab':'kick';
    this.giantAt=hash(seed+193357)/2**32<GIANT_CHANCE?this.finishX*.33:Infinity;
    this.rainbowAt=hash(seed+721639)/2**32<RAINBOW_CHANCE?this.finishX*.56:Infinity;
    this.wall=distanceMeters>=150?{
      id:-1,x:Math.floor(this.finishX*.43/COURSE_SPACING)*COURSE_SPACING+208,
      width:widths.wall,type:'wall',phase:0,band:laneBand(hash(seed+37051)),
    }:null;
    if(this.wall)this.obstacles.push(this.wall);
    this.runners=participants.map((participant,index)=>{
      const slot=lineup.indexOf(participant.id),start=slot<0?index:slot;
      const rows=Math.min(10,participants.length);
      const lane=clampLane((start%rows+.5)/rows+(Math.floor(start/rows)%4-1.5)*.009);
      return {
      participant,index,x:0,previousX:0,z:0,vz:0,speed:BASE_SPEED,target:BASE_SPEED,nextSpeed:0,
      rng:hash(seed+index*92821+17),status:'running',until:0,protectUntil:0,
      handled:new Set(),attempted:new Set(),jumpAt:new Map(),tie:hash(seed+index*31991),respawn:0,respawnAt:-Infinity,statusStarted:0,statusX:0,finishTime:null,
      obstacleRetries:new Map(),retryRng:hash(seed+index*63737+16103),
      transport:null,nextBreak:12+hash(seed+index*13007)/4294967296*10,breakRng:hash(seed+index*7919+523),
      stamina:1,boostUntil:0,speedBoost:0,lane,startLane:lane,previousLane:lane,laneTarget:lane,nextLane:.6+hash(seed+index*837)/2**32,
      laneRng:hash(seed+index*7919+44601),damageAt:-Infinity,damageAmount:0,damageRng:hash(seed+index*17011+17863),
      rainbow:false,candyBoostUntil:0,finishHeld:false,gait:index*1.7,
      obstaclePassUntil:0,infiniteStaminaUntil:0,animal:animalAvatar(participant.avatarId),ride:null
    };});
    this.ensureCourse(2200);
  }
  private rand(){const [n,s]=seededRandom(this.rng);this.rng=s;return n;}
  private addCourseObstacle(type:ObstacleType,id:number,x:number,band:NonNullable<Obstacle['band']>,phase:number){
    const width=widths[type];
    if(x+width>this.finishX-160)return false;
    if(this.wall&&x<this.wall.x+this.wall.width+62&&x+width>this.wall.x-68)return false;
    this.obstacles.push({id,x,width,type,phase,band});
    return true;
  }
  private ensureCourse(end:number){
    while(320+this.generated*COURSE_SPACING<Math.min(end,this.finishX-160)){
      const slot=this.generated++,type=types[(slot+this.seed%types.length)%types.length];
      const baseX=320+slot*COURSE_SPACING;
      const mechanical=type==='spinner'||type==='platform'||type==='hammer';
      const count=type==='banana'?3:type==='hole'?2:1;
      for(let piece=0;piece<count;piece++){
        const id=slot*4+piece,shape=hash(this.seed+id*199);
        const x=baseX+piece*67+(count>1?shape%36:0);
        const row=((hash(this.seed+slot*311)>>>8)+piece*2)%LANE_COUNT;
        const band=mechanical?laneBand(shape):{center:laneCenter(row),span:type==='banana'?.105:type==='hole'?.22:.29};
        this.addCourseObstacle(type,id,x,band,shape/2**32*Math.PI*2);
      }
      // Fill the gap after the original group, including groups of three banana peels.
      const extraId=slot*4+3;
      const shape=hash(this.seed+extraId*199);
      const extraType=mechanicalTypes[(this.extraObstacles+this.seed%mechanicalTypes.length)%mechanicalTypes.length];
      if(this.addCourseObstacle(extraType,extraId,baseX+EXTRA_OBSTACLE_OFFSET,laneBand(shape),shape/2**32*Math.PI*2)){
        this.extraObstacles++;
      }
    }
  }
  rank():Runner[]{return [...this.runners].sort((a,b)=>{
    if(a.finishTime!==null&&b.finishTime!==null)return a.finishTime-b.finishTime||a.tie-b.tie;
    if(a.finishTime!==null)return -1;if(b.finishTime!==null)return 1;
    return b.x-a.x||a.tie-b.tie||a.index-b.index;
  });}
  private waitForRainbow(r:Runner,stepStart:number){
    if(this.rainbowIndex===null||r.rainbow)return false;
    const rainbow=this.runners[this.rainbowIndex];
    if(rainbow.finishTime!==null&&rainbow.finishTime<stepStart)return false;
    const otherFinishers=this.completedCount-Number(rainbow.finishTime!==null);
    return this.winnerRule==='first'||otherFinishers>=this.runners.length-2;
  }
  private recordArrival(r:Runner,realStart:number,realDt:number,worldStart:number,dt:number){
    if(r.finishTime!==null||r.x<this.finishX)return false;
    if(this.waitForRainbow(r,realStart)){
      r.x=this.finishX-.01;r.z=r.vz=0;r.transport=null;r.status='running';r.finishHeld=true;
      return true;
    }
    let fraction=(this.finishX-r.previousX)/Math.max(1e-12,r.x-r.previousX);
    const m=r.transport;
    if(m&&m.to>m.from&&this.finishX<=m.to){
      const position=(this.finishX-m.from)/(m.to-m.from);let lo=0,hi=1;
      for(let i=0;i<40;i++){const t=(lo+hi)/2;if(t*t*(3-2*t)<position)lo=t;else hi=t;}
      const cross=m.started+m.duration*(lo+hi)/2;fraction=(cross-worldStart)/dt;
    }
    r.finishTime=realStart+realDt*Math.max(0,Math.min(1,fraction));r.x=this.finishX;r.z=0;r.vz=0;
    r.transport=null;r.status='finished';r.statusStarted=this.worldTime;r.until=Infinity;
    this.event(r,'결승선을 통과했어요! 완주 축하해요!','finish');return true;
  }
  private event(r:Runner,text:string,kind:string){
    this.events.unshift({id:++this.eventId,time:this.elapsed,runner:r.index,text,kind});
    this.events.length=Math.min(12,this.events.length);
  }
  private damage(r:Runner){
    if(this.worldTime<r.infiniteStaminaUntil)return;
    const [roll,state]=seededRandom(r.damageRng);r.damageRng=state;
    r.damageAmount=10+Math.floor(roll*41);r.damageAt=this.worldTime;
    r.stamina=Math.max(0,r.stamina-r.damageAmount/100);
  }
  private markObstacleRetries(r:Runner,from:number,to:number){
    if(to>=from)return;
    for(const obstacle of this.obstacles){
      if(obstacle.type!=='wall'&&obstacle.x<=from&&to<obstacle.x+obstacle.width&&r.handled.has(obstacle.id)){
        r.obstacleRetries.set(obstacle.id,'pending');
      }
    }
  }
  private retryObstacle(r:Runner,obstacle:Obstacle){
    const [roll,state]=seededRandom(r.retryRng);r.retryRng=state;
    if(roll>=.5){r.obstacleRetries.set(obstacle.id,'skip');return false;}
    r.obstacleRetries.delete(obstacle.id);
    // Returning through a hazard has its own roll, even right after a respawn.
    r.protectUntil=Math.min(r.protectUntil,this.worldTime);
    return true;
  }
  private hitObstacle(r:Runner,obstacle:Obstacle){
    if(!this.canInterrupt(r))return false;
    switch(obstacle.type){
      case 'wall':return false;
      case 'spring':
        this.launch(r,'spring',-(170+random(r)*140),1.15);
        break;
      case 'mud':
        this.event(r,'진흙에 발이 묶여 속도가 줄었어요.','mud');
        break;
      case 'platform':
        this.stop(r,'falling',1.25,'발판을 놓쳐 체크포인트로 돌아갑니다.','platform');
        r.respawn=Math.max(0,Math.floor((obstacle.x-100)/900)*900);
        this.impacts.push({id:++this.impactId,kind:'fall',runner:r.index,x:r.x,at:this.worldTime});
        break;
      case 'puddle':
        this.stop(r,'splash',1+random(r)*2,'웅덩이에 풍덩! 잠시 쉬어갑니다.','puddle');
        break;
      case 'banana':
        this.stop(r,'banana-cry',1.9,'바나나 껍질을 밟고 미끄러져 엉엉 울어요!','banana');
        break;
      case 'hole':
        this.stop(r,'pit-fall',1.42,'구멍에 쏙! 반대편으로 기어 나와요.','pit');
        r.respawn=obstacle.x+obstacle.width+7;
        break;
      case 'spinner':
      case 'hammer':
        this.stop(r,'fallen',1+random(r),'장애물에 우당탕! 다시 일어납니다.',obstacle.type);
        if(obstacle.type==='hammer'){
          const destination=Math.max(0,r.x-24);
          this.markObstacleRetries(r,r.x,destination);
          r.x=destination;
        }
        break;
    }
    this.damage(r);
    return true;
  }
  private moveAcrossLanes(r:Runner,dt:number){
    if(this.worldTime>=r.nextLane){
      const [direction,state]=seededRandom(r.laneRng);
      const [delay,next]=seededRandom(state);r.laneRng=next;
      r.laneTarget=clampLane(r.lane+(direction-.5)*.72);
      r.nextLane=this.worldTime+1.15+delay*1.85;
    }
    if(r.z===0&&this.worldTime>=r.obstaclePassUntil){
      const threat=this.obstacles.find(o=>{
        if(!o.band||r.handled.has(o.id)||o.x<r.x-3||!inObstacleBand(o,r.laneTarget))return false;
        const reaction=hash(this.seed+r.index*991+o.id*997)/2**32;
        return reaction<.74&&o.x-r.x<26+reaction*132;
      });
      if(threat?.band){
        const {center,span}=threat.band;
        const choices=[center-span/2-.11,center+span/2+.11].filter(lane=>lane>=.06&&lane<=.94);
        choices.sort((a,b)=>Math.abs(r.lane-a)-Math.abs(r.lane-b));
        if(choices.length)r.laneTarget=choices[0];
      }
    }
    const rate=dt*(r.z>0?.26:.70);
    r.lane+=Math.max(-rate,Math.min(rate,(r.laneTarget-r.lane)*dt*6.5));
  }
  private startClimb(r:Runner){
    const wall=this.wall;
    if(!wall||!this.obstacles.includes(wall)||r.handled.has(wall.id)||
      r.previousX>wall.x+wall.width||r.x<wall.x-7||!inObstacleBand(wall,r.lane))return false;
    r.handled.add(wall.id);
    if(this.worldTime<r.obstaclePassUntil)return false;
    r.transport=null;r.z=0;r.vz=0;r.status='climbing';
    r.x=r.statusX=Math.max(wall.x-7,Math.min(r.previousX,wall.x+wall.width));
    r.respawn=wall.x+wall.width+8;r.statusStarted=this.worldTime;
    r.until=this.worldTime+1.9+hash(this.seed+r.index*881)/2**32*.5;
    this.event(r,'거대한 벽을 발견했어요! 손발을 써서 올라가는 중.','wall');
    return true;
  }
  private releaseRunner(r:Runner){
    if(this.contact&&(this.contact.actor===r.index||this.contact.target===r.index))this.contact=null;
    if(this.beam?.index===r.index)this.beam=null;
    if(this.ufo?.index===r.index)this.ufo=null;
    r.transport=null;r.z=r.vz=0;r.status='running';r.finishHeld=false;
    r.statusStarted=r.until=r.protectUntil=this.worldTime;r.statusX=r.x;
    r.respawnAt=-Infinity;
  }
  private moveForLollipop(r:Runner,x:number,lane:number){
    r.x=r.previousX=x;r.lane=r.previousLane=r.laneTarget=lane;
    this.releaseRunner(r);
    r.respawn=x;r.damageAt=-Infinity;
    this.impacts.push({id:++this.impactId,kind:'roulette',runner:r.index,x,at:this.worldTime});
    this.lastDuelLeader=null;this.duelOvertake=null;
  }
  private startGiant(r:Runner){
    const now=this.worldTime;
    r.gait=4-4*.43/STOMP_INTERVAL;
    this.giant={runner:r.index,started:now,end:now+6.1,nextStep:now+.43,stompAt:-Infinity,stompUntil:0};
  }
  resolveLollipop(){
    const draw=this.lollipop;
    if(!draw||draw.resolved||this.finished)return;
    draw.resolved=true;
    const winner=this.runners[draw.winner],now=this.worldTime;
    switch(draw.reward){
      case 'blank':break;
      case 'restart':
        this.impacts=[];this.giant=null;
        for(const r of this.runners){
          r.handled.clear();r.attempted.clear();r.jumpAt.clear();r.obstacleRetries.clear();
          this.moveForLollipop(r,0,r.startLane);
        }
        break;
      case 'swap':{
        const order=this.rank(),first=order[0],last=order[order.length-1];
        const {x,lane}=first;
        this.markObstacleRetries(first,x,last.x);
        if(this.wall&&last.x<this.wall.x-7)first.handled.delete(this.wall.id);
        this.moveForLollipop(first,last.x,last.lane);
        this.moveForLollipop(last,x,lane);
        break;
      }
      case 'pass':
        winner.obstaclePassUntil=now+PASS_SECONDS;
        if(['fallen','falling','splash','pit-fall','banana-cry','climbing','launched'].includes(winner.status))this.releaseRunner(winner);
        break;
      case 'stamina':
        winner.stamina=1;winner.infiniteStaminaUntil=now+STAMINA_SECONDS;winner.damageAt=-Infinity;
        if(winner.status==='sleeping')this.releaseRunner(winner);
        break;
      case 'ride':
        this.releaseRunner(winner);
        winner.ride={kind:vehicles[draw.variant],until:now+RIDE_SECONDS};
        break;
      case 'animal':
        this.releaseRunner(winner);
        winner.animal=animals[draw.variant];
        break;
      case 'giant':
        this.releaseRunner(winner);
        this.startGiant(winner);
        break;
      case 'boost':
        winner.candyBoostUntil=now+CANDY_BOOST_SECONDS;
        if(winner.status==='sleeping')this.releaseRunner(winner);
        break;
    }
    const individual=lollipopRewards.find(reward=>reward.id===draw.reward)!.individual;
    this.event(winner,lollipopDescription(draw),individual?'lollipop-win':'lollipop-global');
  }
  isStompFrozen(index:number){return !!this.giant&&index!==this.giant.runner&&this.worldTime<this.giant.stompUntil;}
  private updateFestival(){
    if(this.distanceMeters<150||this.worldTime<3||this.completedCount)return;
    const lead=Math.max(...this.runners.map(r=>r.x));
    const round=this.lollipop?.round??0;
    if(round<this.lollipopRounds&&lead>=this.finishX*LOLLIPOP_PROGRESS[round]){
      const salt=round*169313;
      const winner=hash(this.seed+533509+salt)%this.runners.length;
      const reward=pickLollipopReward(hash(this.seed+684701+salt)/2**32);
      const variant=hash(this.seed+295889+salt)%(reward==='ride'?vehicles.length:animals.length);
      this.lollipop={round:round+1,winner,reward,variant,at:this.worldTime,resolved:false};
      this.event(this.runners[winner],'갑자기 누군가 막대사탕을 던졌다!','lollipop');
      return;
    }
    if(!this.giant&&lead>=this.giantAt){
      const ready=this.runners.filter(r=>this.canInterrupt(r)&&r.z===0);
      if(ready.length){
        const runner=ready[hash(this.seed+318911)%ready.length];
        this.giantAt=Infinity;
        this.startGiant(runner);
        this.event(runner,'거대화! 발을 디딜 때마다 다른 주자들이 잠깐 멈춰요.','giant');
      }
    }
    if(lead>=this.rainbowAt){
      const runner=this.runners[hash(this.seed+729791)%this.runners.length];
      this.rainbowAt=Infinity;this.rainbowIndex=runner.index;this.rainbowStarted=this.worldTime;runner.rainbow=true;
      this.event(runner,this.winnerRule==='first'?'무지개 변신! 이번 경기의 1등이 확정됐어요.':'무지개 변신! 이번 경기에서는 꼴찌가 되지 않아요.','rainbow');
    }
  }
  private updateStomp(dt:number){
    const giant=this.giant;
    if(!giant)return false;
    if(this.worldTime>=giant.end){this.giant=null;return false;}
    if(this.worldTime>=giant.nextStep&&this.runners[giant.runner].status==='running'){
      giant.nextStep=this.worldTime+STOMP_INTERVAL;giant.stompAt=this.worldTime;giant.stompUntil=this.worldTime+.41;
    }
    if(this.worldTime>=giant.stompUntil)return false;
    this.nextContact+=dt;this.nextUfo+=dt;this.nextBeam+=dt;this.nextCatchUp+=dt;
    if(this.contact){this.contact.started+=dt;this.contact.hitAt+=dt;this.contact.end+=dt;}
    if(this.ufo){this.ufo.fire+=dt;this.ufo.end+=dt;}
    if(this.beam){this.beam.fire+=dt;this.beam.end+=dt;}
    return true;
  }
  private freezeForStomp(r:Runner,dt:number){
    r.until+=dt;r.statusStarted+=dt;r.nextBreak+=dt;r.nextLane+=dt;r.nextSpeed+=dt;
    r.protectUntil+=dt;r.boostUntil+=dt;r.respawnAt+=dt;r.damageAt+=dt;
    if(r.transport)r.transport.started+=dt;
  }
  private runningPace(r:Runner,candyShare:number){
    const boost=this.worldTime<r.boostUntil?1+r.speedBoost:1;
    const ride=r.ride&&this.worldTime<r.ride.until?r.ride.kind.pace:1;
    const ordinary=staminaPace(r.stamina)*boost*(r.rainbow?1.55:1)*ride;
    return ordinary*(1-candyShare)+CANDY_SPEED_MULTIPLIER*candyShare;
  }
  private canInterrupt(r:Runner){return this.worldTime>=r.protectUntil&&r.status==='running';}
  private stop(r:Runner,status:Status,seconds:number,text:string,kind:string){
    if(!this.canInterrupt(r))return false;
    r.status=status;r.statusStarted=this.worldTime;r.statusX=r.x;r.until=this.worldTime+seconds;r.z=0;r.vz=0;this.event(r,text,kind);return true;
  }
  private launch(r:Runner,kind:Transport['kind'],shift:number,duration:number,message?:string){
    if(!this.canInterrupt(r))return false;
    r.transport={kind,from:r.x,to:Math.max(0,r.x+shift),started:this.worldTime,duration,height:kind==='spring'?88:kind==='kick-bump'?24:115,startZ:r.z};
    r.status=kind==='spring'||kind==='kick-bump'?'launched':'abducted';r.statusStarted=this.worldTime;r.until=this.worldTime+duration;r.vz=0;
    if(kind==='kick-bump')return true;
    const text=kind==='spring'?'점프대가 반대로 튕겼어요! 뒤로 슈웅!':kind==='beam-forward'?'견인 광선에 잡혀 앞으로 슈우웅!':'견인 광선에 잡혀 뒤로 끌려갑니다!';
    this.event(r,message??text,kind);return true;
  }
  private updateContact(){
    const now=this.worldTime;
    if(this.contact){
      const c=this.contact;
      if(now>=c.end){this.contact=null;return;}
      if(c.attempted||now<c.hitAt)return;
      c.attempted=true;
      const actor=this.runners[c.actor],target=this.runners[c.target];
      const gap=target.x-actor.x;
      if(actor.finishTime!==null||!this.canInterrupt(target)||target.z!==0||gap<3||gap>52||Math.abs(actor.lane-target.lane)>.29)return;
      c.hit=true;
      if(c.kind==='grab'){
        target.status='grabbed';target.statusStarted=now;target.until=c.end;
        this.event(actor,`${target.participant.name}의 옷자락을 잡아 속도를 늦췄어요!`,'grab');
      }else{
        this.launch(target,'kick-bump',55,.42);
        this.event(actor,`${target.participant.name}에게 장난 발차기! 휘청!`,'kick');
      }
      return;
    }
    if(now<this.nextContact)return;
    const ready=this.runners.filter(r=>this.canInterrupt(r)&&r.z===0&&r.vz===0&&r.x>145&&r.x<this.finishX-150);
    const pairs:{actor:Runner;target:Runner}[]=[];
    for(const actor of ready)for(const target of ready){
      const gap=target.x-actor.x;
      if(gap<12||gap>32||Math.abs(actor.lane-target.lane)>.23)continue;
      if(this.obstacles.some(o=>o.x+o.width>actor.x-10&&o.x<target.x+130))continue;
      pairs.push({actor,target});
    }
    if(!pairs.length){this.nextContact=now+.55;return;}
    const [n,seed]=seededRandom(this.contactRng);this.contactRng=seed;
    const {actor,target}=pairs[Math.floor(n*pairs.length)];
    const kind=this.contactKind;
    this.contactKind=kind==='grab'?'kick':'grab';
    this.nextContact=now+4.6+n*2.7;
    const end=now+(kind==='grab'?1.04:.83);
    this.contact={kind,actor:actor.index,target:target.index,started:now,hitAt:now+.37,end,attempted:false,hit:false};
    actor.status=kind==='grab'?'grabbing':'kicking';actor.statusStarted=now;actor.until=end;
  }
  private catchUpTarget(active:Runner[]){
    if(active.length<2)return null;
    let [last,ahead]=active;
    if(last.x>ahead.x)[last,ahead]=[ahead,last];
    for(let i=2;i<active.length;i++){
      const runner=active[i];
      if(runner.x<last.x){ahead=last;last=runner;}
      else if(runner.x<ahead.x)ahead=runner;
    }
    const gap=ahead.x-last.x;
    return gap>=CATCH_UP_GAP?{runner:last,gap}:null;
  }
  private updateDuelOvertake(){
    if(this.completedCount!==this.runners.length-2){this.lastDuelLeader=null;return;}
    const [a,b]=this.runners.filter(r=>r.finishTime===null);
    if(Math.abs(a.x-b.x)<1e-6)return;
    const [leader,trailer]=a.x>b.x?[a,b]:[b,a];
    if(this.lastDuelLeader!==null&&this.lastDuelLeader!==leader.index){
      this.duelOvertake={leader:leader.index,trailer:trailer.index};
      this.event(leader,'마지막 두 주자의 순위가 바뀌었어요!','duel-overtake');
    }
    this.lastDuelLeader=leader.index;
  }
  private updateSkyEvents(){
    const active=this.runners.filter(r=>r.finishTime===null);if(!active.length)return;
    const catchUp=this.nextBeam===Infinity?null:this.catchUpTarget(active);
    if(this.ufo&&this.worldTime>=this.ufo.fire&&this.ufo.warn===1){
      const r=this.runners[this.ufo.index];
      if(r!==catchUp?.runner&&!this.stop(r,'frozen',2+this.rand()*2,'UFO 광선에 꽁꽁 얼었어요!','ufo'))this.event(r,'보호 중이라 냉동 광선을 피했어요.','ufo-blocked');
      this.ufo.warn=0;
    }
    if(this.ufo&&this.worldTime>=this.ufo.end)this.ufo=null;
    if(this.worldTime>=this.nextUfo&&!this.ufo){
      const targets=catchUp?active.filter(r=>r!==catchUp.runner):active;
      const index=targets[Math.floor(this.rand()*targets.length)].index;
      this.ufo={index,warn:1,fire:this.worldTime+1.3,end:this.worldTime+5.3};
      this.nextUfo=this.worldTime+10+this.rand()*8;
      this.event(this.runners[index],'머리 위에 UFO가 나타났어요!','ufo');
    }
    if(this.beam&&this.worldTime>=this.beam.fire&&this.beam.phase==='warning'){
      const beam=this.beam,runner=this.runners[beam.index];
      if(beam.catchUp){
        const duration=1.35;
        const accepted=catchUp?.runner===runner&&this.launch(runner,'beam-forward',
          Math.min(MAX_CATCH_UP_DISTANCE,catchUp.gap-CATCH_UP_BUFFER),duration,'추격 광선에 올라 앞 주자에게 가까워졌어요!');
        beam.phase=accepted?'moving':'blocked';beam.end=this.worldTime+(accepted?duration:.3);
        this.nextCatchUp=this.worldTime+(accepted?3.5:.6);
      }else{
        const duration=1.8+this.rand()*.5,distance=240+this.rand()*140;
        const accepted=(beam.mode!=='back'||runner!==catchUp?.runner)&&this.launch(runner,
          beam.mode==='forward'?'beam-forward':'beam-back',beam.mode==='forward'?distance:-distance,duration);
        beam.phase=accepted?'moving':'blocked';beam.end=this.worldTime+(accepted?duration:.8);
        if(!accepted)this.event(runner,'보호 중이라 견인 광선을 피했어요.','beam-blocked');
      }
    }
    if(this.beam&&this.worldTime>=this.beam.end)this.beam=null;
    if(this.beam)return;
    if(catchUp){
      if(this.worldTime>=this.nextCatchUp&&this.canInterrupt(catchUp.runner)){
        const fire=this.worldTime+.65;
        this.beam={index:catchUp.runner.index,mode:'forward',phase:'warning',fire,end:fire+1,catchUp:true};
        this.event(catchUp.runner,'50m 이상 뒤처진 주자에게 추격 광선이 나타났어요!','catch-up');
      }
      return;
    }
    if(this.worldTime>=this.nextBeam){
      const index=active[Math.floor(this.rand()*active.length)].index;const mode=this.rand()<.5?'back':'forward';
      this.beam={index,mode,phase:'warning',fire:this.worldTime+1,end:this.worldTime+4};
      this.nextBeam=this.worldTime+13+this.rand()*7;
      this.event(this.runners[index],mode==='forward'?'앞으로 보내는 견인 광선이 나타났어요!':'뒤로 당기는 견인 광선이 나타났어요!','beam-warning');
    }
  }
  step(requested=STEP){
    if(this.finished)return;
    const realDt=requested;if(!Number.isFinite(realDt)||realDt<=0)return;
    this.resolveLollipop();
    const realStart=this.elapsed,worldStart=this.worldTime;const dt=realDt;
    this.elapsed+=realDt;this.worldTime+=dt;
    this.impacts=this.impacts.filter(i=>this.worldTime-i.at<1.1);
    this.ensureCourse(Math.max(...this.runners.map(r=>r.x))+1800);
    const stomp=this.updateStomp(dt);
    if(!stomp)this.updateSkyEvents();
    for(const r of this.runners){
      r.previousX=r.x;r.previousLane=r.lane;
      if(r.finishTime!==null)continue;
      if(stomp&&this.isStompFrozen(r.index)){this.freezeForStomp(r,dt);continue;}
      const candyTime=Math.min(dt,r.candyBoostUntil-worldStart);
      const candyShare=candyTime>1e-9?candyTime/dt:0;
      if(r.finishHeld){
        if(this.waitForRainbow(r,realStart))continue;
        r.finishHeld=false;
      }
      if(r.transport){
        const m=r.transport;const t=Math.max(0,Math.min(1,(this.worldTime-m.started)/m.duration));
        const ease=t*t*(3-2*t);r.x=m.from+(m.to-m.from)*ease;r.z=m.startZ*(1-t)+Math.sin(t*Math.PI)*m.height;
        if(this.startClimb(r))continue;
        if(this.recordArrival(r,realStart,realDt,worldStart,dt))continue;
        if(t>=1-1e-9){
          this.markObstacleRetries(r,m.from,m.to);
          r.x=m.to;r.z=0;r.transport=null;
          if(m.kind==='kick-bump'){r.status='fallen';r.statusStarted=this.worldTime;r.until=this.worldTime+.9;}
          else{r.status='running';r.protectUntil=this.worldTime+1;}
        }
        continue;
      }
      if(r.status!=='running'){
        if(this.worldTime<r.until){
          const age=this.worldTime-r.statusStarted,remaining=r.until-this.worldTime;
          if(r.status==='climbing'){
            const t=age/(r.until-r.statusStarted);
            r.x=r.statusX+(r.respawn-r.statusX)*progress(t-.49,.35);
            r.z=WALL_HEIGHT*progress(t,.51)*(1-progress(t-.78,.22));
          }else if(r.status==='pit-fall'){
            r.x=r.statusX+(r.respawn-r.statusX)*progress(age-.34,.83);
          }else if(r.status==='banana-cry'){
            r.x=r.statusX+24*progress(age,.39);
          }else if(r.status==='sleeping'){
            r.stamina=progress(age-.36,r.until-r.statusStarted-.68);
          }else if(r.status==='eating'||r.status==='drinking'||r.status==='phoning'||r.status==='grabbed'){
            const blend=actionBlend(age,remaining);
            const actionPace=r.status==='phoning'?.35:r.status==='grabbed'?.31:0;
            r.x+=r.speed*this.runningPace(r,candyShare)*(1-(1-actionPace)*blend)*dt;
            if(this.startClimb(r))continue;
            this.recordArrival(r,realStart,realDt,worldStart,dt);
          }else if((r.status==='grabbing'||r.status==='kicking')&&this.contact?.actor===r.index){
            const blend=actionBlend(age,remaining);
            const c=this.contact;
            const target=this.runners[c.target];
            const approach=Math.max(r.speed*.48,Math.min(r.speed*1.45,target.speed+(target.x-r.x-20)*5));
            const speed=c.kind==='grab'&&c.hit?Math.min(r.speed,target.speed)*.33:approach;
            r.x+=(r.speed+(speed-r.speed)*blend)*this.runningPace(r,candyShare)*dt;
            if(c.kind==='kick')r.z=Math.sin(Math.PI*age/(c.end-c.started))*34;
            if(this.startClimb(r))continue;
            this.recordArrival(r,realStart,realDt,worldStart,dt);
          }
          continue;
        }
        if(r.status==='falling'){
          this.markObstacleRetries(r,r.x,r.respawn);
          r.x=r.respawn;r.previousX=r.x;r.respawnAt=this.worldTime;
          this.impacts.push({id:++this.impactId,kind:'respawn',runner:r.index,x:r.x,at:this.worldTime});
          this.event(r,'체크포인트에서 번쩍! 다시 달려요.','respawn');
        }
        if(r.status==='pit-fall'||r.status==='climbing')r.x=r.respawn;
        if(r.status==='sleeping'){
          r.stamina=1;r.boostUntil=0;
          this.event(r,'푹 자고 체력을 회복했어요!','wake');
        }
        if(r.status==='eating'||r.status==='drinking'){
          r.stamina=1;r.speedBoost=.1+breakRandom(r)*.1;r.boostUntil=this.worldTime+BOOST_SECONDS;
          this.event(r,`체력 충전! 5초 동안 ${Math.round(r.speedBoost*100)}% 더 빠르게 달려요.`,'boost');
        }
        r.status='running';r.statusStarted=this.worldTime;r.protectUntil=this.worldTime+1;r.z=0;r.vz=0;
      }
      const giant=this.giant?.runner===r.index;
      const pass=this.worldTime<r.obstaclePassUntil;
      const riding=r.ride&&this.worldTime<r.ride.until;
      if(!giant&&!candyShare&&r.stamina===0&&r.z===0&&r.vz===0&&this.stop(r,'sleeping',2.8,'체력이 바닥나 침대에서 잠들었어요.','sleep'))continue;
      if(!giant&&!candyShare&&this.worldTime>=r.nextBreak&&this.canInterrupt(r)&&r.z===0&&r.x<this.finishX-145&&
        !this.obstacles.some(o=>o.x+o.width>r.x-4&&o.x<r.x+190)){
        const roll=breakRandom(r),action=roll<.5?'eating':roll<.74?'drinking':'phoning';
        const duration=action==='eating'?2.4+breakRandom(r)*1.6:action==='drinking'?1.3+breakRandom(r):2+breakRandom(r)*.8;
        r.nextBreak=this.worldTime+22+breakRandom(r)*17;
        if(action==='eating')this.stop(r,action,duration,'배가 고파서 도시락을 먹고 있어요.','meal');
        else if(action==='drinking')this.stop(r,action,duration,'잠깐! 시원한 음료 한 모금!','drink');
        else this.stop(r,action,duration,'전화가 왔어요! 속도를 줄이고 통화 중이에요.','phone');
        continue;
      }
      if(this.worldTime>=r.nextSpeed){r.target=MIN_SPEED+random(r)*SPEED_RANGE;r.nextSpeed=this.worldTime+1.2+random(r)*2.3;}
      r.speed+=(r.target-r.speed)*Math.min(1,dt*2.2);
      this.moveAcrossLanes(r,dt);
      let factor=1;
      for(const o of this.obstacles){
        if(pass||giant||r.rainbow||o.type==='wall'||o.x+o.width+10<r.x||o.x-190>r.x)continue;
        if(o.type==='mud'){
          if(r.x>=o.x&&r.x<=o.x+o.width&&r.z<4&&inObstacleBand(o,r.lane)){
            const retry=r.obstacleRetries.get(o.id);
            if(retry==='skip')continue;
            const hit=retry==='pending'?this.retryObstacle(r,o):!r.handled.has(o.id);
            if(retry==='pending'&&!hit)continue;
            factor=.5;
            if(hit&&this.hitObstacle(r,o))r.handled.add(o.id);
          }
          continue;
        }
        if(riding||o.type==='spring'||r.handled.has(o.id)||!inObstacleBand(o,r.lane)&&!inObstacleBand(o,r.laneTarget))continue;
        if(!r.jumpAt.has(o.id)&&o.x-r.x<185)r.jumpAt.set(o.id,o.x-(27+random(r)*80));
        if(!r.attempted.has(o.id)&&r.x>=(r.jumpAt.get(o.id)??Infinity)&&r.z===0){r.attempted.add(o.id);r.vz=245+random(r)*90;}
      }
      if(r.z>0||r.vz>0){r.vz-=700*dt;r.z=Math.max(0,r.z+r.vz*dt);if(r.z===0)r.vz=0;}
      const boosted=this.worldTime<r.boostUntil;
      if(!boosted&&!giant&&this.worldTime>=r.infiniteStaminaUntil)r.stamina=Math.max(0,r.stamina-dt*.022);
      const pace=this.runningPace(r,candyShare);
      const cadence=Math.max(14,Math.min(36,r.speed/7));
      r.gait+=(giant?4/STOMP_INTERVAL:cadence*Math.min(1.35,pace)*(r.stamina<=.5&&!candyShare?.67:1))*dt;
      r.x+=r.speed*factor*pace*dt;
      if(this.startClimb(r))continue;
      if(this.recordArrival(r,realStart,realDt,worldStart,dt))continue;
      for(const o of this.obstacles){
        const retry=r.obstacleRetries.get(o.id)==='pending';
        if(pass||giant||r.rainbow||r.handled.has(o.id)&&!retry||o.type==='wall'||o.type==='mud'||r.x<o.x||r.previousX>o.x+o.width)continue;
        if(r.x>o.x+o.width){r.handled.add(o.id);continue;}
        if(!inObstacleBand(o,r.lane))continue;
        if(retry){
          if(r.z<8&&this.retryObstacle(r,o)&&this.hitObstacle(r,o))break;
          continue;
        }
        if(o.type==='spring'){
          if(r.z<8){r.handled.add(o.id);if(random(r)<.7&&this.hitObstacle(r,o))break;}
          continue;
        }
        let hit=false;
        if(o.type==='puddle')hit=r.z<5;
        if(o.type==='banana')hit=r.z<4;
        if(o.type==='hole')hit=r.z<5;
        if(o.type==='spinner')hit=r.z<20+Math.max(0,Math.sin(this.worldTime*3+o.phase))*23;
        if(o.type==='hammer')hit=r.z<35&&Math.sin(this.worldTime*3.6+o.phase)>.15;
        if(o.type==='platform'){
          const center=o.x+o.width/2+Math.sin(this.worldTime*1.8+o.phase)*27;
          hit=r.z<4&&Math.abs(r.x-center)>18;
        }
        if(hit){
          r.handled.add(o.id);
          if(this.hitObstacle(r,o))break;
        }
      }
    }
    const wall=this.wall;
    const waitingForClimb=wall&&this.obstacles.includes(wall)&&this.runners.some(r=>
      r.finishTime===null&&(r.status==='climbing'||!r.handled.has(wall.id)&&r.x<wall.x-7&&inObstacleBand(wall,r.lane)));
    if(this.winnerRule==='last'&&this.completedCount>=this.runners.length-1&&!waitingForClimb){
      const ranked=this.rank();const last=ranked[ranked.length-1];
      const priorCutoff=ranked[ranked.length-2].finishTime!;
      const cutoff=priorCutoff<realStart?this.elapsed:priorCutoff;
      this.tieOccurred=last.finishTime!==null&&last.finishTime===cutoff;
      const fraction=Math.max(0,Math.min(1,(cutoff-realStart)/realDt));
      let x=last.previousX+(last.x-last.previousX)*fraction;
      if(last.finishTime!==null){const crossFraction=Math.max(1e-12,(last.finishTime-realStart)/realDt);x=last.previousX+(this.finishX-last.previousX)*Math.min(1,fraction/crossFraction);}
      else if(last.transport){const m=last.transport,t=Math.max(0,Math.min(1,(worldStart+dt*fraction-m.started)/m.duration));x=m.from+(m.to-m.from)*t*t*(3-2*t);}
      last.x=Math.max(0,Math.min(this.finishX-1e-6,x));last.previousX=last.x;last.finishTime=null;
      last.z=last.vz=0;last.transport=null;last.status='crying';last.until=Infinity;
      this.lastPlaceIndex=last.index;this.elapsed=cutoff;this.worldTime=worldStart+dt*fraction;last.statusStarted=this.worldTime;
      this.event(last,'꼴찌 확정! 그 자리에서 눈물이 뚝뚝…','last-place');this.finish();
    }else if(this.completedCount===this.runners.length){
      this.elapsed=Math.max(...this.runners.map(r=>r.finishTime!));
      this.worldTime=worldStart+(this.elapsed-realStart)*(dt/realDt);this.finish();
    }else{
      this.updateDuelOvertake();
      this.updateFestival();
      if(!stomp&&!this.giant)this.updateContact();
    }
  }
  private finish(){if(this.finished)return;this.finished=true;this.result=this.rank();this.tieOccurred=this.tieOccurred||this.result.some((r,i,a)=>i>0&&r.finishTime!==null&&r.finishTime===a[i-1].finishTime);this.ufo=null;this.beam=null;this.contact=null;this.giant=null;this.impacts=[];}
}
