import type {Animal} from '../data/avatars.ts';
import type {Vehicle} from '../simulation/lollipop.ts';

const ink='#3c3946';

export function drawAnimal(g:CanvasRenderingContext2D,kind:Animal['id'],gait:number,moving:boolean){
  const step=moving?Math.sin(gait*Math.PI/2):0;
  const hop=moving?Math.round(Math.abs(step)*(kind==='rabbit'?6:3)):0;
  const coat=kind==='rabbit'?'#bcb9d6':kind==='fox'?'#e88a4f':'#f5cb5d';
  const light=kind==='rabbit'?'#f1edf6':kind==='fox'?'#ffe7c0':'#ffed9a';
  const rect=(x:number,y:number,w:number,h:number,color:string)=>{g.fillStyle=color;g.fillRect(Math.round(x),Math.round(y-hop),w,h);};
  const rear=Math.round(step*5),front=-rear;
  if(kind==='fox'){
    rect(-28,-22,12,12,ink);rect(-32,-26,10,10,ink);
    rect(-30,-24,9,7,light);rect(-24,-20,11,7,coat);
  }else if(kind==='rabbit'){
    rect(-24,-15,9,8,ink);rect(-22,-14,7,5,light);
  }else{
    rect(-24,-17,9,8,ink);rect(-22,-16,8,5,light);
  }
  const paw=kind==='duck'?'#ed9749':light;
  rect(-14+rear,-9,9,8,ink);rect(4+front,-9,8,8,ink);
  rect(-12+rear,-7,7,4,paw);rect(5+front,-7,6,4,paw);
  rect(-18,-19,33,14,ink);rect(-15,-20,25,13,coat);rect(-8,-11,20,4,light);
  if(kind==='rabbit'){
    rect(4,-38,6,17,ink);rect(12,-42,7,21,ink);
    rect(6,-36,3,13,'#e9a5ba');rect(14,-40,3,16,'#efb1c2');
  }else if(kind==='fox'){
    rect(2,-34,6,12,ink);rect(14,-36,6,11,ink);
    rect(4,-31,4,7,coat);rect(16,-33,3,8,coat);
  }else{
    rect(5,-33,10,7,ink);rect(7,-32,7,5,light);rect(-13,-16,15,6,'#f6b652');
  }
  rect(0,-29,21,19,ink);rect(2,-27,17,14,coat);rect(10,-19,10,6,light);
  rect(13,-25,3,4,ink);rect(13,-25,1,1,'#fff8e4');
  if(kind==='duck'){
    rect(19,-21,10,7,ink);rect(19,-20,8,4,'#f89b43');
  }else{
    rect(19,-19,6,5,ink);rect(18,-18,4,3,light);rect(22,-19,3,2,kind==='fox'?ink:'#d97891');
  }
  return (kind==='rabbit'?42:kind==='fox'?36:33)+hop;
}

export function drawRide(g:CanvasRenderingContext2D,kind:Vehicle['id'],rider:HTMLCanvasElement,gait:number,animalRider=false){
  const bounce=Math.round(Math.sin(gait*Math.PI/2));
  const rect=(x:number,y:number,w:number,h:number,color:string)=>{g.fillStyle=color;g.fillRect(x,y,w,h);};
  const wheel=(x:number,y:number,size:number)=>{
    rect(x-size,y-size+2,size*2,size*2-4,ink);rect(x-size+2,y-size,size*2-4,size*2,ink);
    rect(x-2,y-2,4,4,'#bec6d4');
    const angle=gait*.7;
    rect(x+Math.round(Math.cos(angle)*(size-3))-1,y+Math.round(Math.sin(angle)*(size-3))-1,2,2,'#f9edcc');
  };
  if(kind==='car'){
    if(animalRider)g.drawImage(rider,-29,-65+bounce,55,55);
    else g.drawImage(rider,14,4,37,35,-16,-47+bounce,37,35);
    rect(-25,-18,54,15,ink);rect(-18,-24,33,10,ink);
    rect(-23,-16,50,11,'#c84c67');rect(-16,-22,31,7,'#ef8c86');
    rect(-11,-21,24,5,'#819cae');rect(-9,-21,9,2,'#cfe7e6');
    rect(20,-14,7,5,'#fff0ab');rect(-22,-14,5,4,'#f9b570');rect(-7,-10,23,2,'#f6a4a0');
    wheel(-14,-5,6);wheel(18,-5,6);
    return 46-bounce;
  }
  const bike=kind==='bike',front=bike?22:20,rear=bike?-19:-17,size=bike?9:6;
  wheel(rear,-size,size);wheel(front,-size,size);
  g.strokeStyle=bike?'#d36f68':'#6bc4a7';g.lineWidth=3;
  g.beginPath();g.moveTo(rear,-size);g.lineTo(5,-size-1);g.lineTo(front,-size);g.lineTo(15,-32);g.stroke();
  if(bike){
    g.beginPath();g.moveTo(rear,-size);g.lineTo(-4,-26);g.lineTo(5,-size-1);g.lineTo(15,-28);g.stroke();
    rect(-11,-27,12,3,ink);
  }else rect(-17,-9,33,4,'#f6d77e');
  const bodyY=bike?-50:-58;
  if(animalRider)g.drawImage(rider,-35,(bike?-62:-52)+bounce,62,50);
  else g.drawImage(rider,15,4,37,42,-21,bodyY+bounce,37,42);
  if(animalRider)return bike?48:38;
  rect(9,-34,13,3,ink);rect(9,-34,5,3,'#f3c29f');
  const foot=bike?Math.round(Math.sin(gait)*5):0;
  rect(-4,-18+foot,5,bike?8:10,ink);rect(-3,-11+foot,8,3,'#f6e9d7');
  if(bike){rect(4,-12+foot,7,2,'#c9cfda');rect(8,-14+foot,5,4,ink);}
  return -bodyY-bounce;
}
