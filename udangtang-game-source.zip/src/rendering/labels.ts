const LABEL_HEIGHT = 27;
const HEAD_GAP = 4;

export function headLabelBox(x: number, headY: number, width: number) {
  return { left: x - width / 2, top: headY - HEAD_GAP - LABEL_HEIGHT, width };
}
