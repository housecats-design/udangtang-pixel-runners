/** Display-only weaving. Distance drives motion, so stopped runners and pauses stay still.
 * No race random numbers, jump height, collision state, or course positions are changed.
 */
export function groundPosition(index:number,total:number,distance:number,top:number,bottom:number,seed:number):number {
  const lanes=Math.min(10,Math.max(2,total));
  const base=top+(index%lanes+.5)/lanes*(bottom-top);
  const phase=((Math.imul(index+1,1597334677)^(seed>>>0))>>>0)/4294967296*Math.PI*2;
  const amplitude=Math.min(19,(bottom-top)*.105);
  const movement=(Math.sin(distance*.009+phase)+.35*Math.sin(distance*.017+phase*1.7))/1.35;
  const fade=Math.min(1,Math.max(0,distance)/100);
  const group=(Math.floor(index/lanes)%4-1.5)*2;
  return Math.max(top,Math.min(bottom,base+group+movement*amplitude*fade));
}

export function ease(t:number){const x=Math.max(0,Math.min(1,t));return x*x*(3-2*x);}

export function tumblePose(status:'fallen'|'falling'|'respawn',age:number,duration:number) {
  if(status==='respawn'){
    const rise=ease(age/.42);
    return {angle:.52*(1-rise),centerY:-17-8*rise,scale:1,opacity:.6+.4*rise};
  }
  const tip=ease((age-.04)/.27);
  const hop=7*Math.sin(Math.PI*tip);
  if(status==='falling'){
    const drop=ease((age-.12)/(duration-.12));
    return {angle:1.52*tip+drop,centerY:-25-hop+drop*74,scale:1-.55*drop,opacity:1-drop};
  }
  const standAge=age-(duration-.5);
  const push=ease(standAge/.21);
  const stand=ease((standAge-.21)/.29);
  const impact=Math.max(0,age-.29);
  const rebound=Math.sin(impact*24)*.13*(1-ease(impact/.27));
  const bounce=impact>0?Math.max(0,Math.sin(impact*19))*4*(1-ease(impact/.27)):0;
  return {angle:1.55*tip-.83*push-.72*stand+rebound,centerY:-25+13*tip-hop-bounce-6*push-7*stand,
    scale:1,opacity:1};
}

export type Reaction='flight'|'fall'|'recover'|'splash'|'kick'|'grab'|'snag'|'phone'|'freeze'|'climb';
type Limb=readonly [jointX:number,jointY:number,endX:number,endY:number];
type Limbs=readonly [rearArm:Limb,frontArm:Limb,rearLeg:Limb,frontLeg:Limb];

type BananaKeyframe={at:number;x:number;angle:number;lift:number;limbs:Limbs};

// Retargeted from the Higgsfield slip, kneel, and palm-brace poses to the game rig.
const bananaKeyframes:readonly BananaKeyframe[]=[
  {at:0,x:0,angle:.14,lift:0,limbs:[[-11,3,-16,-3],[11,2,14,-6],[-11,15,-18,22],[9,16,14,25]]},
  {at:.12,x:-4,angle:-.43,lift:1,limbs:[[-14,-3,-21,-13],[12,4,20,12],[-10,16,-16,22],[16,10,24,17]]},
  {at:.23,x:-3,angle:-.53,lift:4,limbs:[[-12,3,-20,9],[13,-5,23,-17],[-10,13,-17,15],[16,11,25,15]]},
  {at:.34,x:1,angle:.28,lift:0,limbs:[[-13,-1,-19,-5],[10,5,17,-7],[-11,15,-21,18],[10,15,17,22]]},
  {at:.46,x:2,angle:.39,lift:0,limbs:[[-11,-2,-16,-4],[9,4,17,-5],[-9,27,-22,23],[10,14,15,18]]},
  {at:.64,x:2,angle:.33,lift:0,limbs:[[-10,0,-15,0],[9,5,17,-3],[-9,26,-22,23],[10,15,15,18]]},
  {at:.77,x:2,angle:.42,lift:0,limbs:[[-7,10,-6,17],[10,9,14,18],[-9,28,-21,23],[8,13,14,19]]},
  {at:.87,x:2,angle:.29,lift:0,limbs:[[-8,11,-3,20],[9,12,13,20],[-8,23,-16,22],[7,13,12,20]]},
  {at:.94,x:1,angle:.16,lift:0,limbs:[[-9,8,-14,12],[9,5,13,4],[-8,17,-12,22],[9,14,16,22]]},
  {at:1,x:0,angle:.14,lift:0,limbs:[[-11,3,-16,-3],[11,2,14,-6],[-11,15,-18,22],[9,16,14,25]]},
];

export function bananaPose(progress:number){
  const at=Math.max(0,Math.min(1,progress));
  const nextIndex=bananaKeyframes.findIndex((frame,i)=>i>0&&at<=frame.at);
  const next=bananaKeyframes[nextIndex],previous=bananaKeyframes[nextIndex-1];
  const t=ease((at-previous.at)/(next.at-previous.at));
  const mix=(a:number,b:number)=>a+(b-a)*t;
  const mixLimb=(i:number):Limb=>{
    const a=previous.limbs[i],b=next.limbs[i];
    return [mix(a[0],b[0]),mix(a[1],b[1]),mix(a[2],b[2]),mix(a[3],b[3])];
  };
  const limbs:Limbs=[mixLimb(0),mixLimb(1),mixLimb(2),mixLimb(3)];
  const angle=mix(previous.angle,next.angle),scale=.86;
  const ankleY=(leg:Limb)=>(leg[2]*Math.sin(angle)+leg[3]*Math.cos(angle))*scale;
  const y=-Math.max(ankleY(limbs[2]),ankleY(limbs[3]))-4-mix(previous.lift,next.lift);
  return {x:mix(previous.x,next.x),y,angle,scale,limbs};
}

export function reactionLimbs(kind:Reaction,age:number,duration:number,reachX=24,reachY=0):Limbs {
  const wave=Math.sin(age*21),offset=Math.sin(age*21+2.4);
  if(kind==='flight'){
    return [[-14,-6+3*wave,-23,-13+10*wave],[13,1+6*offset,23,-12+11*offset],
      [-11,17-4*offset,-19,23+9*offset],[11,16-5*wave,19,24+9*wave]];
  }
  if(kind==='fall'){
    const flail=1-ease((age-.16)/.40);
    const brace=ease((age-.06)/.17)*(1-ease((age-.3)/.16));
    const push=ease((age-(duration-.5))/.22)*(1-ease((age-(duration-.23))/.2));
    const knee=ease((age-(duration-.49))/.29);
    return [[-10,-1,-15+9*brace,-5+wave*10*flail+11*push],
      [10,2,14+13*brace-4*push,3+offset*8*flail-7*brace+13*push],
      [-10+5*knee,17,-13+5*knee,22+offset*8*flail],
      [9-5*knee,15+5*flail*wave,13-6*knee,24+wave*7*flail]];
  }
  if(kind==='climb'){
    const grip=Math.sin(age*15);
    return [[-7,-8,-4,-20-6*grip],[12,-8,14,-22+7*grip],
      [-10,14+5*grip,-5,24+7*grip],[10,12-5*grip,12,23-7*grip]];
  }
  if(kind==='kick'){
    const extend=ease((age-.14)/.22)*(1-ease((age-.42)/.28));
    return [[-13,2,-21,-1],[11,4,17,-6],[-11,17,-18,23-11*extend],
      [8+9*extend,18+8*extend,8+19*extend,24+10*extend]];
  }
  if(kind==='grab')return [[-10,5,-13,11],[12,1,reachX,reachY+1],[-8,17,-12,23+wave*4],[10,16,10,24+offset*4]];
  if(kind==='snag')return [[-13,0,-21,-6],[12,4,19,-4],[-11,18,-17,24],[8,19,12,23+wave*3]];
  if(kind==='phone')return [[-10,4,-13,11+wave*2],[12,6,14,-7],[-8,17,-10,22+wave*3],[8,17,10,24+offset*3]];
  if(kind==='recover')return [[-11,6,-13,13],[12,5,15,13],[-8,17,-9,22],[8,16,12,23]];
  if(kind==='freeze')return [[-13,0,-17,-7],[12,4,16,-4],[-8,17,-12,24],[10,16,13,24]];
  return [[-12,2,-19,-7+4*wave],[13,2,22,-8+4*offset],[-9,17,-12,24],[9,16,12,22]];
}

export const SCENE_ZOOM=.7;

export function trackPosition(lane:number,top:number,bottom:number){return top+lane*(bottom-top);}
