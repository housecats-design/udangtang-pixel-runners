import {avatars,type Participant} from '../data/avatars.ts';

const motions=[
  'idle','run','flight','cheer','cry','fall',
  'recover','climb','splash','sleep','eat','drink',
  'phone','freeze','grab','snag','kick','tired-run',
  'scooter','bike','car','rabbit','fox','duck','jump',
] as const;
export type GeneratedMotion=typeof motions[number];
const tile=64,columns=12;
type Frame={canvas:HTMLCanvasElement;top:number};
let atlas:HTMLImageElement|null=null;
const frames=new Map<string,Frame>();
const rgb=(value:string)=>[1,3,5].map(i=>parseInt(value.slice(i,i+2),16));

export async function loadGeneratedMotions(){
  const image=new Image();
  image.src=`${import.meta.env.BASE_URL}assets/characters/higgsfield-motion-atlas.png`;
  try{
    await image.decode();
    if(image.width!==columns*tile||image.height!==motions.length*tile)return false;
    atlas=image;frames.clear();
    return true;
  }catch{return false;}
}
export function hasGeneratedMotions(){return atlas!==null;}

export function motionFrame(participant:Participant,motion:GeneratedMotion,frame:number):Frame|null{
  if(!atlas)return null;
  const count=motion==='jump'?12:6;
  const column=(Math.floor(Math.max(0,frame))||0)%count;
  const row=motions.indexOf(motion);
  const animal=motion==='rabbit'||motion==='fox'||motion==='duck';
  const key=`${animal?'animal':participant.avatarId}:${row}:${column}`;
  const cached=frames.get(key);
  if(cached)return cached;
  const canvas=document.createElement('canvas');canvas.width=canvas.height=tile;
  const ctx=canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled=false;
  ctx.drawImage(atlas,column*tile,row*tile,tile,tile,0,0,tile,tile);
  const image=ctx.getImageData(0,0,tile,tile);
  const data=image.data;
  const avatar=avatars.find(a=>a.id===participant.avatarId)??avatars[0];
  const hair=rgb(avatar.hair),skin=rgb(avatar.skin),shirt=rgb(avatar.shirt),pants=rgb(avatar.pants);
  let top=tile;
  for(let i=0;i<data.length;i+=4){
    if(!data[i+3])continue;
    const y=Math.floor(i/(tile*4));
    top=Math.min(top,y);
    if(animal||avatar===avatars[0])continue;
    const [r,g,b]=[data[i],data[i+1],data[i+2]];
    const l=.25*r+.6*g+.15*b;
    let target:number[]|undefined;
    let level=1;
    if(g-r>13&&b-r>8&&g>=b-13){target=shirt;level=l/129;}
    else if(r>142&&r-g>16&&g-b>9&&r-b>35&&g/r>.66){target=skin;level=l/191;}
    else if(r>43&&r-g>13&&g-b>4&&g/r<=.75&&r-b>21&&y<45){target=hair;level=l/105;}
    else if(y>34&&b-r>7&&b-g>3&&r<79&&g<92&&b<123&&motion!=='drink'&&motion!=='phone'){
      target=pants;level=l/53;
    }
    if(target)for(let c=0;c<3;c++){
      const base=target[c];
      data[i+c]=level>1?base+(255-base)*Math.min(.7,(level-1)*.76):base*Math.max(.22,level);
    }
  }
  ctx.putImageData(image,0,0);
  const result={canvas,top:top===tile?7:top};frames.set(key,result);
  return result;
}

export function sequenceFrame(age:number,duration:number,count=6){
  return Math.min(count-1,Math.max(0,Math.floor(age/Math.max(.01,duration)*count)));
}
