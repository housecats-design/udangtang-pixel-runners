import {headLabelBox} from './labels.ts';
import {bananaPose,ease,groundPosition,reactionLimbs,SCENE_ZOOM,trackPosition,tumblePose,type Reaction} from './motion.ts';
import {drawAnimal,drawRide} from './lollipop-effects.ts';
import {avatars,type Participant} from '../data/avatars.ts';
import {actionBlend,hash,PIXELS_PER_METER,WALL_HEIGHT,type Contact,type Race,type Runner,type Obstacle} from '../simulation/engine.ts';
const sprites=new Map<string,HTMLCanvasElement>();
const rainbowSprites=new WeakMap<HTMLCanvasElement,HTMLCanvasElement>();
type ContactPose={kind:Contact['kind'];amount:number;reachX:number;reachY:number};
type ReactionDetails={reachX?:number;reachY?:number;limbs?:ReturnType<typeof reactionLimbs>};
type AtlasFrame={x:number;y:number;w:number;h:number;foot:number;scale:number};
const bananaFrameHeads=[
  [9,-47],[9,-50],[8,-51],[8,-51],[9,-50],[11,-48],
  [13,-44],[14,-43],[12,-44],[12,-44],[12,-45],[12,-45],
  [12,-45],[12,-45],[13,-43],[14,-42],[15,-42],[15,-42],
  [14,-42],[13,-42],[10,-42],[7,-42],[4,-44],[-1,-48],
] as const;
let runnerAtlas:HTMLImageElement|null=null;
let actionAtlas:HTMLImageElement|null=null;
let bananaAtlas:HTMLImageElement|null=null;
let atlasFrames:AtlasFrame[][]=[];
let actionFrames:AtlasFrame[][]=[];
function readFrames(img:HTMLImageElement,columns:number):AtlasFrame[][]{
  const c=document.createElement('canvas');c.width=img.width;c.height=img.height;const ctx=c.getContext('2d')!;ctx.drawImage(img,0,0);
  const pixels=ctx.getImageData(0,0,img.width,img.height).data;const rows:AtlasFrame[][]=[];
  for(let row=0;row<8;row++){
    const frames:AtlasFrame[]=[];let maximumHeight=1;
    for(let col=0;col<columns;col++){
      const x=Math.round(col*img.width/columns),y=Math.round(row*img.height/8);
      const w=Math.round((col+1)*img.width/columns)-x,h=Math.round((row+1)*img.height/8)-y;
      let top=h,bottom=0;
      for(let yy=0;yy<h;yy++)for(let xx=0;xx<w;xx++)if(pixels[((y+yy)*img.width+x+xx)*4+3]>60){top=Math.min(top,yy);bottom=Math.max(bottom,yy);}
      maximumHeight=Math.max(maximumHeight,bottom-top+1);frames.push({x,y,w,h,foot:bottom+1,scale:1});
    }
    for(const f of frames)f.scale=49/maximumHeight;rows.push(frames);
  }
  return rows;
}
export function hasActionAtlas(){return actionAtlas!==null;}
export function hasBananaAtlas(){return bananaAtlas!==null;}
export async function loadRunnerAtlas():Promise<boolean>{
  const load=async(file:string)=>{
    const img=new Image();
    img.src=`${import.meta.env.BASE_URL}assets/characters/${file}`;
    await img.decode();
    return img;
  };
  const [run,actions,banana]=await Promise.allSettled(['runners-v2.png','actions-v1.png','banana-slip-higgsfield.png'].map(load));
  if(run.status==='fulfilled'){runnerAtlas=run.value;atlasFrames=readFrames(runnerAtlas,8);}
  if(actions.status==='fulfilled'){actionAtlas=actions.value;actionFrames=readFrames(actionAtlas,12);}
  if(banana.status==='fulfilled'&&banana.value.width===384&&banana.value.height===256)bananaAtlas=banana.value;
  sprites.clear();avatarURLs.clear();return runnerAtlas!==null;
}
function rasterSprite(p:Participant,frame:number,pose:string):HTMLCanvasElement{
  const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d')!;g.imageSmoothingEnabled=false;
  const row=Math.max(0,avatars.findIndex(a=>a.id===p.avatarId));
  const action=actionAtlas&&['eat','drink','cry'].includes(pose);
  const col=action?(pose==='eat'?0:pose==='drink'?4:8)+(frame%4):pose==='run'?frame%8:pose==='jump'||pose==='cheer'?3:2;const f=(action?actionFrames:atlasFrames)[row][col];
  const w=f.w*f.scale,h=f.h*f.scale;const y=56-f.foot*f.scale;
  g.drawImage(action?actionAtlas!:runnerAtlas!,f.x,f.y,f.w,f.h,Math.round(32-w/2),Math.round(y),w,h);
  // Small jersey marker preserves saved participant palette choices without recoloring skin.
  g.fillStyle=p.paletteId;g.fillRect(27,40,7,2);
  if(pose==='cheer'){g.fillStyle='#f5cc57';g.fillRect(12,17,3,8);g.fillRect(9,20,9,2);g.fillRect(48,11,2,7);g.fillRect(46,13,6,2);}
  return c;
}
// Original 64×64 procedural sprites: fixed frame, foot anchor (32,56), no trimmed frames.
export function sprite(p:Participant,frame=0,pose='run'):HTMLCanvasElement {
  const key=`${p.avatarId}:${p.paletteId}:${frame}:${pose}`;
  if(sprites.has(key))return sprites.get(key)!;
  const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d')!;g.imageSmoothingEnabled=false;
  if(runnerAtlas){const raster=rasterSprite(p,frame,pose);sprites.set(key,raster);return raster;}
  const a=avatars.find(a=>a.id===p.avatarId)??avatars[0];
  const rect=(x:number,y:number,w:number,h:number,color:string)=>{g.fillStyle=color;g.fillRect(x,y,w,h);};
  const bounce=pose==='run'&&frame%4<2?-1:0;
  g.translate(0,bounce);
  const stride=pose==='jump'?3:pose==='run'?Math.round(Math.sin(frame/8*Math.PI*2)*5):pose==='cheer'?3:0;
  rect(24-stride,45,7,9,a.pants);rect(34+stride,45,7,9,a.pants);
  rect(23-stride,53,10,3,'#fff7e1');rect(33+stride,53,10,3,'#fff7e1');
  rect(23-stride,56,11,2,'#364441');rect(33+stride,56,11,2,'#364441');
  rect(23,32,17,15,'#35453e');rect(25,32,14,13,a.shirt);rect(25,42,14,3,p.paletteId);
  rect(21+stride,35,5,9,a.skin);rect(36-stride,34,5,9,a.skin);
  if(pose==='cheer'){rect(18,24,5,13,a.skin);rect(40,23,5,13,a.skin);}
  rect(22,12,21,3,'#3d3b38');rect(19,15,27,16,'#3d3b38');rect(22,30,21,3,'#3d3b38');
  rect(22,15,21,15,a.skin);rect(43,21,5,5,a.skin);rect(24,30,15,3,a.skin);
  rect(21,13,22,7,a.hair);rect(20,19,7,9,a.hair);rect(24,11,15,3,a.hair);
  rect(38,21,3,4,'#303c3a');rect(43,27,3,2,'#a96657');rect(36,27,4,2,'#ef9e91');
  if(a.style===1){rect(20,7,23,6,a.shirt);rect(40,12,10,3,a.shirt);}
  if(a.style===2){rect(18,18,6,15,a.hair);rect(16,27,7,7,a.hair);}
  if(a.style===3){rect(20,16,24,3,p.paletteId);rect(19,16,4,9,p.paletteId);}
  sprites.set(key,c);return c;
}
const avatarURLs=new Map<string,string>();
function rainbowSprite(original:HTMLCanvasElement){
  const cached=rainbowSprites.get(original);if(cached)return cached;
  const c=document.createElement('canvas');c.width=c.height=64;
  const g=c.getContext('2d')!;g.drawImage(original,0,0);
  const rainbow=g.createLinearGradient(15,15,47,53);
  ['#ff6379','#ffd45a','#8adf78','#68dcf1','#947df8','#f485d2'].forEach((color,i)=>rainbow.addColorStop(i/5,color));
  g.globalCompositeOperation='source-atop';g.globalAlpha=.42;g.fillStyle=rainbow;g.fillRect(0,0,64,64);
  rainbowSprites.set(original,c);return c;
}
export function avatarURL(p:Participant):string{const key=p.avatarId+':'+p.paletteId;let url=avatarURLs.get(key);if(!url){url=sprite(p,0,'idle').toDataURL();avatarURLs.set(key,url);}return url;}
export class Renderer {
  canvas:HTMLCanvasElement;ctx:CanvasRenderingContext2D;camera=-115;targetIndex=0;candidate=-1;candidateSince=0;width=960;height=430;lastTime=0;private sceneTop=0;private lastRespawnId=0;private respawnFlashAt=-Infinity;private lastRace:Race|null=null;private observer:ResizeObserver;private woodland:HTMLImageElement|null=null;
  constructor(canvas:HTMLCanvasElement){
    this.canvas=canvas;this.ctx=canvas.getContext('2d')!;
    this.observer=new ResizeObserver(()=>this.resize());
    this.observer.observe(canvas);
    this.resize();
    const scenery=new Image();
    scenery.src=`${import.meta.env.BASE_URL}assets/maps/woodland-festival-v1.png`;
    void scenery.decode().then(()=>{
      this.woodland=scenery;
      canvas.dataset.map='woodland-festival';
    }).catch(()=>{canvas.dataset.map='fallback';});
  }
  resize(){
    const w=this.canvas.clientWidth;
    const focused=document.body.classList.contains('race-focus');
    const available=this.canvas.clientHeight;
    const scale=focused?(available<390?Math.max(.35,available/390):available>=800&&w>=960?2:1):1;
    this.width=Math.max(260,Math.round(w/(scale*SCENE_ZOOM)));
    this.height=focused?Math.max(390,Math.round(available/scale)):available;
    const renderHeight=Math.round(this.height/SCENE_ZOOM);
    if(this.canvas.width!==this.width)this.canvas.width=this.width;
    if(this.canvas.height!==renderHeight)this.canvas.height=renderHeight;
    this.sceneTop=Math.floor((this.canvas.height-this.height)*.48);
    this.canvas.dataset.zoom=String(SCENE_ZOOM);
    this.ctx.imageSmoothingEnabled=false;
  }
  rect(x:number,y:number,w:number,h:number,c:string){this.ctx.fillStyle=c;this.ctx.fillRect(Math.round(x),Math.round(y),w,h);}
  tree(x:number,y:number,s:number,c:string){this.rect(x+15*s,y+30*s,7*s,26*s,'#8f9872');this.rect(x+6*s,y,24*s,9*s,c);this.rect(x,y+9*s,36*s,22*s,c);this.rect(x+5*s,y+30*s,27*s,6*s,c);}
  fallbackBackground(){
    const {width:w,height:h,camera:cam}=this;const g=this.ctx;
    this.rect(0,-this.sceneTop,w,this.canvas.height,'#cbece7');this.rect(0,h-30,w,this.canvas.height-h+30,'#92b976');this.rect(0,150,w,100,'#bedfd1');
    for(let i=-1;i<Math.ceil(w/230)+2;i++){const x=i*230-((cam*.06)%230);this.rect(x+10,37,64,16,'#f5fbef');this.rect(x+23,27,36,13,'#f5fbef');this.rect(x+5,45,83,9,'#f5fbef');}
    for(let i=-2;i<w/120+3;i++){const x=i*120-((cam*.15)%120);this.tree(x,116+(i%3)*8,2.2,'#9dceaf');}
    const hx=650-((cam*.25)%1300);this.rect(hx,144,82,61,'#f6e9bc');this.rect(hx-7,138,96,12,'#d49a76');this.rect(hx+9,126,70,12,'#d49a76');this.rect(hx+20,115,48,12,'#d49a76');this.rect(hx+18,164,17,20,'#84b7b0');this.rect(hx+52,164,17,20,'#84b7b0');
    for(let i=-1;i<w/290+2;i++)this.tree(i*290-((cam*.38)%290),137,1.45,'#72ad86');
    this.rect(0,214,w,h-214,'#91bb76');this.rect(0,225,w,h-225,'#d9c899');this.rect(0,225,w,7,'#72a66c');this.rect(0,h-30,w,30,'#92b976');this.rect(0,h-30,w,6,'#6f9d5f');
    for(let i=-1;i<w/53+2;i++){const x=i*53-((cam*.7)%53);this.rect(x,211,5,12,'#5c8e61');this.rect(x+5,207,4,8,'#699961');this.rect(x+20,h-16,3,4,'#eae5ab');this.rect(x+23,h-19,4,3,'#fff2bd');}
    for(let i=-1;i<w/80+2;i++){const x=i*80-(cam%80);this.rect(x+13,263,9,2,'#caba8e');this.rect(x+42,321,6,2,'#bcb084');this.rect(x+5,365,12,2,'#c7b98b');}
    // Repeating fence, far side of the course.
    for(let i=-1;i<w/42+2;i++){const x=i*42-(cam%42);this.rect(x,199,6,27,'#faf2cf');this.rect(x+6,207,36,4,'#faf2cf');this.rect(x+6,218,36,4,'#faf2cf');}
  }
  drawMapStrip(image:HTMLImageElement,sourceTop:number,sourceHeight:number,y:number,height:number,tileWidth:number,offset:number){
    const g=this.ctx;
    const start=Math.floor(offset/tileWidth);
    for(let tile=start;tile*tileWidth-offset<this.width;tile++){
      const x=Math.round(tile*tileWidth-offset);
      g.save();
      g.translate(x+(tile%2!==0?tileWidth:0),y);
      if(tile%2!==0)g.scale(-1,1);
      g.drawImage(image,0,sourceTop,image.naturalWidth,sourceHeight,0,0,tileWidth,height);
      g.restore();
    }
  }
  background(){
    const scenery=this.woodland;
    if(scenery){
      const groundY=225;
      const sourceGroundY=656;
      const turfY=scenery.naturalHeight-98;
      this.drawMapStrip(scenery,0,sourceGroundY,-this.sceneTop,groundY+this.sceneTop,560,this.camera*.24);
      this.drawMapStrip(scenery,sourceGroundY,turfY-sourceGroundY,groundY,this.height-29-groundY,760,this.camera);
      this.drawMapStrip(scenery,turfY,scenery.naturalHeight-turfY,this.height-29,this.canvas.height-this.sceneTop-this.height+29,760,this.camera);
    }else{
      this.fallbackBackground();
    }
    const x=-this.camera;
    if(x<-72||x>this.width)return;
    for(let y=233;y<this.height-35;y+=12){
      for(let column=0;column<2;column++)this.rect(x+column*9,y,9,12,((y-233)/12+column)%2?'#fff6d7':'#4a5d4a');
    }
    this.rect(x-5,167,5,63,'#61472c');
    this.rect(x-3,167,2,63,'#c59655');
    this.rect(x,169,65,24,'#513b2a');
    this.rect(x+2,171,61,20,'#f1d398');
    this.rect(x+5,174,2,2,'#967344');
    this.rect(x+58,174,2,2,'#967344');
    this.ctx.fillStyle='#4c3826';this.ctx.font='bold 11px sans-serif';this.ctx.fillText('START',x+12,185);
  }
  finishLine(race:Race){
    const x=Math.round(race.finishX-this.camera);if(x<-80||x>this.width+80)return;
    for(let y=233;y<this.height-35;y+=10)for(let col=0;col<3;col++)this.rect(x+col*8,y,8,10,((y-233)/10+col)%2?'#fff9de':'#385746');
    this.rect(x-4,165,4,this.height-200,'#4d6957');this.rect(x+78,165,4,this.height-200,'#4d6957');
    this.rect(x-8,151,94,27,'#34583f');this.rect(x-8,151,94,3,'#d8ed9b');
    this.ctx.font='bold 12px sans-serif';this.ctx.fillStyle='#fff7d5';this.ctx.textAlign='center';this.ctx.fillText('FINISH',x+39,170);
    this.ctx.font='10px sans-serif';this.ctx.fillText(`${race.distanceMeters>=1000?'1 km':race.distanceMeters+' m'}`,x+39,193);this.ctx.textAlign='left';
    if(race.runners.some(r=>r.finishHeld&&r.finishTime===null)){
      const g=this.ctx;
      this.rect(x-24,204,110,17,'#fff0d2');g.fillStyle='#684b74';g.textAlign='center';
      g.fillText('무지개 주자 통과 대기',x+31,216);g.textAlign='left';
    }
  }
  courseDetails(time:number,finishX:number,seed:number){
    const g=this.ctx;
    const verge=this.height-26;
    const first=Math.max(1,Math.floor(this.camera/56));
    const end=Math.min(finishX,this.camera+this.width+70);
    for(let i=first;i*56<end;i++){
      const key=hash(seed+i*31337),x=Math.round(i*56+(key%19)-this.camera);
      const y=verge+(key%7);
      this.rect(x-1,y+3,14,3,'#627a36');this.rect(x,y-2,2,6,'#91ae43');this.rect(x+5,y-5,2,9,'#749839');
      this.rect(x+4,y-6,4,3,i%3===0?'#f3b58a':i%3===1?'#fff3c5':'#efd75f');
      this.rect(x+9,y+1,4,3,'#6b8a3b');
      const pebbleY=252+(key>>>8)%Math.max(1,this.height-312);
      this.rect(x+15,pebbleY+2,6,2,'#ae763f');this.rect(x+16,pebbleY,4,2,'#edb978');
      if(i%3===0){this.rect(x+23,226,18,3,'#b4763c');this.rect(x+25,225,15,2,'#f9d080');}
    }
    const interval=50*PIXELS_PER_METER;
    for(let mark=Math.max(interval,Math.floor((this.camera-100)/interval)*interval);mark<end&&mark<finishX-150;mark+=interval){
      const x=Math.round(mark-this.camera),banner=(mark/interval)%2?'#db7b5f':'#489688';
      this.rect(x-3,178,6,53,'#62422e');this.rect(x-2,177,2,53,'#bc8c53');this.rect(x-5,226,11,4,'#795239');
      this.rect(x+1,180,48,17,'#573f2f');this.rect(x+3,181,44,14,banner);this.rect(x+3,181,44,2,'#f1c288');
      g.fillStyle='#fff3cf';g.font='bold 9px sans-serif';g.textAlign='center';g.fillText(mark/PIXELS_PER_METER+'m',x+25,192);g.textAlign='left';
      const wave=(Math.floor(time*4)+mark/interval)%3;
      this.rect(x+52,204,31,3,'#684936');this.rect(x+51,207,33,13,'#935e41');this.rect(x+53,208,29,3,'#cc905c');
      for(let person=0;person<2;person++){
        const px=x+57+person*13,shirt=person===0?'#f2bf56':'#72a9ce';
        this.rect(px,193-person*3,7,9,'#63483e');this.rect(px+1,196-person*3,6,5,'#f5c199');
        this.rect(px-1,202-person*3,9,6,shirt);this.rect(px+8,200-wave*2-person*3,3,6,'#f5c199');
      }
      for(let y=239;y<this.height-38;y+=22){this.rect(x-1,y,3,9,'#d59453');this.rect(x,y,1,8,'#f3bb72');}
    }
  }
  puddle(x:number,top:number,bottom:number,width:number,seed:number,time:number){
    const waterBottom=bottom-3;
    for(let row=top;row<bottom;row+=4){
      const edge=Math.max(0,8-(row-top),8-(waterBottom-row));
      const offset=hash(seed*67+Math.floor(row/8));
      const left=x+edge+offset%5,right=x+width-edge-(offset>>>8)%5;
      this.rect(left-3,row,right-left+6,4,'#936742');
      this.rect(left,row,right-left,4,'#366c74');
      if(row>top+3&&row<waterBottom){
        this.rect(left+3,row,right-left-6,4,row%12===3?'#63aebb':'#5fa6b2');
        if(row%8===top%8)this.rect(left+2,row+1,6,1,'#a6dad4');
        if(row%16===top%16){
          const shimmer=(offset>>>13)%Math.max(1,right-left-21)+Math.round(Math.sin(time*2+row)*3);
          this.rect(left+7+shimmer,row+1,11,2,'#a3dce0');this.rect(left+11+shimmer,row+3,8,1,'#438798');
          this.rect(right+5,row+2,3,2,'#ba905f');
        }
      }
    }
    this.rect(x+8,top+9,3,5,'#527e53');this.rect(x+6,top+7,3,6,'#71964e');
    this.rect(x+width-11,bottom-10,2,6,'#65824b');this.rect(x+width-8,bottom-12,2,7,'#7c9a53');
  }
  hole(x:number,top:number,bottom:number,width:number,id:number){
    for(let y=top;y<bottom;y+=5){
      const edge=Math.abs(2*(y-top)/(bottom-top)-1);
      const taper=Math.round(width*.28*edge*edge);
      const noise=hash(id*61+Math.floor(y/9));
      const left=x+taper+noise%5,right=x+width-taper-(noise>>>8)%5;
      this.rect(left-4,y,right-left+8,5,'#bd884f');
      this.rect(left,y,right-left,5,'#312822');
      this.rect(left,y,7+noise%3,5,'#77513a');
      this.rect(left+2,y+1,4,2,'#9e6c46');
      this.rect(right-9,y,9,5,'#563e2f');
      if(y%4===top%4)this.rect(right+1,y+2,5,2,'#e5ad62');
    }
  }
  bananaPeel(x:number,y:number){
    this.rect(x-9,y+2,18,4,'#966631');
    this.rect(x-3,y-7,6,12,'#9d7136');this.rect(x-2,y-7,4,10,'#f3c642');
    this.rect(x-9,y-1,7,5,'#e8a534');this.rect(x+2,y-1,7,5,'#e8a534');
    this.rect(x-8,y-2,6,3,'#fff09b');this.rect(x+2,y-2,6,3,'#fff09b');
    this.rect(x-1,y-8,3,2,'#705236');this.rect(x,y-5,2,4,'#fff1a3');
  }
  wall(x:number,width:number,top:number,bottom:number){
    const crest=top-WALL_HEIGHT;
    this.rect(x-10,top+5,width+24,bottom-top+6,'#a8754a');
    this.rect(x,crest,width,bottom-crest,'#665854');
    this.rect(x+8,crest+7,width-13,bottom-crest-8,'#aa8980');
    for(let y=crest+10,row=0;y<bottom-8;y+=13,row++){
      this.rect(x+8,y,width-13,2,'#795e59');
      this.rect(x+9,y+2,width-15,1,'#c2a294');
      for(let col=0;col<3;col++)this.rect(x+14+col*17+(row%2)*7,y+2,2,10,'#8b6c63');
    }
    this.rect(x+23,crest+4,width-43,bottom-top-3,'#b3998d');
    this.rect(x+23,bottom-WALL_HEIGHT-2,width-43,4,'#dcc0a4');
    for(let y=crest+11;y<bottom-WALL_HEIGHT-5;y+=18){
      this.rect(x+25,y,width-47,1,'#d5bba4');this.rect(x+31,y+1,2,9,'#a18373');
    }
    this.rect(x-5,crest-5,width+10,10,'#4d5d44');
    this.rect(x-4,crest-5,width+8,4,'#b5ce77');
    this.rect(x-4,crest+7,4,bottom-crest-8,'#745846');
    this.rect(x+width,crest+7,4,bottom-crest-8,'#57493c');
    for(let y=crest+16;y<bottom-5;y+=17){
      this.rect(x+11,y,4,8,'#d8b177');this.rect(x+13,y+4,13,3,'#eac688');
      this.rect(x+width-19,y-3,7,4,'#d7c3a1');
    }
  }
  obstacle(o:Obstacle,time:number,lanes:number){
    const x=Math.round(o.x-this.camera);if(x+o.width<-100||x>this.width+100)return;
    const g=this.ctx,trackBottom=this.height-44;
    const top=o.band?Math.round(trackPosition(o.band.center-o.band.span/2,257,trackBottom)):243;
    const bottom=o.band?Math.round(trackPosition(o.band.center+o.band.span/2,257,trackBottom)):this.height-36;
    const rows=o.band?1:lanes;
    if(o.type==='wall'){
      this.wall(x,o.width,top,bottom);
    }else if(o.type==='spring'){
      this.rect(x,top,o.width,bottom-top,'#eccb8b');
      for(let lane=0;lane<rows;lane++){
        const y=o.band?(top+bottom)/2:257+(lane+.5)/rows*(bottom-257);const squash=Math.round(Math.sin(time*5+o.phase)*2);
        this.rect(x+7,y-3,40,5,'#6c6650');this.rect(x+10,y-11,6,8,'#b27f52');this.rect(x+36,y-11,6,8,'#b27f52');
        this.rect(x+14,y-17+squash,24,4,'#df9a50');this.rect(x+5,y-23+squash,43,7,'#f47c60');this.rect(x+5,y-23+squash,43,2,'#fff0b8');
        this.rect(x+18,y-21+squash,15,2,'#fff8d9');this.rect(x+15,y-20+squash,5,2,'#fff8d9');
      }
    }else if(o.type==='banana'){
      this.bananaPeel(x+o.width/2,(top+bottom)/2);
    }else if(o.type==='hole'){
      this.hole(x,top,bottom,o.width,o.id);
    }else if(o.type==='puddle'){
      this.puddle(x,top,bottom,o.width,o.id,time);
    }else if(o.type==='mud'||o.type==='platform'){
      const mud=o.type==='mud';
      const edge=mud?'#9b6846':'#3e534d';
      this.rect(x+4,top,o.width-8,bottom-top,edge);this.rect(x,top+4,o.width,bottom-top-8,edge);
      this.rect(x+4,top+3,o.width-8,bottom-top-7,mud?'#ac7953':'#5e7468');
      for(let y=top+8;y<bottom-3;y+=12){
        const offset=hash(o.id*67+y)%Math.max(1,o.width-28);
        this.rect(x+6+offset,y,13+(y%5),2,mud?'#87593e':'#384e4a');
        this.rect(x+6+offset,y+3,7,1,mud?'#c69966':'#849187');
      }
      if(o.type==='platform'){
        const px=x+o.width/2+Math.sin(time*1.8+o.phase)*27-18;
        this.rect(px-3,top-2,42,bottom-top+5,'#493c33');this.rect(px,top-2,36,bottom-top+2,'#c89559');
        for(let y=top;y<bottom-4;y+=12){
          this.rect(px,y,36,2,'#ebbf79');this.rect(px+1,y+10,34,1,'#9b6a43');
          this.rect(px+3,y+5,3,3,'#604d40');this.rect(px+30,y+5,3,3,'#604d40');
        }
      }
    }else{
      for(let lane=0;lane<rows;lane++){
        const y=o.band?(top+bottom)/2:255+lane*(bottom-257)/Math.max(1,rows-1);
        if(o.type==='spinner'){
          this.rect(x+10,y-34,9,36,'#7e7769');g.save();g.translate(x+15,y-25);g.rotate(time*3+o.phase);this.rect(-31,-5,62,10,'#ee927b');this.rect(-27,-5,12,10,'#fff0b5');this.rect(16,-5,12,10,'#fff0b5');g.restore();this.rect(x+11,y-29,8,8,'#f5d25b');
        }else{
          const swing=Math.sin(time*3.6+o.phase);this.rect(x+8,y-69,6,70,'#8d9a85');this.rect(x+8,y-70,38,5,'#8d9a85');const hy=y-42+swing*22;this.rect(x+29,hy-30,5,30,'#817467');this.rect(x+17,hy-6,30,16,'#af8bca');this.rect(x+17,hy-6,6,16,'#d0b4e2');
        }
      }
    }
  }
  drawRunner(r:Runner,x:number,y:number,time:number,idle=false,cheer=false,visualTime=time,contact?:ContactPose,stompFrozen=false){
    const g=this.ctx;
    const sy=y-r.z,age=time-r.statusStarted,remaining=r.until-time;
    const candy=!idle&&time<r.candyBoostUntil;
    const boost=!idle&&r.status==='running'&&(candy||time<r.boostUntil);
    const pass=!idle&&time<r.obstaclePassUntil;
    const infinite=!idle&&time<r.infiniteStaminaUntil;
    const form=!idle&&r.form&&time<r.form.until?r.form.kind:null;
    const blend=idle?0:actionBlend(age,remaining);
    const tired=!idle&&!candy&&r.stamina<=.5;
    const shortSteps=[1,2,5,6];
    const stride=idle?0:tired?shortSteps[Math.floor(r.gait)%shortSteps.length]:Math.floor(r.gait)%8;
    const runnerSprite=(frame:number,pose:string)=>{
      const original=sprite(r.participant,frame,pose);return r.rainbow?rainbowSprite(original):original;
    };
    const run=runnerSprite(stride,'run');
    const breakPose=r.status==='eating'?'eat':r.status==='drinking'?'drink':null;
    const returnAge=time-r.respawnAt;
    const respawning=!idle&&r.status==='running'&&returnAge>=0&&returnAge<.42;
    let head={x,y:sy-49},footY=sy,visibility=1;
    g.save();
    g.fillStyle='rgba(57,69,42,.19)';g.beginPath();g.ellipse(x+1,y+2,Math.max(7,16-r.z*.08),4,0,0,Math.PI*2);g.fill();
    if(!idle&&r.status==='running'&&!respawning&&r.z===0&&!stompFrozen&&!r.finishHeld){
      const phase=(time*10+r.index)%1;
      g.globalAlpha=.48;this.rect(x-28-phase*19,y-3,7,3,boost?'#ffe492':'#f8edc9');
      this.rect(x-18-phase*12,y+1,4,2,'#f8edc9');
      if(boost){this.rect(x-25-phase*28,sy-13,11,2,'#fff4ac');this.rect(x-23-phase*16,sy-27,6,2,'#fff7d6');}
      g.globalAlpha=1;
    }
    if(r.rainbow){
      const colors=['#ff758e','#ffd974','#9cf193','#83e7ff','#b79aff'];
      for(let i=0;i<colors.length;i++){
        const drift=(time*2.4+i/5)%1;
        this.rect(x-13-drift*30,sy-11-i*5+drift*4,4+drift*4,2,colors[i]);
      }
    }

    if(form&&'pace' in form&&r.status==='running'){
      g.save();g.translate(Math.round(x),Math.round(sy));
      const height=drawRide(g,form.id,runnerSprite(0,'idle'),r.gait);
      g.restore();head={x:x-3,y:sy-height};
    }else if(form&&!('pace' in form)&&r.status!=='crying'&&r.status!=='finished'){
      const moving=r.status==='running'&&!r.finishHeld&&!stompFrozen;
      const knocked=r.status==='falling'||r.status==='fallen'||r.status==='banana-cry';
      const depth=r.status==='pit-fall'?27*ease(age/.35)*ease(remaining/.5):0;
      const tilt=knocked?-.96*ease(age/.24)*ease(remaining/.24):r.transport?.kind==='beam-back'?.35:r.transport?-.35:0;
      g.save();g.translate(Math.round(x),Math.round(sy+depth));g.rotate(tilt);
      if(knocked)g.translate(0,5*ease(age/.24));
      const height=drawAnimal(g,form.id,r.gait,moving);
      g.restore();head={x,y:sy+depth-height*Math.cos(tilt)};
      if(r.status==='frozen'){
        g.fillStyle='rgba(177,236,255,.45)';g.fillRect(x-27,sy-height-2,54,height+4);
      }
      if(r.status==='splash')this.splash(r,x,y,age);
    }else if(r.status==='falling'||r.status==='fallen'||respawning){
      const reaction=respawning?'recover':'fall';
      const elapsed=respawning?returnAge:age,duration=respawning?.42:r.until-r.statusStarted;
      const pose=tumblePose(r.status==='falling'?'falling':respawning?'respawn':'fallen',elapsed,duration);
      const fade=respawning?1:ease(elapsed/.13)*(r.status==='fallen'?ease((duration-elapsed)/.17):1);
      if(fade<1){g.globalAlpha=1-fade;g.drawImage(run,Math.round(x-32),Math.round(sy-56));}
      g.globalAlpha=pose.opacity*fade;
      ({head,footY}=this.drawReaction(r.participant,reaction,x,sy+pose.centerY,pose.angle,elapsed,duration,pose.scale));
      if(r.status==='falling')visibility=pose.opacity;
      g.globalAlpha=1;
      if(r.status==='fallen'&&age>=.24&&age<.68){
        const dust=(age-.24)/.44;g.globalAlpha=1-dust;
        for(let i=0;i<6;i++)this.rect(x+(i-3)*(8+dust*13),y-4-dust*(6+i%2*9),4+i%2*2,3,i%2?'#f8e9bc':'#bd8c60');
        g.globalAlpha=1;
      }
    }else if(r.status==='climbing'){
      const progress=age/(r.until-r.statusStarted);
      const reach=ease(age/.16)*ease(remaining/.19);
      g.globalAlpha=1-reach;g.drawImage(run,Math.round(x-32),Math.round(sy-56));
      g.globalAlpha=reach;
      ({head,footY}=this.drawReaction(r.participant,progress<.62?'climb':progress<.85?'recover':'flight',x,sy-25,
        (.14*Math.sin(age*15)-.20)*reach,age,r.until-r.statusStarted,1));
      g.globalAlpha=1;
    }else if(r.status==='pit-fall'){
      const drop=ease(age/.38),climb=ease((age-.84)/.58),depth=55*drop*(1-climb);
      const tint=1-depth*.008;
      const angle=age<.84?.94*drop:-.47*(1-climb);
      const g=this.ctx;
      g.save();g.beginPath();g.rect(x-65,sy-100,130,103);g.clip();g.globalAlpha=tint;
      ({head,footY}=this.drawReaction(r.participant,age<.84?'flight':'recover',x,sy-25+depth,angle,age,1.42,1-depth*.004));
      g.restore();
      if(age<.54){
        const dust=ease(age/.54),rim=x+r.statusX-r.x;
        g.globalAlpha=1-dust;
        for(let i=0;i<7;i++)this.rect(rim+(i-3)*(5+dust*6),sy-2-(i%3+1)*Math.sin(dust*Math.PI)*5,3,3,i%2?'#e3b47b':'#936040');
        g.globalAlpha=1;
      }
      visibility=1-ease((depth-22)/24);
    }else if(r.status==='banana-cry'){
      const duration=r.until-r.statusStarted;
      const progress=age/duration;
      const reactionAlpha=ease(age/.1)*ease(remaining/.13);
      if(reactionAlpha<1){
        g.globalAlpha=1-reactionAlpha;
        g.drawImage(run,Math.round(x-32),Math.round(sy-56));
      }
      g.globalAlpha=reactionAlpha;
      let reactionHead;
      if(bananaAtlas&&r.participant.avatarId==='human-01'){
        const index=Math.max(0,Math.min(bananaFrameHeads.length-1,Math.floor(progress*bananaFrameHeads.length)));
        g.drawImage(bananaAtlas,(index%6)*64,Math.floor(index/6)*64,64,64,Math.round(x-32),Math.round(sy-56),64,64);
        const [headX,headY]=bananaFrameHeads[index];
        reactionHead={x:x+headX,y:sy+headY};
      }else{
        const pose=bananaPose(progress);
        reactionHead=this.drawReaction(r.participant,'fall',x+pose.x,sy+pose.y,pose.angle,age,duration,pose.scale,{limbs:pose.limbs}).head;
      }
      head={x:x+(reactionHead.x-x)*reactionAlpha,y:sy-49+(reactionHead.y-sy+49)*reactionAlpha};
      if(progress<.28){
        const slip=ease(progress/.28);
        g.globalAlpha=1-slip;
        this.rect(x-17-slip*16,sy-5,10+slip*8,2,'#f5d98d');
        this.rect(x-23-slip*12,sy-10,9,2,'#fff0bd');
      }
      if(progress>.38&&progress<.76){
        for(let i=0;i<2;i++){
          const tear=((progress-.38)*6+i/2)%1;
          g.globalAlpha=1-tear;
          const tx=head.x+11+tear*12+i*4,ty=head.y+12+tear*17;
          this.rect(tx,ty,3,4,'#b3ecf3');
          this.rect(tx+1,ty+2,2,2,'#71c2de');
        }
      }
      g.globalAlpha=1;
    }else if(r.status==='sleeping'){
      g.globalAlpha=1-blend;
      g.drawImage(sprite(r.participant,0,'idle'),Math.round(x-32),Math.round(sy-56));
      g.globalAlpha=blend;
      this.nap(r,x,sy,age);
      g.globalAlpha=1;
      head={x:x-18*blend,y:sy-49+22*blend};
    }else if(r.transport){
      const movement=r.transport;
      const flight=ease(age/.12)*(1-ease((age-(movement.duration-.16))/.16));
      const forward=movement.to>=movement.from;
      const tilt=(forward?-.49:.49)*flight+Math.sin(age*12+r.index)*.24*flight;
      if(flight<1){g.globalAlpha=1-flight;g.drawImage(sprite(r.participant,3,'jump'),Math.round(x-32),Math.round(sy-56));}
      g.globalAlpha=flight;
      ({head,footY}=this.drawReaction(r.participant,'flight',x,sy-25,tilt,age,movement.duration,1));
      g.globalAlpha=1;
      const color=movement.kind==='beam-forward'?'#d4f69a':movement.kind==='beam-back'?'#e9c7ff':'#fff0b8';
      for(let i=0;i<3;i++){
        const shift=Math.floor((age*65+i*11)%34);
        this.rect(x+(forward?-1:1)*(22+shift),sy-13-i*10,8+i*3,2,color);
      }
    }else if(breakPose){
      g.globalAlpha=1-blend;g.drawImage(run,Math.round(x-32),Math.round(sy-56));
      g.globalAlpha=blend;
      const actionFrame=Math.floor(age*(breakPose==='eat'?6:5))%4;
      g.drawImage(sprite(r.participant,actionFrame,breakPose),Math.round(x-32),Math.round(sy-56+2*blend));
      if(!actionAtlas)this.breakProp(r,x,sy,age,breakPose);
      g.globalAlpha=1;
    }else if(r.status==='splash'){
      const bob=Math.sin(age*19)*4*(1-ease(age/.65));
      const impact=ease(age/.13);
      this.splash(r,x,y,age);
      g.globalAlpha=1-impact;g.drawImage(run,Math.round(x-32),Math.round(sy-56));
      g.globalAlpha=impact;
      ({head,footY}=this.drawReaction(r.participant,'splash',x+bob,sy-25+7*impact,.23*impact,age,r.until-r.statusStarted,1));
      g.globalAlpha=1;
    }else if(r.status==='phoning'||r.status==='grabbed'||r.status==='frozen'||contact){
      const reaction:Reaction=r.status==='phoning'?'phone':r.status==='grabbed'?'snag':r.status==='frozen'?'freeze':contact?.kind??'grab';
      const duration=r.until-r.statusStarted;
      const intensity=reaction==='kick'?ease(age/.13)*(1-ease((age-(duration-.14))/.14)):contact?.amount??blend;
      const tilt=reaction==='kick'?-.29*intensity:reaction==='grab'?.32*intensity:reaction==='snag'?-.38*intensity:-.1*intensity;
      g.globalAlpha=1-intensity;g.drawImage(run,Math.round(x-32),Math.round(sy-56));
      g.globalAlpha=intensity;
      ({head,footY}=this.drawReaction(r.participant,reaction,x,sy-25,tilt,age,duration,1,{reachX:contact?.reachX,reachY:contact?.reachY}));
      g.globalAlpha=1;
      if(r.status==='frozen'){
        g.globalAlpha=blend;g.fillStyle='rgba(177,236,255,.58)';g.fillRect(x-20,sy-49,41,50);g.strokeStyle='#e0ffff';g.lineWidth=2;g.strokeRect(x-20,sy-49,41,50);
        this.rect(x-16,sy-45,5,22,'#efffff');this.rect(x+13,sy-18,4,13,'#91ccd9');g.globalAlpha=1;
      }
    }else{
      const pose=r.status==='crying'?'cry':cheer?'cheer':idle||r.finishHeld?'idle':r.z>0?'jump':'run';
      const frame=r.status==='crying'?Math.floor((visualTime-r.statusStarted)*5)%4:stride;
      if(tired&&pose==='run'&&r.z===0){
        g.save();g.translate(Math.round(x),Math.round(sy));g.transform(1,0,-.20,.91,0,0);
        g.drawImage(runnerSprite(frame,pose),-32,-56);g.restore();
        head={x:x+9,y:sy-45};
        const sweat=Math.floor(r.gait)%5;
        this.rect(x+21+sweat,sy-37+sweat,3,3,'#b9eff4');
      }else g.drawImage(runnerSprite(frame,pose),Math.round(x-32),Math.round(sy-56));
    }
    g.globalAlpha=visibility;
    if(pass){
      g.strokeStyle='rgba(181,238,255,.84)';g.lineWidth=2;
      g.beginPath();g.ellipse(x,(footY+head.y)/2,29,Math.max(6,(footY-head.y)/2+6),0,0,Math.PI*2);g.stroke();
      this.rect(x+22,head.y+10,5,3,'#e2fcff');
    }
    const damageAge=time-r.damageAt;
    this.staminaBar(x,footY+5,idle?1:r.stamina,boost,damageAge>=0&&damageAge<.34,infinite);
    if(damageAge>=0&&damageAge<.78&&visibility>.3){
      g.globalAlpha=1-damageAge/.9;g.font='bold 10px sans-serif';g.strokeStyle='#5d322e';g.lineWidth=2;
      const label=`-${r.damageAmount}%`,at=x+15,high=sy-21-damageAge*25;
      g.strokeText(label,at,high);g.fillStyle='#ffe4d8';g.fillText(label,at,high);
    }
    g.restore();
    return {...head,visible:visibility>.12};
  }
  drawReaction(p:Participant,kind:Reaction,x:number,y:number,angle:number,age:number,duration:number,scale:number,details:ReactionDetails={}){
    const g=this.ctx;
    const avatar=avatars.find(a=>a.id===p.avatarId)??avatars[0];
    const [rearArm,frontArm,rearLeg,frontLeg]=details.limbs??reactionLimbs(kind,age,duration,details.reachX,details.reachY);
    g.save();g.translate(Math.round(x),Math.round(y));g.rotate(angle);g.scale(scale,scale);
    const arm=(rootX:number,limb:typeof frontArm)=>{
      const [jx,jy,ex,ey]=limb;
      this.pixelLimb(rootX,0,jx,jy,avatar.skin);
      this.pixelLimb(jx,jy,ex,ey,avatar.skin);
      this.rect(ex-1,ey-2,4,2,avatar.skin);
    };
    const leg=(rootX:number,limb:typeof frontLeg)=>{
      const [jx,jy,ex,ey]=limb;
      this.pixelLimb(rootX,10,jx,jy,avatar.pants);
      this.pixelLimb(jx,jy,ex,ey,avatar.skin);
      this.rect(ex-3,ey-2,10,7,'#373443');this.rect(ex-2,ey-2,8,4,'#fff1e0');this.rect(ex+1,ey,5,2,'#c2a9b5');
    };
    arm(-6,rearArm);leg(-4,rearLeg);leg(5,frontLeg);
    this.rect(-10,-6,22,20,'#43352f');
    this.rect(-9,-4,19,14,avatar.shirt);this.rect(-7,-4,14,3,p.paletteId);this.rect(-7,10,15,4,avatar.pants);
    this.rect(-4,1,6,3,'#fff0d5');
    arm(6,frontArm);
    const headSprite=sprite(p,0,'run');
    g.drawImage(headSprite,0,0,64,33,-32,-31,64,33);
    if(kind==='flight'||kind==='fall'||kind==='splash'){
      this.rect(10,-5,5,4,'#743d37');this.rect(11,-4,3,2,'#ef9a84');
    }
    if(kind==='phone'){
      const [, ,hx,hy]=frontArm;
      this.rect(hx-2,hy-5,7,10,'#304c58');this.rect(hx-1,hy-4,4,6,'#8cd2d6');
      const wave=Math.floor(age*8)%3;
      this.rect(hx+7,hy-5-wave,3,2,'#fff2ab');this.rect(hx+11,hy-9-wave*2,3,2,'#fff2ab');
    }
    g.restore();
    const sin=Math.sin(angle)*scale,cos=Math.cos(angle)*scale;
    const footY=y+Math.max(rearLeg[2]*sin+rearLeg[3]*cos,frontLeg[2]*sin+frontLeg[3]*cos)+3;
    return {head:{x:x+23*sin,y:y-23*cos},footY:Math.max(y,footY)};
  }
  pixelLimb(x:number,y:number,endX:number,endY:number,color:string){
    const steps=Math.max(1,Math.ceil(Math.hypot(endX-x,endY-y)/3));
    for(let i=0;i<=steps;i++)this.rect(x+(endX-x)*i/steps-3,y+(endY-y)*i/steps-3,7,7,'#42342d');
    for(let i=0;i<=steps;i++)this.rect(x+(endX-x)*i/steps-2,y+(endY-y)*i/steps-2,5,4,color);
  }
  breakProp(r:Runner,x:number,y:number,age:number,pose:'eat'|'drink'){
    const bob=Math.floor(Math.sin(age*6)*2);
    const avatar=avatars.find(a=>a.id===r.participant.avatarId)??avatars[0];
    this.rect(x+10,y-24+bob,9,5,avatar.skin);
    if(pose==='eat'){
      this.rect(x+12,y-23,17,5,'#fff9df');this.rect(x+14,y-18,13,6,'#dc8560');
      this.rect(x+24,y-32+bob,2,12,'#855d42');this.rect(x+28,y-32+bob,2,12,'#855d42');
    }else{
      this.rect(x+15,y-27+bob,10,14,'#83d0da');this.rect(x+14,y-29+bob,12,3,'#fff9dc');
      this.rect(x+19,y-35+bob,2,8,'#e67e80');this.rect(x+19,y-35+bob,7,2,'#e67e80');
    }
  }
  splash(r:Runner,x:number,y:number,age:number){
    const g=this.ctx;
    g.save();
    for(let ring=0;ring<2;ring++){
      const spread=(age-ring*.13)/.75;
      if(spread<0||spread>=1)continue;
      g.globalAlpha=(1-spread)*.8;g.strokeStyle=ring?'#c9f4e9':'#e5fff7';g.lineWidth=2;
      g.beginPath();g.ellipse(x,y+1,9+spread*27,3+spread*8,0,0,Math.PI*2);g.stroke();
    }
    if(age<.64){
      g.globalAlpha=1-ease((age-.28)/.36);
      for(let i=0;i<10;i++){
        const seed=hash(r.index*997+i*413);
        const vx=(i-5)*14,vy=66+seed%85;
        const dx=vx*age,dy=Math.min(2,-vy*age+227*age*age);
        this.rect(x+dx,y+dy,3+seed%3,3+(seed>>>5)%4,i%3?'#9ce2e5':'#e2fffa');
      }
    }
    g.restore();
  }
  nap(r:Runner,x:number,y:number,age:number){
    const g=this.ctx;
    const breath=Math.round((1+Math.sin(age*5))*1.2);
    this.rect(x-31,y-2,61,5,'#49362e');
    this.rect(x-32,y-22,5,25,'#805334');this.rect(x+27,y-11,5,14,'#805334');
    this.rect(x-29,y-16,57,13,'#664335');this.rect(x-27,y-15,53,9,'#fbebc9');
    this.rect(x-27,y-19,22,9,'#fff4dd');this.rect(x-25,y-20,16,4,'#fffaf0');
    g.save();g.translate(x-16,y-17);g.rotate(-.49);
    g.drawImage(sprite(r.participant,0,'run'),0,0,64,33,-21,-17,42,22);
    const avatar=avatars.find(a=>a.id===r.participant.avatarId)??avatars[0];
    this.rect(4,-5,6,4,avatar.skin);this.rect(5,-3,4,1,'#49362e');
    g.restore();
    this.rect(x-4,y-17-breath,32,13+breath,'#385d4c');
    this.rect(x-3,y-16-breath,29,7+breath,r.participant.paletteId);
    this.rect(x-2,y-17-breath,26,2,'#fff0b9');this.rect(x+7,y-12,2,6,'#63806b');this.rect(x+16,y-12,2,6,'#63806b');
    for(let i=0;i<3;i++){
      const drift=(age*.9+i/3)%1;
      g.fillStyle=drift>.62?'#7bab9f':'#fbf4b8';g.font='bold '+Math.round(8+drift*4)+'px sans-serif';
      g.fillText('z',x+4+drift*20,y-28-drift*23);
    }
  }
  staminaBar(x:number,y:number,stamina:number,boost:boolean,hit:boolean,infinite:boolean){
    const width=30,fill=Math.round(width*stamina),left=x-width/2;
    this.rect(left-2,y-1,width+4,6,'#373d32');this.rect(left,y,width,4,'#67634b');
    if(fill>0){this.rect(left,y,fill,4,hit?'#fa7776':boost?'#ffc35d':stamina>.5?'#91ce65':'#efab68');this.rect(left,y,fill,1,hit?'#ffb2a5':boost?'#fff0ad':stamina>.5?'#c4ed95':'#ffd195');}
    if(infinite){this.rect(left,y,width,4,'#8ee8cf');this.rect(left,y,width,1,'#e0fff2');this.ctx.fillStyle='#16564d';this.ctx.font='bold 10px sans-serif';this.ctx.fillText('∞',x-4,y+5);}
  }
  drawImpact(race:Race,time:number){
    const g=this.ctx;
    for(const impact of race.impacts){
      const age=time-impact.at;if(age<0||age>1.05)continue;const r=race.runners[impact.runner];
      const x=impact.x-this.camera;
      if(x<-90||x>this.width+90)continue;
      const y=trackPosition(r.lane,257,this.height-44);
      const respawn=impact.kind!=='fall';const color=impact.kind==='roulette'?'#f5d0ff':respawn?'#e0fff6':'#fff0ac';
      g.save();g.globalAlpha=Math.max(0,1-age/(respawn?1.05:.75));g.strokeStyle=respawn?'#88e0d3':'#f4c96f';g.lineWidth=3;
      g.beginPath();g.ellipse(x,y-3,12+age*42,5+age*15,0,0,Math.PI*2);g.stroke();
      if(respawn){g.fillStyle='rgba(196,255,243,.4)';g.fillRect(x-20,y-94,40,95);this.rect(x-24,y-68,48,3,'#e9fff7');}
      for(let i=0;i<12;i++){const angle=i*Math.PI/6+impact.id*.4;const radius=12+age*65;this.rect(x+Math.cos(angle)*radius,y-24+Math.sin(angle)*radius*.65+age*age*28,respawn?3:5,respawn?7:4,i%2?color:respawn?'#83d7e1':'#e5b96c');}
      if(impact.kind!=='roulette'){g.font='bold 12px sans-serif';g.textAlign='center';g.fillStyle=respawn?'#267d77':'#906139';g.fillText(respawn?'번쩍! 복귀':'앗! 우당탕!',x,y-65-age*18);}
      g.restore();
    }
  }
  drawCandyThrow(age:number){
    const x=this.width*.21,y=216;
    const wind=ease(age/.19),release=ease((age-.20)/.17);
    this.rect(x-10,y-24,20,27,'#523b33');this.rect(x-8,y-21,17,22,'#bc7459');
    this.rect(x-9,y-42,21,21,'#4b3934');this.rect(x-7,y-38,18,15,'#f4bd91');
    this.rect(x+4,y-35,4,4,'#513f36');this.rect(x+5,y-27,5,2,'#b3665a');
    const hx=x+10-wind*14+release*34,hy=y-15-wind*20+release*4;
    this.pixelLimb(x+7,y-16,hx,hy,'#f4bd91');
    const t=Math.max(0,Math.min(1,(age-.23)/.60));
    const candyX=hx+(this.width*.51-hx)*t,candyY=hy+(this.height*.41-hy)*t-88*Math.sin(Math.PI*t);
    const g=this.ctx;g.save();g.translate(candyX,candyY);g.rotate(t*Math.PI*4);
    this.rect(-2,4,4,17,'#fff5d8');this.rect(-9,-8,18,17,'#813d67');this.rect(-7,-9,14,18,'#f4869d');
    this.rect(-5,-5,9,8,'#ffd8ae');this.rect(-2,-2,5,4,'#d86e9a');g.restore();
  }
  drawNames(labels:{r:Runner;x:number;headY:number;rank:number;tracked:boolean}[],preview:boolean){
    const g=this.ctx;
    g.save();
    g.textAlign='center';
    for(const label of labels){
      g.save();g.translate(label.x,label.headY);g.scale(1.17,1.17);
      g.font='bold 10px sans-serif';
      const width=Math.max(34,g.measureText(label.r.participant.name).width+12);
      const {left,top}=headLabelBox(0,0,width);
      g.fillStyle=label.tracked?'#294b36':'rgba(255,249,226,.96)';
      g.beginPath();g.roundRect(left,top+11,width,16,3);g.fill();
      g.fillStyle=label.tracked?'#fff8dc':'#332f27';
      g.fillText(label.r.participant.name,0,top+22);
      g.fillStyle=label.rank===1&&!preview?'#f2c96c':'#365440';
      g.beginPath();g.roundRect(-14,top,28,11,3);g.fill();
      g.fillStyle=label.rank===1&&!preview?'#4b381b':'#fff8de';
      g.font='bold 9px sans-serif';
      g.fillText(preview?'대기':`${label.rank}위`,0,top+8.5);
      g.restore();
    }
    g.restore();
  }
  draw(participants:Participant[],race:Race|null,rule:'first'|'last',uiTime:number,paused:boolean,alpha=1,displayOrder:readonly string[]=[],candyAge=-1,duelSlow=false){
    const time=race?.worldTime??uiTime;if(race!==this.lastRace){this.lastRace=race;this.lastRespawnId=0;this.respawnFlashAt=-Infinity;}this.ctx.save();
    this.ctx.translate(0,this.sceneTop);
    const lanes=Math.min(10,Math.max(2,participants.length));
    const ranked=race?.rank()??[];
    const last=ranked.at(-1);
    if(race){const normal=rule==='first'?ranked[race.completedCount]??last!:last!;
      const specialIndex=race.giant?.runner??(time-race.rainbowStarted<2.4?race.rainbowIndex:null);
      const special=specialIndex===null?null:race.runners[specialIndex];
      const desired=special?.finishTime===null?special:normal;
      if(this.candidate!==desired.index){this.candidate=desired.index;this.candidateSince=time;}
      if(desired===special||time-this.candidateSince>.6||race.runners[this.targetIndex]?.finishTime!==null)this.targetIndex=desired.index;
      if(race.finished)this.targetIndex=normal.index;
      const target=race.runners[this.targetIndex];const respawn=race.impacts.slice().reverse().find(i=>i.kind!=='fall'&&i.runner===this.targetIndex&&i.id!==this.lastRespawnId);if(respawn&&time-respawn.at>=0&&time-respawn.at<1.05){this.camera=target.x-this.width*.37;this.lastRespawnId=respawn.id;this.respawnFlashAt=time;}
      let wanted=target.x-this.width*.37;
      if(duelSlow&&race.duelOvertake){
        const {leader,trailer}=race.duelOvertake;
        const leading=race.runners[leader].x,trailing=race.runners[trailer].x;
        if(Math.abs(leading-trailing)<this.width*.76)wanted=(leading+trailing-this.width)/2;
      }
      const dt=Math.max(0,Math.min(.08,uiTime-this.lastTime));if(!paused)this.camera+=(wanted-this.camera)*(1-Math.exp(-dt*(duelSlow?7:3.5)));
    }else{this.camera=-Math.round(this.width*.24);this.targetIndex=0;}
    this.lastTime=uiTime;
    const impact=race?.impacts.slice().reverse().find(i=>i.runner===this.targetIndex&&time-i.at>=0&&time-i.at<.25);
    const shakeAge=time-(race?.giant?.stompAt??impact?.at??-Infinity);
    if(shakeAge>=0&&shakeAge<.25){const power=(1-shakeAge/.25)*(race?.giant?7:4);this.ctx.translate(Math.round(Math.sin(time*90)*power),Math.round(Math.cos(time*75)*power*.6));}
    this.camera=Math.round(this.camera*100)/100;this.background();
    this.courseDetails(time,race?.finishX??3000,race?.seed??0);
    if(race)this.finishLine(race);
    if(race)for(const o of race.obstacles)this.obstacle(o,time,lanes);
    else {
      this.obstacle({id:1,x:this.width*.5,width:64,type:'puddle',phase:0},time,lanes);
      this.obstacle({id:2,x:this.width*.82,width:34,type:'spinner',phase:0},time,lanes);
    }
    const bottom=this.height-44;
    const runners=race?.runners??participants.map((participant,index)=>({participant,index,x:0,previousX:0,z:0,status:'running',finishTime:null} as Runner));
    const slotOf=(r:Runner)=>{const slot=displayOrder.indexOf(r.participant.id);return slot<0?r.index:slot;};
    const ordered=[...runners].sort((a,b)=>race?a.lane-b.lane||a.index-b.index:(slotOf(a)%lanes)-(slotOf(b)%lanes)||a.index-b.index);
    const positions:{r:Runner;x:number;headY:number;rank:number;tracked:boolean}[]=[];
    const ground=(r:Runner,rx:number)=>race?trackPosition(r.previousLane+(r.lane-r.previousLane)*alpha,257,bottom):groundPosition(slotOf(r),participants.length,rx,257,bottom,0);
    if(race?.giant&&shakeAge>=0&&shakeAge<.5){
      const runner=race.runners[race.giant.runner],x=runner.x-this.camera,y=ground(runner,runner.x);
      const g=this.ctx;g.save();g.globalAlpha=(1-shakeAge/.5)*.82;g.strokeStyle='#fff0a5';g.lineWidth=3;
      for(let ring=0;ring<2;ring++){
        g.beginPath();g.ellipse(x,y+1,21+shakeAge*150+ring*16,6+shakeAge*45+ring*5,0,0,Math.PI*2);g.stroke();
      }
      g.restore();
    }
    const contact=race?.contact;
    const contactTarget=contact?race?.runners[contact.target]:null;
    for(const r of ordered){
      if(r.finishTime!==null&&!(race?.finished&&r===last))continue;
      const rx=race?r.previousX+(r.x-r.previousX)*alpha:0;const x=rx-this.camera;
      if(x<-70||x>this.width+70)continue;
      let y=ground(r,rx);
      let gesture:ContactPose|undefined;
      if(contact&&contactTarget&&contact.actor===r.index){
        const amount=actionBlend(time-contact.started,contact.end-time);
        const targetY=ground(contactTarget,contactTarget.x);
        y+=(targetY-y)*amount*.88;
        gesture={kind:contact.kind,amount,reachX:Math.max(13,Math.min(31,contactTarget.x-rx)),reachY:Math.max(-14,Math.min(14,targetY-y))};
      }
      const tracked=!!race&&this.targetIndex===r.index;
      const giant=race?.giant?.runner===r.index?race.giant:null;
      const size=giant?1+1.45*ease((time-giant.started)/.39)*ease((giant.end-time)/.43):1;
      this.ctx.save();this.ctx.translate(x,y);this.ctx.scale(size,size);this.ctx.translate(-x,-y);
      const head=this.drawRunner(r,x,y,time,!race,race?r.finishTime!==null:false,race?.finished?uiTime:time,gesture,race?.isStompFrozen(r.index));
      this.ctx.restore();
      if(head.visible)positions.push({r,x:x+(head.x-x)*size,headY:y+(head.y-y)*size,rank:ranked.indexOf(r)+1,tracked});
    }
    if(contact?.hit&&contactTarget&&contact.kind==='kick'){
      const age=time-contact.hitAt;
      const x=contactTarget.x-this.camera-12,y=ground(contactTarget,contactTarget.x)-contactTarget.z-19;
      if(age<.3&&x>-30&&x<this.width+30){
        const g=this.ctx;g.save();g.globalAlpha=1-age/.3;
        const radius=5+age*26;
        this.rect(x-2,y-radius,4,radius*2,'#ffe08b');this.rect(x-radius,y-2,radius*2,4,'#ffe08b');
        this.rect(x-3,y-3,6,6,'#fff7d6');g.restore();
      }
    }
    if(race)this.drawImpact(race,time);
    if(race?.beam){
      const b=race.beam;const r=race.runners[b.index];const x=r.x-this.camera;
      const y=ground(r,r.x)-r.z;
      const forward=b.mode==='forward';const color=forward?'#bce58c':'#cda5e8';
      if(x>-100&&x<this.width+100){
        const g=this.ctx;g.save();g.strokeStyle=b.catchUp?'#ffe18b':color;g.lineWidth=3;g.setLineDash(b.phase==='warning'?[5,5]:[]);
        if(b.phase==='moving'){
          g.fillStyle=forward?'rgba(199,247,152,.28)':'rgba(218,180,255,.3)';
          g.beginPath();g.moveTo(x-9,87);g.lineTo(x-25,y+4);g.lineTo(x+25,y+4);g.lineTo(x+9,87);g.fill();
          g.beginPath();g.ellipse(x,y-26,26,33,0,0,Math.PI*2);g.stroke();
        }else if(b.phase==='warning'){g.beginPath();g.moveTo(x,87);g.lineTo(x,y-56);g.stroke();}
        this.rect(x-25,69,50,13,'#667d89');this.rect(x-15,60,30,11,color);this.rect(x-10,82,20,7,color);
        g.fillStyle='#fffdef';g.font='bold 11px sans-serif';g.textAlign='center';
        if(!b.catchUp||b.phase!=='blocked')g.fillText(b.catchUp?'추격 광선 →':b.phase==='blocked'?'보호 중':forward?'앞으로 →':'← 뒤로',x,52);
        g.restore();
      }
    }
    if(race?.ufo){const u=race.ufo;const r=race.runners[u.index];const x=r.x-this.camera;const y=83+Math.sin(time*4)*4;
      if(x>-60&&x<this.width+60){if(!u.warn&&r.status==='frozen'){this.ctx.fillStyle='rgba(186,249,239,.42)';this.ctx.beginPath();this.ctx.moveTo(x-13,y+20);this.ctx.lineTo(x-35,this.height-40);this.ctx.lineTo(x+35,this.height-40);this.ctx.lineTo(x+13,y+20);this.ctx.fill();}else{this.ctx.fillStyle='#eb935d';this.ctx.font='bold 20px sans-serif';this.ctx.fillText('!',x-3,137);}
      this.rect(x-16,y-10,32,17,'#99b4be');this.rect(x-11,y-16,22,9,'#d2fff3');this.rect(x-29,y+4,58,10,'#7e899e');this.rect(x-20,y+14,40,5,'#b9c7dc');for(let j=0;j<4;j++)this.rect(x-21+j*13,y+7,5,3,j%2?'#f1db84':'#a8e8c9');}
    }
    this.drawNames(positions,!race);if(this.canvas.dataset.nameLabels!==String(positions.length))this.canvas.dataset.nameLabels=String(positions.length);if(this.canvas.dataset.rankLabels!==String(positions.length))this.canvas.dataset.rankLabels=String(positions.length);
    if(candyAge>=0&&candyAge<.83)this.drawCandyThrow(candyAge);
    const visibleFinishers=String(positions.filter(p=>p.r.finishTime!==null).length);
    if(this.canvas.dataset.visibleFinishers!==visibleFinishers)this.canvas.dataset.visibleFinishers=visibleFinishers;
    if(!race){const g=this.ctx;g.font='bold 11px sans-serif';g.fillStyle='#fff9e5';g.strokeStyle='#284a45';g.lineWidth=3;g.strokeText('모두 같은 출발선, 행운은 누구에게?',20,28);g.fillText('모두 같은 출발선, 행운은 누구에게?',20,28);}
    const flashAge=time-this.respawnFlashAt;if(race&&!race.finished&&flashAge>=0&&flashAge<.22){this.ctx.fillStyle=`rgba(218,255,247,${(1-flashAge/.22)*.35})`;this.ctx.fillRect(0,-this.sceneTop,this.width,this.canvas.height);}
    this.ctx.restore();
  }
}
