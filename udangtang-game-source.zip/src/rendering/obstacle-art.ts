import {WALL_HEIGHT,type Obstacle} from '../simulation/engine.ts';

const spriteNames=['puddle','mud','spinnerPost','spinnerBeam','hammerStand','hammer','platformPit','platformBoard','banana','hole','wall','spring'] as const;
type SpriteName=(typeof spriteNames)[number];
type Region={x:number;y:number;width:number;height:number};
type ObstacleArt={image:HTMLImageElement;regions:Record<SpriteName,Region>};
const CELL=128;

export async function loadObstacleArt():Promise<ObstacleArt|null>{
  const image=new Image();
  image.src=`${import.meta.env.BASE_URL}assets/maps/woodland-obstacles-higgsfield.png`;
  try{await image.decode();}catch{return null;}
  if(image.width!==CELL*4||image.height!==CELL*3)return null;
  const canvas=document.createElement('canvas');
  canvas.width=image.width;canvas.height=image.height;
  const ctx=canvas.getContext('2d')!;
  ctx.drawImage(image,0,0);
  const {data}=ctx.getImageData(0,0,canvas.width,canvas.height);
  const regions={} as Record<SpriteName,Region>;
  for(const [index,name] of spriteNames.entries()){
    const originX=index%4*CELL,originY=Math.floor(index/4)*CELL;
    let left=CELL,top=CELL,right=-1,bottom=-1;
    for(let y=0;y<CELL;y++)for(let x=0;x<CELL;x++){
      if(data[((originY+y)*canvas.width+originX+x)*4+3]<24)continue;
      left=Math.min(left,x);top=Math.min(top,y);right=Math.max(right,x);bottom=Math.max(bottom,y);
    }
    if(right-left<4||bottom-top<4)return null;
    regions[name]={x:originX+left,y:originY+top,width:right-left+1,height:bottom-top+1};
  }
  return {image,regions};
}

export function drawObstacleArt(ctx:CanvasRenderingContext2D,art:ObstacleArt,o:Obstacle,x:number,top:number,bottom:number,rows:number,time:number){
  const height=bottom-top,middle=(top+bottom)/2;
  const sprite=(name:SpriteName,left:number,upper:number,width:number,depth:number)=>{
    const r=art.regions[name];
    ctx.drawImage(art.image,r.x,r.y,r.width,r.height,Math.round(left),Math.round(upper),Math.round(width),Math.round(depth));
  };
  switch(o.type){
    case 'puddle':
      sprite('puddle',x-3,top-1,o.width+6,height+2);
      ctx.save();ctx.globalAlpha=.35+.2*Math.sin(time*3+o.phase);ctx.fillStyle='#e2f8ec';
      ctx.fillRect(x+o.width*.3,Math.round(middle),8,1);ctx.fillRect(x+o.width*.62,Math.round(middle)+5,5,1);ctx.restore();
      return;
    case 'mud':
    case 'hole':
      sprite(o.type,x-3,top-1,o.width+6,height+2);
      return;
    case 'banana':
      sprite('banana',x+2,middle-12,o.width-4,16);
      return;
    case 'wall':
      sprite('wall',x-5,top-WALL_HEIGHT-4,o.width+10,height+WALL_HEIGHT+4);
      return;
    case 'platform':{
      sprite('platformPit',x-3,top-2,o.width+6,height+4);
      const center=x+o.width/2+Math.sin(time*1.8+o.phase)*27;
      sprite('platformBoard',center-18,top-2,36,height+4);
      return;
    }
  }
  for(let lane=0;lane<rows;lane++){
    const y=top+(lane+.5)/rows*height;
    if(o.type==='spring'){
      const squash=Math.round(Math.sin(time*5+o.phase)*2);
      sprite('spring',x+4,y-26+squash,o.width-8,28-squash);
    }else if(o.type==='spinner'){
      sprite('spinnerPost',x+8,y-35,14,37);
      ctx.save();ctx.translate(x+15,y-25);ctx.rotate(time*3+o.phase);
      sprite('spinnerBeam',-31,-6,62,12);ctx.restore();
    }else{
      const swing=Math.sin(time*3.6+o.phase);
      const hammerTop=y-72+swing*22;
      if(hammerTop>y-67){ctx.fillStyle='#755441';ctx.fillRect(x+31,y-67,4,hammerTop-y+70);}
      ctx.save();ctx.beginPath();ctx.rect(x-2,y-69,o.width+10,74);ctx.clip();
      sprite('hammer',x+17,hammerTop,30,52);ctx.restore();
      sprite('hammerStand',x+4,y-72,32,74);
    }
  }
}
