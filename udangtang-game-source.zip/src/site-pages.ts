export type SitePage='home'|'race'|'sports';
export const SITE_URL='https://udangtang-pixel-runners.housecats850262.chatgpt.site/';
export const SITE_NAME='우당탕 게임룸';
export const pages={
  home:{title:'우당탕 게임룸 | 우당탕 달리기 · 우당탕 올림픽',description:'우당탕 달리기와 우당탕 올림픽을 한 곳에서! 최대 35명의 랜덤 장애물 레이스와 최대 8명이 휴대폰으로 함께하는 8종 경기, 혼자 연습까지 즐겨보세요.',url:SITE_URL},
  race:{title:'우당탕 달리기 | 우당탕 게임룸',description:'최대 35명이 자동으로 달리는 도트 장애물 레이스. 300m, 500m, 1km 코스에서 1등 또는 꼴찌를 뽑아보세요. 우당탕 게임룸에서 함께 즐겨요.',url:SITE_URL+'?game=race'},
  sports:{title:'우당탕 올림픽 | 우당탕 게임룸',description:'최대 8명이 휴대폰 A·B·C 버튼으로 함께하는 우당탕 올림픽. 수영, 클레이 사격, 도마, 양궁, 세단뛰기, 역도, 장대높이뛰기, 100m 장애물 달리기와 혼자 연습을 즐겨보세요.',url:SITE_URL+'?game=sports'},
} as const;
export function sitePage(search:string):SitePage {
  const game=new URLSearchParams(search).get('game');
  return game==='race'?'race':game==='sports'||game==='olympics'?'sports':'home';
}
export function siteSchema(page:SitePage) {
  const website={'@type':'WebSite','@id':SITE_URL+'#website',name:SITE_NAME,alternateName:'Udangtang Game Room',url:SITE_URL,inLanguage:'ko-KR'};
  const games=(['race','sports'] as const).map(id=>({'@type':'VideoGame','@id':pages[id].url+'#game',name:id==='race'?'우당탕 달리기':'우당탕 올림픽',url:pages[id].url,description:pages[id].description,applicationCategory:'Game',operatingSystem:'Web browser',isAccessibleForFree:true,isPartOf:{'@id':website['@id']}}));
  return {'@context':'https://schema.org','@graph':page==='home'?[website,{'@type':'CollectionPage',name:SITE_NAME,url:SITE_URL,isPartOf:{'@id':website['@id']},mainEntity:{'@type':'ItemList',itemListElement:games.map((game,i)=>({'@type':'ListItem',position:i+1,item:game}))}}]:[website,games[page==='race'?0:1]]};
}
const escape=(value:string)=>value.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
export function metadataHTML(page:SitePage,room=false) {
  const info=pages[page];
  return `<title>${info.title}</title>
  <meta name="description" content="${escape(info.description)}"/>
  <meta name="robots" content="${room?'noindex,follow':'index,follow'}"/>
  <link rel="canonical" href="${escape(info.url)}"/>
  <meta property="og:type" content="website"/>
  <meta property="og:locale" content="ko_KR"/>
  <meta property="og:site_name" content="${SITE_NAME}"/>
  <meta property="og:title" content="${info.title}"/>
  <meta property="og:description" content="${escape(info.description)}"/>
  <meta property="og:url" content="${escape(info.url)}"/>
  <meta property="og:image" content="${SITE_URL}assets/maps/woodland-festival-v1.png"/>
  <meta name="twitter:card" content="summary_large_image"/>
  <meta name="twitter:title" content="${info.title}"/>
  <meta name="twitter:description" content="${escape(info.description)}"/>
  <script type="application/ld+json">${JSON.stringify(siteSchema(page))}</script>`;
}
export function raceShell() {
  return `<main><div class="intro"><div><div class="eyebrow">READY, SET, A LITTLE BIT OF LUCK!</div><h1>우당탕 달리기 <em>랜덤 장애물 레이스</em></h1><p>최대 35명이 자동으로 달리는 도트 장애물 레이스. 1등 또는 꼴찌를 뽑아보세요.</p></div><div class="weather"><i class="sun"></i><div>달리기 딱 좋은 날씨<br><span style="color:#a1ac91;font-size:9px">숲속 운동장에서 만나요</span></div></div></div><div id="app"></div></main>`;
}
export function renderSiteDocument(template:string,url:URL) {
  const page=sitePage(url.search);
  let html=template.replace(/<!-- site-meta:start -->[\s\S]*?<!-- site-meta:end -->/,`<!-- site-meta:start -->${metadataHTML(page,url.searchParams.has('room'))}<!-- site-meta:end -->`);
  if(page!=='home')html=html.replace(/<!-- site-main:start -->[\s\S]*?<!-- site-main:end -->/,`<!-- site-main:start -->${page==='race'?raceShell():`<main><h1>우당탕 올림픽</h1><p>${pages.sports.description}</p><a href="./">우당탕 게임룸 홈</a></main>`}<!-- site-main:end -->`);
  return html;
}
export function updatePageMetadata(page:SitePage) {
  const nodes=Array.from(document.head.childNodes);
  const start=nodes.findIndex(n=>n.nodeType===8&&n.textContent?.trim()==='site-meta:start');
  const end=nodes.findIndex(n=>n.nodeType===8&&n.textContent?.trim()==='site-meta:end');
  if(start<0||end<start)return;
  for(const node of nodes.slice(start+1,end))node.parentNode?.removeChild(node);
  const block=document.createElement('template');block.innerHTML=metadataHTML(page,new URLSearchParams(location.search).has('room'));
  document.head.insertBefore(block.content,nodes[end]);
}
