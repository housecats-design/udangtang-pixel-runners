import './site-header.css';
import {version} from '../../package.json';
export function siteHeader(active:'home'|'race'|'sports',soundEnabled:boolean) {
  return `<header class="site-header">
    <a class="site-brand" href="./" aria-label="우당탕 게임룸 홈"><span class="site-logo" aria-hidden="true"><svg viewBox="0 0 32 32"><path d="M15 3h8v7h-8zM10 12h10v6H10zM6 12h5v5H6zM19 15h7v4h-7zM11 18h7v6h-7zM5 23h10v5H5zM18 21h5v7h-5z" fill="#fff8dc"/><path d="M23 4h3v5h-3z" fill="#466348"/></svg></span><span><span class="site-brand-title">우당탕 게임룸<small>ver. ${version}</small></span><span class="site-brand-sub">LITTLE PLAYERS, BIG FUN</span></span></a>
    <nav class="site-game-menu" aria-label="게임 선택"><a href="./" ${active==='home'?'aria-current="page"':''}>게임룸</a><a href="?game=race" ${active==='race'?'aria-current="page"':''}>우당탕 달리기</a><a href="?game=sports" ${active==='sports'?'aria-current="page"':''}>우당탕 올림픽</a></nav>
    <div class="site-header-actions">${active==='home'?'':`<button class="site-header-button" id="site-sound" aria-pressed="${soundEnabled}" aria-label="${soundEnabled?'소리 끄기':'소리 켜기'}">${soundEnabled?'♫ 소리 켜짐':'♫ 소리 꺼짐'}</button>`}<button class="site-header-button site-help" id="help"><span>?</span> 이용 가이드</button></div>
  </header>`;
}
export function updateHeaderSound(enabled:boolean) {
  const button=document.querySelector<HTMLButtonElement>('#site-sound');
  if(!button)return;
  button.textContent=enabled?'♫ 소리 켜짐':'♫ 소리 꺼짐';
  button.setAttribute('aria-pressed',String(enabled));
  button.setAttribute('aria-label',enabled?'소리 끄기':'소리 켜기');
}
