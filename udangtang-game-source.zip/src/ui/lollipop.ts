import {CANDY_BOOST_SECONDS,CANDY_SPEED_MULTIPLIER} from '../simulation/engine.ts';

const THROW_END=.83;
const SPIN_START=1.28;
const SPIN_END=4.8;
export const LOLLIPOP_END=6.45;

const colors=['#f5a49d','#f3d686','#aed494','#88cbd0','#a7b9ec','#c5a8d9'];

export class LollipopWheel {
  private canvas:HTMLCanvasElement;
  private caption:HTMLElement;
  private winnerName='';
  private stopAngle=0;

  constructor(private overlay:HTMLElement){
    this.canvas=overlay.querySelector('canvas')!;
    this.caption=overlay.querySelector('.lollipop-caption')!;
  }

  prepare(names:readonly string[],winner:number){
    const g=this.canvas.getContext('2d')!;
    const center=this.canvas.width/2,radius=center-5,segment=Math.PI*2/names.length;
    this.winnerName=names[winner];
    this.stopAngle=Math.PI*12-(winner+.5)*segment;
    this.canvas.setAttribute('aria-label',`룰렛 참가자 ${names.join(', ')}`);
    this.canvas.style.transform='';
    g.clearRect(0,0,center*2,center*2);
    for(const [i,name] of names.entries()){
      const angle=-Math.PI/2+i*segment;
      g.beginPath();g.moveTo(center,center);g.arc(center,center,radius,angle,angle+segment);g.closePath();
      g.fillStyle=colors[i%colors.length];g.fill();g.lineWidth=2;g.strokeStyle='#fff4df';g.stroke();
      g.save();g.translate(center,center);g.rotate(angle+segment/2);
      g.textBaseline='middle';g.textAlign='right';g.fillStyle='#2c453c';
      g.font=`bold ${names.length>25?14:names.length>15?17:21}px sans-serif`;
      g.fillText(name,radius-13,0,radius-45);g.restore();
    }
    g.beginPath();g.arc(center,center,24,0,Math.PI*2);g.fillStyle='#fff3d8';g.fill();
    g.lineWidth=4;g.strokeStyle='#60503e';g.stroke();
    g.fillStyle='#ea8296';g.fillRect(center-7,center-7,14,14);
    this.caption.textContent='누가 막대사탕을 받을까요?';
  }

  render(age:number){
    this.overlay.hidden=age<THROW_END;
    if(age<THROW_END)return;
    const t=Math.max(0,Math.min(1,(age-SPIN_START)/(SPIN_END-SPIN_START)));
    const motion=matchMedia('(prefers-reduced-motion: reduce)').matches?t===1?1:0:1-(1-t)**3.5;
    this.canvas.style.transform=`rotate(${this.stopAngle*motion}rad)`;
    if(t===1){
      const result=`${this.winnerName} 당첨! ${CANDY_BOOST_SECONDS}초간 달리기 속도 ${CANDY_SPEED_MULTIPLIER}배`;
      if(this.caption.textContent!==result)this.caption.textContent=result;
    }
  }

  hide(){this.overlay.hidden=true;}
}
