import {LOLLIPOP_THROW_SECONDS,lollipopDescription,lollipopRewards,type Lollipop} from '../simulation/lollipop.ts';

const REWARD_START=.65;
const REWARD_END=2.25;
const TARGET_START=2.75;
const TARGET_END=4.15;
const RESULT_HOLD=1.4;
const TURN=2*Math.PI;
const colors=['#f5a49d','#f3d686','#aed494','#88cbd0','#a7b9ec','#c5a8d9'];
const rewardWeights=lollipopRewards.map(reward=>reward.weight/100);

export class LollipopWheel {
  private canvas:HTMLCanvasElement;
  private caption:HTMLElement;
  private round:HTMLElement;
  private labels:readonly string[]=[];
  private rewardIndex=0;
  private draw:Lollipop|null=null;
  private showingTargets=false;
  private centers:number[]=[];

  constructor(private overlay:HTMLElement){
    this.canvas=overlay.querySelector('canvas')!;
    this.caption=overlay.querySelector('.lollipop-caption')!;
    this.round=overlay.querySelector('.lollipop-round')!;
  }

  prepare(draw:Lollipop,names:readonly string[],roundLabel:string){
    this.draw=draw;
    this.labels=names;
    this.rewardIndex=lollipopRewards.findIndex(reward=>reward.id===draw.reward);
    this.showingTargets=false;
    this.round.textContent=roundLabel;
    this.caption.textContent='어떤 보상이 나올까요?';
    this.paint(lollipopRewards.map(reward=>reward.label),'룰렛 보상',rewardWeights);
  }

  private paint(labels:readonly string[],title:string,weights?:readonly number[]){
    const g=this.canvas.getContext('2d')!;
    const center=this.canvas.width/2,radius=center-5;
    this.canvas.setAttribute('aria-label',`${title} ${labels.join(', ')}`);
    g.clearRect(0,0,center*2,center*2);
    let angle=0;
    this.centers=[];
    for(const [i,label] of labels.entries()){
      const segment=TURN*(weights?.[i]??1/labels.length);
      const middle=angle+segment/2;
      this.centers.push(middle);
      g.beginPath();g.moveTo(center,center);g.arc(center,center,radius,angle-Math.PI/2,angle+segment-Math.PI/2);g.closePath();
      g.fillStyle=colors[i%colors.length];g.fill();g.lineWidth=2;g.strokeStyle='#fff4df';g.stroke();
      g.save();g.translate(center,center);g.rotate(middle-Math.PI/2);
      g.textBaseline='middle';g.textAlign='right';g.fillStyle='#2c453c';
      g.font=`bold ${segment<.15||labels.length>25?14:labels.length>15?17:22}px sans-serif`;
      g.fillText(label,radius-13,0,radius-46);g.restore();
      angle+=segment;
    }
    g.beginPath();g.arc(center,center,24,0,Math.PI*2);g.fillStyle='#fff3d8';g.fill();
    g.lineWidth=4;g.strokeStyle='#60503e';g.stroke();
    g.fillStyle='#ea8296';g.fillRect(center-7,center-7,14,14);
  }

  render(age:number):boolean{
    const draw=this.draw;
    if(!draw)return false;
    this.overlay.hidden=age<LOLLIPOP_THROW_SECONDS;
    if(age<LOLLIPOP_THROW_SECONDS)return false;
    const reward=lollipopRewards[this.rewardIndex];
    const targets=reward.individual&&age>=TARGET_START;
    if(targets&&!this.showingTargets){
      this.showingTargets=true;
      this.paint(this.labels,'룰렛 참가자');
    }
    const start=targets?TARGET_START:REWARD_START,end=targets?TARGET_END:REWARD_END;
    const index=targets?draw.winner:this.rewardIndex;
    const t=Math.max(0,Math.min(1,(age-start)/(end-start)));
    const motion=matchMedia('(prefers-reduced-motion: reduce)').matches?Number(t===1):1-(1-t)**3.5;
    const angle=TURN*(targets?2:3)-this.centers[index];
    this.canvas.style.transform=`rotate(${angle*motion}rad)`;
    const message=targets
      ?t<1?`${reward.label} · 누가 받을까요?`:`${this.labels[draw.winner]} 당첨! ${lollipopDescription(draw)}`
      :age<REWARD_END?'어떤 보상이 나올까요?':reward.individual?`${reward.label} 당첨! 참가자를 뽑아요.`:lollipopDescription(draw);
    if(this.caption.textContent!==message)this.caption.textContent=message;
    return age>=(reward.individual?TARGET_END:REWARD_END)+RESULT_HOLD;
  }

  hide(){this.overlay.hidden=true;}
}
