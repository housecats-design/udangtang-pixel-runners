/** Display order only. Does not reorder participants or touch simulation RNG. */
export function shuffleLineup(ids:readonly string[],random=()=>Math.random()):string[]{
  const order=[...ids];
  for(let i=order.length-1;i>0;i--){const j=Math.min(i,Math.floor(Math.max(0,random())*(i+1)));[order[i],order[j]]=[order[j],order[i]];}
  return order;
}
