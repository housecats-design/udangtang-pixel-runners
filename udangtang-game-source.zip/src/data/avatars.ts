export const avatars = [
  {id:'human-01',name:'민트 러너',hair:'#624336',skin:'#ffcfaa',shirt:'#3bbba2',pants:'#30495e',style:0},
  {id:'human-02',name:'햇살 러너',hair:'#543749',skin:'#f9c29e',shirt:'#f4c64c',pants:'#745373',style:1},
  {id:'human-03',name:'복숭아 러너',hair:'#bf6c46',skin:'#ffdbc1',shirt:'#ee8290',pants:'#586080',style:2},
  {id:'human-04',name:'하늘 러너',hair:'#30364c',skin:'#d59670',shirt:'#6ca9ed',pants:'#3a4967',style:3},
  {id:'human-05',name:'라일락 러너',hair:'#e4b76e',skin:'#ffe0bc',shirt:'#aa8bda',pants:'#65518b',style:1},
  {id:'human-06',name:'귤빛 러너',hair:'#58433c',skin:'#f5b88d',shirt:'#f39454',pants:'#665044',style:2},
  {id:'human-07',name:'클로버 러너',hair:'#905a3a',skin:'#ffe0bd',shirt:'#87b754',pants:'#475747',style:3},
  {id:'human-08',name:'체리 러너',hair:'#353442',skin:'#c78964',shirt:'#db6370',pants:'#483d63',style:0},
];
export const animals=[
  {id:'rabbit',name:'토끼',shirt:'#a68ec7'},
  {id:'fox',name:'여우',shirt:'#e68448'},
  {id:'duck',name:'오리',shirt:'#e5b741'},
] as const;
export type Animal=(typeof animals)[number];
export const avatarChoices=[...avatars,...animals];
export function animalAvatar(id:string){return animals.find(animal=>animal.id===id)??null;}
export const palettes=['#43b8a0','#f0c34d','#ee8190','#73a9ed','#ae8ad9','#f59a5a','#91b65c','#dd667c'];
export type Participant={id:string;name:string;avatarId:string;paletteId:string};
export const RACE_DISTANCES=[300,500,1000] as const;
export type RaceDistance=typeof RACE_DISTANCES[number];
export type Settings={distanceMeters:RaceDistance;winnerRule:'first'|'last';soundEnabled:boolean};
const initialOffset=crypto.getRandomValues(new Uint32Array(2));
export const newParticipant=(index:number):Participant=>({id:crypto.randomUUID(),name:`참가자 ${index+1}`,avatarId:avatars[(index+initialOffset[0])%8].id,paletteId:palettes[(Math.floor(index/8)+initialOffset[1])%8]});
