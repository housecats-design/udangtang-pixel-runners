import {avatars,palettes,RACE_DISTANCES,type Participant,type Settings} from '../data/avatars.ts';
export const STORAGE_KEY='udangtang.pixel-race.v1';
export const defaultSettings:Settings={distanceMeters:300,winnerRule:'first',soundEnabled:true};
export type SaveData={schemaVersion:2;participants:Participant[];settings:Settings};
export function parseSave(raw:string):SaveData|null {
  try {
    const d=JSON.parse(raw);
    if(![1,2].includes(d.schemaVersion)||!Array.isArray(d.participants)||d.participants.length<2||d.participants.length>35)return null;
    const ids=new Set<string>();
    for(const p of d.participants){
      if(!p||typeof p.id!=='string'||!p.id||ids.has(p.id)||typeof p.name!=='string'||p.name.length>12||!avatars.some(a=>a.id===p.avatarId)||!palettes.includes(p.paletteId))return null;
      ids.add(p.id);
    }
    const s=d.settings;
    if(!s||!['first','last'].includes(s.winnerRule)||typeof s.soundEnabled!=='boolean')return null;
    if(d.schemaVersion===1){if(!Number.isInteger(s.durationSeconds)||s.durationSeconds<60||s.durationSeconds>600)return null;return {schemaVersion:2,participants:d.participants,settings:{distanceMeters:300,winnerRule:s.winnerRule,soundEnabled:s.soundEnabled}};}
    if(!RACE_DISTANCES.includes(s.distanceMeters))return null;
    return {schemaVersion:2,participants:d.participants,settings:{distanceMeters:s.distanceMeters,winnerRule:s.winnerRule,soundEnabled:s.soundEnabled}};
  }catch{return null;}
}
export function load(storage:Pick<Storage,'getItem'>):{data:SaveData|null;error:boolean}{
  try{const raw=storage.getItem(STORAGE_KEY);const data=raw?parseSave(raw):null;return {data,error:!!raw&&!data};}catch{return {data:null,error:true};}
}
export function save(storage:Pick<Storage,'setItem'>,participants:Participant[],settings:Settings):boolean{
  try{storage.setItem(STORAGE_KEY,JSON.stringify({schemaVersion:2,participants,settings}));return true;}catch{return false;}
}
