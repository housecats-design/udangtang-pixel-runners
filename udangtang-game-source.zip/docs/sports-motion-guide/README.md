# 우당탕 올림픽 동작 컷 도감

기준: 게임 v1.1.13. 게임 실행 코드를 변경하지 않는 검토 자료입니다.

- `catalog.ts`: 종목별 76개 컷의 ID, 이름, 조작, 실제 구현 상태, 검토용 선수 상태.
- `preview.ts` / `preview.html`: 기존 `SportCanvas`와 `SportsArena`로 실제 게임 이미지를 렌더링하고 6개 대표 프레임을 저장.
- `background.ts`: 실제 렌더러에서 풍경과 경기 시설만 분리한 캐릭터 없는 배경. 게임 렌더러를 바꾸면 이 파일도 함께 대조해야 합니다.
- `build-guide.py`: PNG 내보내기 결과를 검색·확대·대표 프레임 재생이 가능한 오프라인 도감과 Markdown 목록으로 묶습니다.

## 다시 만들기

1. `npm run dev -- --port 5190`으로 로컬 미리보기를 실행합니다.
2. `/docs/sports-motion-guide/preview.html`에서 이미지 로딩이 완료되면 **동작 컷과 배경 ZIP 저장**을 누릅니다.
3. ZIP의 `images/`와 `catalog.json`을 `artifacts/sports-motion-guide-v1.1.13/`에 풀어 놓습니다.
4. `python3 docs/sports-motion-guide/build-guide.py`를 실행합니다.

`?export=SWM`처럼 접두어를 주면 특정 종목 이미지만 내보낼 수 있습니다. 최초에는 전체 내보내기가 필요합니다.

완성 파일:

- `artifacts/sports-motion-guide-v1.1.13/우당탕_올림픽_동작도감.html`: 단일 HTML. 인터넷과 로컬 서버 없이 사용.
- `artifacts/sports-motion-guide-v1.1.13/index.html`: 분리된 PNG를 이용하는 가벼운 도감.
- `artifacts/sports-motion-guide-v1.1.13/동작_컷_목록.md`: 76개 컷 목록, 현재 부족한 동작, 관련 코드 위치.
- `artifacts/우당탕_올림픽_동작자료_v1.1.13.zip`: PNG, 6프레임 스트립, 도감, 목록 묶음.

컷 번호는 검토용 분류입니다. 같은 게임 내부 상태가 여러 컷에 대응할 수 있습니다. 대표 프레임은 통제된 선수 상태를 렌더링한 것으로 실제 경기 영상이 아닙니다. 캐릭터 없는 배경에서는 선수, 이름, 게이지, 발사체를 제외하고 관중석과 경기 시설은 유지합니다.
