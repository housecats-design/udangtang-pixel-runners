// Review-only scenery extracted from the v1.1.13 renderers. No game runtime is changed.
import {stadium,target} from '../../src/sports/render.ts';
import {HURDLES} from '../../src/sports/hurdles.ts';
import {drawHurdle} from '../../src/sports/hurdles-render.ts';
import {arenaLanes,arenaStations} from '../../src/sports/arena-layout.ts';
import type {SportId} from '../../src/sports/model.ts';
const box=(g:CanvasRenderingContext2D,x:number,y:number,w:number,h:number,c:string)=>{g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
const line=(g:CanvasRenderingContext2D,x:number,y:number,ex:number,ey:number,c:string,width=2)=>{g.strokeStyle=c;g.lineWidth=width;g.beginPath();g.moveTo(x,y);g.lineTo(ex,ey);g.stroke();};
const text=(g:CanvasRenderingContext2D,s:string,x:number,y:number,size=14)=>{g.fillStyle='#557762';g.font=`bold ${size}px sans-serif`;g.textAlign='center';g.fillText(s,x,y);};
export function background(canvas:HTMLCanvasElement,sport:SportId,shared=false){
  canvas.width=shared?1280:480;canvas.height=shared?760:250;
  const g=canvas.getContext('2d')!;g.imageSmoothingEnabled=false;
  stadium(g,canvas.width,shared?350:250,10);
  if(!shared){
    if(sport==='hurdles'){
      box(g,0,190,480,60,'#d69677');box(g,0,239,480,3,'#f3d8b0');
      for(let m=0;m<=100;m+=10){const x=60+m*18;box(g,x,244,2,6,'#f1c8a0');text(g,String(m),x,185,10);}
      for(const m of HURDLES){const x=60+m*18;if(x<520)drawHurdle(g,x,222);}
    }else if(sport==='swimming'){
      box(g,0,157,480,93,'#389db9');
      for(let row=0;row<4;row++){const y=164+row*23;for(let c=0;c<32;c++)box(g,c*16,y,10,3,c%3?'#f5d677':'#ed8a79');for(let c=0;c<14;c++)box(g,(c*39+190)%480,y+12,13,2,'#8ad2d3');}
      box(g,34,158,4,92,'#f5f3da');box(g,442,158,5,92,'#f5f3da');
    }else if(sport==='skeet'){
      box(g,0,163,480,87,'#8fad72');
      for(const [i,x] of [155,325].entries()){g.fillStyle='#fff8df22';g.fillRect(x-24,103,48,44);g.strokeStyle='#fff2cc';g.lineWidth=2;g.strokeRect(x-24,103,48,44);text(g,i?'C · 오른쪽':'A · 왼쪽',x,95,10);}
    }else if(sport==='vault')vaultScenery(g);
    else if(sport==='archery'){box(g,376,143,5,90,'#906e4d');target(g,379,125,34);}
    else if(sport==='triple'){box(g,247,188,5,55,'#fff3d2');box(g,328,188,145,55,'#d9c590');for(let i=0;i<12;i++)box(g,334+i*12,193+i%3*8,3,2,'#b9a77c');}
    else if(sport==='weightlifting'){box(g,90,215,300,15,'#c0aa7c');box(g,100,212,280,4,'#f1dab0');for(let i=0;i<3;i++){g.fillStyle='#6e8379';g.beginPath();g.ellipse(333+i*25,141,7,7,0,0,Math.PI*2);g.fill();}}
    else{box(g,335,209,130,25,'#6caab6');box(g,344,94,5,120,'#f7ebca');box(g,407,94,5,120,'#f7ebca');box(g,340,105,77,3,'#e5b056');}
    return;
  }
  box(g,0,220,1280,540,sport==='swimming'?'#d8e6c9':sport==='weightlifting'?'#b9cba4':'#9dbb80');
  const lanes=arenaLanes(8),top=lanes[0].top,bottom=740;
  if(sport==='swimming'){
    box(g,151,top-8,1065,bottom-top+16,'#f6efd4');box(g,160,top,1048,bottom-top,'#60aebb');
    for(let i=0;i<=8;i++)for(let x=166;x<1200;x+=21)box(g,x,top+i*60-2,13,4,(Math.floor(x/21)+i)%3?'#f4d98b':'#e9a58c');
    for(const lane of lanes)box(g,160,lane.top,1048,lane.height,lane.index%2?'#ffffff0d':'#ffffff00');
    line(g,194,top,194,bottom,'#fff6d9',4);line(g,1172,top,1172,bottom,'#fff6d9',4);text(g,'0 / 100m',194,top-18);text(g,'50m · 턴',1172,top-18);
  }else if(sport==='weightlifting'){
    box(g,35,285,1210,445,'#c7b48c');for(let y=300;y<760;y+=38)line(g,35,y,1245,y,'#e6d5ac');
    for(const s of arenaStations(8)){box(g,s.x-95,s.y,190,13,'#9b8866');box(g,s.x-90,s.y-4,180,5,'#f4dba6');for(let i=0;i<3;i++)box(g,s.x+50+i*12,s.y-73,8,8,'#839274');}
  }else if(sport==='skeet'){
    for(const s of arenaStations(8)){g.save();g.translate(s.x,s.y);g.scale(s.scale,s.scale);g.translate(-240,-229);for(const [i,x] of [155,325].entries()){g.fillStyle='#fff8df22';g.fillRect(x-24,103,48,44);g.strokeStyle='#fff2cc';g.lineWidth=2;g.strokeRect(x-24,103,48,44);text(g,i?'C · 오른쪽':'A · 왼쪽',x,95,10);}g.restore();}
  }else if(sport==='archery'){
    for(const lane of lanes){const floor=lane.y+22,y=lane.y-5;box(g,20,lane.top,1240,lane.height,lane.index%2?'#ffffff0d':'#ffffff00');line(g,1125,y+15,1125,floor+7,'#8a7953',3);target(g,1125,y,Math.min(24,lane.height*.32));line(g,1010,lane.y-5,1022,lane.y-5,'#fff9d8');line(g,1016,lane.y-11,1016,lane.y+1,'#fff9d8');}
  }else if(sport==='vault'){
    for(const lane of lanes){g.save();g.translate(160,lane.y+20);g.scale(2.15,.85);g.translate(0,-210);vaultScenery(g);g.restore();}
  }else{
    box(g,160,top-8,1048,bottom-top+16,'#d69677');for(let i=0;i<=8;i++)line(g,160,top+i*60,1208,top+i*60,'#f2d5ae');line(g,220,top,220,bottom,'#fff2ca',3);
    for(const lane of lanes){const floor=lane.y+(sport==='hurdles'?23:20);box(g,160,lane.top,1048,lane.height,lane.index%2?'#ffffff0d':'#ffffff00');
      if(sport==='hurdles')for(const m of HURDLES)drawHurdle(g,220+m*9.4,floor,.78);
      else if(sport==='triple'){line(g,682,lane.top+5,682,lane.top+55,'#fff4d7',3);box(g,960,lane.top+6,225,lane.height-12,'#e2cc99');for(let i=0;i<20;i++)box(g,966+i*10,lane.y+(i%3-1)*10,3,2,'#bca475');}
      else{box(g,950,floor+1,230,12,'#79aeb6');line(g,970,floor-100,970,floor,'#f9e9c1',4);line(g,1090,floor-100,1090,floor,'#f9e9c1',4);line(g,965,floor-85,1095,floor-85,'#e9c275',3);}
    }
    if(sport==='hurdles'){for(const m of [0,25,50,75,100])text(g,`${m}m`,220+m*9.4,top-16);for(let r=0;r<48;r++)for(let col=0;col<2;col++)box(g,1165+col*7,top+r*10,7,10,(r+col)%2?'#3d5c4e':'#fff3d3');}
  }
}
function vaultScenery(g:CanvasRenderingContext2D){box(g,252,174,64,14,'#ba7657');box(g,256,188,8,25,'#576859');box(g,302,188,8,25,'#576859');box(g,228,209,26,6,'#f5d077');box(g,335,213,130,16,'#64a7ac');box(g,335,213,130,3,'#a6d1c7');}
