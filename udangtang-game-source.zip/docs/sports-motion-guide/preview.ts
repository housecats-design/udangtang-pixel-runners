import {chapters,type Cut} from './catalog.ts';
import {background} from './background.ts';
import {loadRunnerAtlas} from '../../src/rendering/renderer.ts';
import {loadVaultMotions} from '../../src/sports/vault-motion.ts';
import {loadSwimmingMotion} from '../../src/sports/swimming-motion.ts';
import {loadSkeetMotion} from '../../src/sports/skeet-motion.ts';
import {SportCanvas} from '../../src/sports/render.ts';
import {SportsArena} from '../../src/sports/arena.ts';
import {createMatch,startRound} from '../../src/sports/engine.ts';
import {hurdleHeight} from '../../src/sports/hurdles.ts';
import {createSkeetCourse,skeetBonusAt} from '../../src/sports/skeet.ts';
import {PLAYER_COLORS,type SportId,type Competitor} from '../../src/sports/model.ts';
await Promise.all([loadRunnerAtlas(),loadVaultMotions(),loadSwimmingMotion(),loadSkeetMotion()]);
const people=Array.from({length:8},(_,i)=>({id:'guide-'+i,name:['민트','햇살','복숭아','하늘','라일락','귤빛','클로버','체리'][i],avatar:i,color:PLAYER_COLORS[i],ready:true,connected:true,total:0}));
const course=createSkeetCourse(73019);
function snapshot(sport:SportId,cut:Cut,offset=0){
 const m=createMatch(people,[sport]);startRound(m);m.phase='playing';const r=m.round!;r.time=10+offset+(sport==='swimming'?(cut.age??.2):0);r.wind=0;r.skeetTargets=course;
 for(const [i,p] of r.players.entries()){
  Object.assign(p,cut.state);p.phaseAt=10-(cut.age??.2);p.vault={runSpeed:8.5,launchAngle:52,peak:60,duration:2.6,targetRotation:Math.PI*2,success:cut.state.vaultSuccess??true};
  const age=r.time-p.phaseAt;
  if(sport==='hurdles'){
   if(p.phase==='jump')p.height=hurdleHeight(age);
   if(p.phase==='fall')p.rotation=Math.min(1,age/.4)*1.45;
   if(p.phase==='recover')p.rotation=1.45*(1-Math.min(1,age/.45));
  }
  if(sport==='vault'){
   if(p.phase==='takeoff'){p.height=Math.sin(Math.min(1,age/.4)*Math.PI/2)*24;p.progress=76+Math.min(1,age/.4)*8;}
   if(p.phase==='horse'){p.height=24+Math.sin(Math.min(1,age/.35)*Math.PI/2)*12;p.progress=84+age*12;}
   if(p.phase==='air')p.rotation=(cut.state.rotation??0)+offset*2.8;
  }
  if(sport==='triple'&&p.phase==='flight')p.height=Math.sin(Math.min(1,age/1.1)*Math.PI)*42;
  if(sport==='pole'){
   if(p.phase==='bend'){p.height=Math.sin(Math.min(1,age/1.6)*Math.PI/2)*60;p.rotation=-Math.min(1,age/1.6)*1.6;}
   if(p.phase==='air'&&!p.finished){p.progress=80+age*24;p.height=60+Math.sin(Math.min(1,age/2)*Math.PI)*p.power*9-age*25;p.rotation=-1.6+age*2;}
  }
  if(sport==='archery'){
   if(cut.state.loadingAge!==undefined)p.aimAt=10-cut.state.loadingAge;
   if(cut.state.arrowAge!==undefined)p.arrow={at:10-cut.state.arrowAge,angle:p.angle,points:10,error:0};
  }
  if(sport==='skeet'&&cut.state.skeetSide!==undefined){
   const side=cut.state.skeetSide as 0|1,disc=course.find(d=>d.side===side)!;r.time=disc.hitAt+(cut.age??.2)+offset;
   p.skeetAim={side,at:disc.hitAt,fromSide:side===0?1:0};
   if(!cut.state.aimOnly)p.shotEffects=[{id:disc.id,side,at:disc.hitAt,hit:cut.state.hit??true}];
  }
  if(sport==='skeet'&&cut.state.bonusTarget)r.time=skeetBonusAt(course)+.4+offset;
  if(p.finished){p.height=0;p.speed=0;}
 }
 return r;
}
const root=document.querySelector('#chapters')!;
const assets:HTMLCanvasElement[]=[];
function canvas(name:string,w=480,h=250){const c=document.createElement('canvas');c.width=w;c.height=h;c.dataset.export=name;assets.push(c);return c;}
const metadata=chapters.map(({sport,prefix,name,background,source,cuts})=>({sport,prefix,name,background,source,cuts:cuts.map(({state,...cut})=>cut)}));
const metadataNode=document.createElement('script');metadataNode.type='application/json';metadataNode.id='catalog-data';metadataNode.textContent=JSON.stringify(metadata);document.body.append(metadataNode);
for(const chapter of chapters){
 document.querySelector('nav')!.insertAdjacentHTML('beforeend',`<a href="#${chapter.prefix}">${chapter.prefix} ${chapter.name}</a>`);
 const section=document.createElement('section');section.id=chapter.prefix;section.innerHTML=`<h2>${chapter.prefix} · ${chapter.name}</h2><p>${chapter.background}</p><div class="scenes"></div><h3>동작 컷</h3><div class="cuts"></div>`;root.append(section);
 const scenes=section.querySelector('.scenes')!;
 for(const shared of [true,false]){const fig=document.createElement('figure');fig.className=shared?'wide':'';fig.innerHTML=`<h3>${chapter.prefix}-BG-${shared?'MAIN':'PHONE'} · 캐릭터 없는 ${shared?'공동 경기장':'개인 화면'}</h3><small>선수·이름·조작 게이지·발사체 제외 / 경기 시설 유지</small>`;const c=canvas(`${chapter.prefix}-BG-${shared?'MAIN':'PHONE'}.png`);background(c,chapter.sport,shared);fig.append(c);scenes.append(fig);}
 const arenaFig=document.createElement('figure');arenaFig.className='wide';arenaFig.innerHTML=`<h3>${chapter.prefix}-SCREEN-MAIN · 8인 공동 경기장</h3>`;
 const arena=canvas(`${chapter.prefix}-SCREEN-MAIN.png`),chosen=chapter.cuts.find(c=>c.phase.includes('run')||c.phase==='swim'||c.id.endsWith('04'))??chapter.cuts[0];new SportsArena(arena).draw(people,snapshot(chapter.sport,chosen),10);arenaFig.append(arena);scenes.append(arenaFig);
 for(const cut of chapter.cuts){
  const card=document.createElement('article');card.innerHTML=`<code>${cut.id}</code><h3>${cut.name}</h3><small>${cut.kind} · ${cut.phase}</small><p>${cut.input}<br>${cut.note}</p>`;
  const still=canvas(`${cut.id}.png`),stillRound=snapshot(chapter.sport,cut);new SportCanvas(still).draw(people[0],stillRound.players[0],stillRound,stillRound.time);card.prepend(still);
  const strip=canvas(`${cut.id}-strip.png`,480*6,250);strip.className='strip';const sg=strip.getContext('2d')!;sg.imageSmoothingEnabled=false;
  for(let frame=0;frame<6;frame++){const r=snapshot(chapter.sport,cut,(cut.span??.25)*frame/5),temp=document.createElement('canvas');new SportCanvas(temp).draw(people[0],r.players[0],r,r.time);sg.drawImage(temp,frame*480,0);}
  card.append(strip);section.querySelector('.cuts')!.append(card);
 }
 const sheet=canvas(`${chapter.prefix}-CUTS.png`,1440,Math.ceil(chapter.cuts.length/3)*390+105);sheet.className='strip';const g=sheet.getContext('2d')!;g.fillStyle='#f4f4e9';g.fillRect(0,0,sheet.width,sheet.height);g.fillStyle='#31594b';g.font='bold 30px sans-serif';g.fillText(`${chapter.prefix} · ${chapter.name} / v1.1.13`,24,44);g.font='17px sans-serif';g.fillText('현재 게임 렌더러로 그린 컷 · 컷 ID로 수정 요청 · 구간별 대표 프레임',24,78);
 for(const [i,cut] of chapter.cuts.entries()){const x=i%3*480,y=105+Math.floor(i/3)*390;g.drawImage(assets.find(c=>c.dataset.export===`${cut.id}.png`)!,x+8,y,464,242);g.fillStyle='#31594b';g.font='bold 22px sans-serif';g.fillText(`${cut.id}  ${cut.name}`,x+14,y+272);g.font='16px sans-serif';g.fillStyle='#85623f';g.fillText(`${cut.kind} · ${cut.phase}`,x+14,y+302);g.fillStyle='#54725e';g.fillText(cut.input,x+14,y+332);}
 section.append(sheet);
}
// Two scenery boards keep all eight backgrounds readable in chat.
for(let group=0;group<2;group++){
 const board=canvas(`BACKGROUNDS-${group+1}.png`,1280,1010);board.className='strip';const g=board.getContext('2d')!;g.fillStyle='#f4f4e9';g.fillRect(0,0,1280,1010);g.fillStyle='#31594b';g.font='bold 28px sans-serif';g.fillText(`캐릭터 없는 공동 경기장 · ${group? '양궁 / 세단뛰기 / 역도 / 장대':'장애물 / 수영 / 사격 / 도마'}`,22,42);
 for(let i=0;i<4;i++){const ch=chapters[group*4+i],x=i%2*640,y=70+Math.floor(i/2)*465;g.drawImage(assets.find(c=>c.dataset.export===`${ch.prefix}-BG-MAIN.png`)!,x+10,y,620,368);g.fillStyle='#31594b';g.font='bold 23px sans-serif';g.fillText(`${ch.prefix}-BG-MAIN · ${ch.name}`,x+15,y+400);g.font='16px sans-serif';g.fillStyle='#6b7e68';g.fillText(ch.background,x+15,y+430);}
 document.body.append(board);
}
document.querySelector('#status')!.textContent=`준비 완료 · ${chapters.length}종목 / ${chapters.reduce((n,c)=>n+c.cuts.length,0)}컷 / 캐릭터 없는 배경 16장`;
document.body.dataset.ready='true';
const download=document.createElement('button');download.textContent='동작 컷과 배경 ZIP 저장';document.querySelector('#status')!.append(' ',download);
download.onclick=async()=>{
 download.disabled=true;const enc=new TextEncoder();const entries:Array<{name:string;bytes:Uint8Array}>=[];
 const prefix=new URLSearchParams(location.search).get('export');
 for(const c of assets.filter(c=>!prefix||c.dataset.export?.startsWith(prefix))){const blob=await new Promise<Blob>(resolve=>c.toBlob(blob=>resolve(blob!),'image/png'));entries.push({name:'images/'+c.dataset.export,bytes:new Uint8Array(await blob.arrayBuffer())});}
 entries.push({name:'catalog.json',bytes:enc.encode(JSON.stringify(metadata,null,2))});
 const chunks:Uint8Array[]=[],central:Uint8Array[]=[];let offset=0;
 const table=Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
 const crc=(bytes:Uint8Array)=>{let n=0xffffffff;for(const b of bytes)n=table[(n^b)&255]^(n>>>8);return (n^0xffffffff)>>>0;};
 for(const {name,bytes} of entries){
  const filename=enc.encode(name),sum=crc(bytes),header=new Uint8Array(30+filename.length),h=new DataView(header.buffer);
  h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x800,true);h.setUint32(14,sum,true);h.setUint32(18,bytes.length,true);h.setUint32(22,bytes.length,true);h.setUint16(26,filename.length,true);header.set(filename,30);
  const record=new Uint8Array(46+filename.length),r=new DataView(record.buffer);r.setUint32(0,0x02014b50,true);r.setUint16(4,20,true);r.setUint16(6,20,true);r.setUint16(8,0x800,true);r.setUint32(16,sum,true);r.setUint32(20,bytes.length,true);r.setUint32(24,bytes.length,true);r.setUint16(28,filename.length,true);r.setUint32(42,offset,true);record.set(filename,46);
  chunks.push(header,bytes);central.push(record);offset+=header.length+bytes.length;
 }
 const end=new Uint8Array(22),e=new DataView(end.buffer);e.setUint32(0,0x06054b50,true);e.setUint16(8,entries.length,true);e.setUint16(10,entries.length,true);e.setUint32(12,central.reduce((n,c)=>n+c.length,0),true);e.setUint32(16,offset,true);
 const a=document.createElement('a');a.download='udangtang-motion-guide-images.zip';a.href=URL.createObjectURL(new Blob([...chunks,...central,end]));a.textContent='준비된 ZIP 다운로드';download.after(a);a.click();download.disabled=false;
};
